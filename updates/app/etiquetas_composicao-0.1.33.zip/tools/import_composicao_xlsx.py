#!/usr/bin/env python3

from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app.services.textile_importer import import_company_textiles  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser(description="Importa composicoes de tecidos a partir de uma planilha XLSX.")
    parser.add_argument("xlsx", help="Caminho da planilha XLSX")
    parser.add_argument("--company", required=True, help="Nome da empresa (por exemplo: la_playa ou lua morena)")
    parser.add_argument("--merge", action="store_true", help="Mescla todas as abas de composicao preservando os cadastros existentes")
    args = parser.parse_args()

    result = import_company_textiles(args.xlsx, args.company, merge=args.merge)
    print(
        f"Empresa: {result['company']}\n"
        f"Linhas lidas: {result['rows_read']}\n"
        f"Etiquetas novas: {result['labels_created']}\n"
        f"Opcoes de tecido novas: {result['options_created']}"
    )
    for conflict in result.get("conflicts", []):
        print(f"CONFLITO preservado: {conflict}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
