import csv
import json
from pathlib import Path
from app.domain.models import LabelTemplate, Assignment, AssignmentRule, ProductTextileOption
from app.paths import DATA_DIR

LABEL_FIELDS = [
    "label_code", "layout_preset", "width_mm", "height_mm", "labels_per_row",
    "text_size_mm", "symbol_size_mm", "left_margin_mm", "top_margin_mm", "right_margin_mm", "bottom_margin_mm", "symbol_x_offset_mm",
    "tecido_principal", "forro", "bojo", "allowed_sizes", "symbols", "fabricante",
    "cnpj", "pais_origem", "instrucoes_adicionais", "logo_text", "vertical_code",
]

PRODUCT_TEXTILE_FIELDS = [
    "company",
    "ref_code",
    "textile_name",
    "color_type",
    "label_code",
]


class CsvStore:
    def __init__(self, base_dir: str = "data"):
        base = Path(base_dir)
        self.base = base if base.is_absolute() else (DATA_DIR if base_dir == "data" else (DATA_DIR.parent / base))
        self.base.mkdir(parents=True, exist_ok=True)
        self.labels_file = self.base / "labels.csv"
        self.assignments_file = self.base / "assignments.csv"
        self.assignment_rules_file = self.base / "assignment_rules.csv"
        self.product_textiles_file = self.base / "product_textiles.csv"
        self.jobs_file = self.base / "print_jobs.csv"
        self._ensure_files()
        self._migrate_labels_file()

    def _ensure_files(self):
        if not self.labels_file.exists():
            with self.labels_file.open("w", newline="", encoding="utf-8") as f:
                csv.writer(f).writerow(LABEL_FIELDS)
        if not self.assignments_file.exists():
            with self.assignments_file.open("w", newline="", encoding="utf-8") as f:
                csv.writer(f).writerow(["ref_code", "label_code"])
        if not self.assignment_rules_file.exists():
            with self.assignment_rules_file.open("w", newline="", encoding="utf-8") as f:
                csv.writer(f).writerow(["priority", "ref_suffix", "color_prefix", "label_code"])
        if not self.product_textiles_file.exists():
            with self.product_textiles_file.open("w", newline="", encoding="utf-8") as f:
                csv.writer(f).writerow(PRODUCT_TEXTILE_FIELDS)
        if not self.jobs_file.exists():
            with self.jobs_file.open("w", newline="", encoding="utf-8") as f:
                csv.writer(f).writerow(["ref_code", "size", "quantity", "mode", "status"])

    def save_label(self, t: LabelTemplate):
        labels = {x.label_code: x for x in self.list_labels()}
        labels[t.label_code] = t
        self.save_labels(list(labels.values()))

    def save_labels(self, labels: list[LabelTemplate]):
        ordered = {x.label_code: x for x in labels}
        with self.labels_file.open("w", newline="", encoding="utf-8") as f:
            wr = csv.writer(f)
            wr.writerow(LABEL_FIELDS)
            for k in sorted(ordered.keys()):
                x = ordered[k]
                wr.writerow([
                    x.label_code, x.layout_preset, x.width_mm, x.height_mm, x.labels_per_row, x.text_size_mm, x.symbol_size_mm, x.left_margin_mm, x.top_margin_mm, x.right_margin_mm, x.bottom_margin_mm, x.symbol_x_offset_mm, x.tecido_principal, x.forro, x.bojo,
                    json.dumps(x.allowed_sizes, ensure_ascii=False),
                    json.dumps(x.symbols, ensure_ascii=False),
                    x.fabricante, x.cnpj, x.pais_origem, x.instrucoes_adicionais,
                    x.logo_text, x.vertical_code,
                ])

    def list_labels(self) -> list[LabelTemplate]:
        out = []
        with self.labels_file.open("r", newline="", encoding="utf-8") as f:
            rd = csv.DictReader(f)
            for r in rd:
                out.append(LabelTemplate(
                    label_code=r["label_code"],
                    layout_preset=r.get("layout_preset", "padrao") or "padrao",
                    width_mm=float(r["width_mm"]),
                    height_mm=float(r["height_mm"]),
                    labels_per_row=int(r.get("labels_per_row", "1") or "1"),
                    text_size_mm=float(r.get("text_size_mm", "2.0") or "2.0"),
                    symbol_size_mm=float(r.get("symbol_size_mm", "4.0") or "4.0"),
                    left_margin_mm=float(r.get("left_margin_mm", "0.0") or "0.0"),
                    top_margin_mm=float(r.get("top_margin_mm", "0.0") or "0.0"),
                    right_margin_mm=float(r.get("right_margin_mm", "0.0") or "0.0"),
                    bottom_margin_mm=float(r.get("bottom_margin_mm", "0.0") or "0.0"),
                    symbol_x_offset_mm=float(r.get("symbol_x_offset_mm", "-4.0") or "-4.0"),
                    tecido_principal=r["tecido_principal"],
                    forro=r["forro"],
                    bojo=r["bojo"],
                    allowed_sizes=json.loads(r["allowed_sizes"] or "[]"),
                    symbols=json.loads(r["symbols"] or "[]"),
                    fabricante=r.get("fabricante", ""),
                    cnpj=r.get("cnpj", ""),
                    pais_origem=r.get("pais_origem", ""),
                    instrucoes_adicionais=r.get("instrucoes_adicionais", ""),
                    logo_text=r.get("logo_text", ""),
                    vertical_code=r.get("vertical_code", ""),
                ))
        return out

    def save_product_textiles(self, options: list[ProductTextileOption]):
        ordered = []
        seen = set()
        for opt in options:
            key = (
                str(opt.company or "").strip().lower(),
                str(opt.ref_code or "").strip(),
                str(opt.textile_name or "").strip(),
                str(opt.color_type or "").strip().upper(),
                str(opt.label_code or "").strip(),
            )
            if key in seen:
                continue
            seen.add(key)
            ordered.append(opt)
        with self.product_textiles_file.open("w", newline="", encoding="utf-8") as f:
            wr = csv.writer(f)
            wr.writerow(PRODUCT_TEXTILE_FIELDS)
            for opt in ordered:
                wr.writerow([
                    opt.company,
                    opt.ref_code,
                    opt.textile_name,
                    opt.color_type,
                    opt.label_code,
                ])

    def list_product_textiles(self, company: str | None = None, ref_code: str | None = None) -> list[ProductTextileOption]:
        out = []
        if not self.product_textiles_file.exists():
            return out
        company_n = str(company or "").strip().lower()
        ref_n = str(ref_code or "").strip()
        with self.product_textiles_file.open("r", newline="", encoding="utf-8") as f:
            rd = csv.DictReader(f)
            for r in rd:
                item = ProductTextileOption(
                    company=str(r.get("company", "") or "").strip(),
                    ref_code=str(r.get("ref_code", "") or "").strip(),
                    textile_name=str(r.get("textile_name", "") or "").strip(),
                    color_type=str(r.get("color_type", "") or "").strip().upper(),
                    label_code=str(r.get("label_code", "") or "").strip(),
                )
                if company_n and item.company.strip().lower() != company_n:
                    continue
                if ref_n and item.ref_code != ref_n:
                    continue
                out.append(item)
        return out

    def _migrate_labels_file(self):
        if not self.labels_file.exists():
            return
        with self.labels_file.open("r", newline="", encoding="utf-8") as f:
            rd = csv.DictReader(f)
            current_fields = rd.fieldnames or []
            if current_fields == LABEL_FIELDS:
                return
            rows = list(rd)

        with self.labels_file.open("w", newline="", encoding="utf-8") as f:
            wr = csv.writer(f)
            wr.writerow(LABEL_FIELDS)
            for r in rows:
                wr.writerow([
                    r.get("label_code", ""),
                    r.get("layout_preset", "padrao") or "padrao",
                    r.get("width_mm", "47"),
                    r.get("height_mm", "25"),
                    r.get("labels_per_row", "1"),
                    r.get("text_size_mm", "2.0"),
                    r.get("symbol_size_mm", "4.0"),
                    r.get("left_margin_mm", "0.0"),
                    r.get("top_margin_mm", "0.0"),
                    r.get("right_margin_mm", "0.0"),
                    r.get("bottom_margin_mm", "0.0"),
                    r.get("symbol_x_offset_mm", "-4.0"),
                    r.get("tecido_principal", ""),
                    r.get("forro", ""),
                    r.get("bojo", ""),
                    r.get("allowed_sizes", "[]"),
                    r.get("symbols", "[]"),
                    r.get("fabricante", ""),
                    r.get("cnpj", ""),
                    r.get("pais_origem", ""),
                    r.get("instrucoes_adicionais", ""),
                    r.get("logo_text", ""),
                    r.get("vertical_code", ""),
                ])

    def save_assignments(self, assignments: list[Assignment]):
        with self.assignments_file.open("w", newline="", encoding="utf-8") as f:
            wr = csv.writer(f)
            wr.writerow(["ref_code", "label_code"])
            for a in assignments:
                wr.writerow([a.ref_code, a.label_code])

    def list_assignments(self) -> list[Assignment]:
        out = []
        with self.assignments_file.open("r", newline="", encoding="utf-8") as f:
            rd = csv.DictReader(f)
            for r in rd:
                out.append(Assignment(ref_code=r["ref_code"], label_code=r["label_code"]))
        return out

    def save_assignment_rules(self, rules: list[AssignmentRule]):
        rules = sorted(rules, key=lambda x: (int(x.priority), x.ref_suffix, x.color_prefix, x.label_code))
        with self.assignment_rules_file.open("w", newline="", encoding="utf-8") as f:
            wr = csv.writer(f)
            wr.writerow(["priority", "ref_suffix", "color_prefix", "label_code"])
            for r in rules:
                wr.writerow([r.priority, r.ref_suffix, r.color_prefix, r.label_code])

    def list_assignment_rules(self) -> list[AssignmentRule]:
        out = []
        with self.assignment_rules_file.open("r", newline="", encoding="utf-8") as f:
            rd = csv.DictReader(f)
            for r in rd:
                try:
                    prio = int(str(r.get("priority", "100") or "100").strip())
                except Exception:
                    prio = 100
                out.append(AssignmentRule(
                    priority=prio,
                    ref_suffix=str(r.get("ref_suffix", "") or "").strip(),
                    color_prefix=str(r.get("color_prefix", "") or "").strip(),
                    label_code=str(r.get("label_code", "") or "").strip(),
                ))
        return out

    def append_print_job(self, ref_code: str, size: str, quantity: int, mode: str, status: str):
        with self.jobs_file.open("a", newline="", encoding="utf-8") as f:
            csv.writer(f).writerow([ref_code, size, quantity, mode, status])
