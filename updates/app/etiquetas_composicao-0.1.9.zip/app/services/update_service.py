from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any
from urllib.request import urlopen

from app.paths import (
    DATA_DIR,
    PENDING_APP_UPDATE_PATH,
    PROJECT_ROOT,
    SYMBOLS_DIR,
    UPDATE_BACKUP_DIR,
    UPDATE_CACHE_DIR,
    UPDATE_STAGE_DIR,
    UPDATE_STATE_PATH,
)
from app.services.update_crypto import decrypt_bytes, sha256_hex
from app.update_config import load_update_config, resolve_bundle_url
from app.version import APP_VERSION, UPDATE_SCHEMA_VERSION


@dataclass
class BundleSpec:
    name: str
    version: str
    forced: bool
    bundle_url: str
    sha256_encrypted: str
    sha256_decrypted_zip: str


def _utc_now() -> str:
    return datetime.utcnow().replace(microsecond=0).isoformat() + "Z"


def _version_key(value: str) -> list[Any]:
    text = str(value or "").strip()
    if not text:
        return [0]
    parts: list[Any] = []
    token = ""
    token_is_digit = text[0].isdigit()
    for ch in text:
        if ch.isdigit() == token_is_digit and ch.isalnum():
            token += ch
            continue
        if token:
            parts.append(int(token) if token_is_digit else token.lower())
        token = ch if ch.isalnum() else ""
        token_is_digit = ch.isdigit()
    if token:
        parts.append(int(token) if token_is_digit else token.lower())
    return parts or [text.lower()]


def _is_newer(remote: str, local: str) -> bool:
    return _version_key(remote) > _version_key(local)


def _safe_read_json(path: Path, default: dict) -> dict:
    if not path.exists():
        return dict(default)
    try:
        loaded = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(loaded, dict):
            merged = dict(default)
            merged.update(loaded)
            return merged
    except Exception:
        pass
    return dict(default)


class UpdateService:
    def __init__(self) -> None:
        self.config = load_update_config()
        self.manifest_url = str(self.config.get("manifest_url", "") or "").strip()
        self.password = str(self.config.get("password", "") or "")
        self.check_timeout = float(self.config.get("check_timeout_seconds", 3.0) or 3.0)
        self.bundle_timeout = float(self.config.get("bundle_timeout_seconds", 20.0) or 20.0)
        self.auto_apply_data = bool(self.config.get("auto_apply_data", True))
        self.auto_stage_app = bool(self.config.get("auto_stage_app", True))
        UPDATE_CACHE_DIR.mkdir(parents=True, exist_ok=True)
        UPDATE_STAGE_DIR.mkdir(parents=True, exist_ok=True)
        UPDATE_BACKUP_DIR.mkdir(parents=True, exist_ok=True)
        DATA_DIR.mkdir(parents=True, exist_ok=True)

    def _log(self, message: str) -> None:
        print(f"[update] {message}", flush=True)

    def _default_state(self) -> dict:
        return {
            "schema_version": UPDATE_SCHEMA_VERSION,
            "app_version": APP_VERSION,
            "data_version": "0",
            "pending_app_version": "",
            "installed_app_files": [],
            "installed_data_files": [],
            "available_app_version": "",
            "available_data_version": "",
            "last_check": "",
            "last_error": "",
            "last_data_update": "",
            "last_app_stage": "",
            "last_app_apply": "",
        }

    def load_state(self) -> dict:
        state = _safe_read_json(UPDATE_STATE_PATH, self._default_state())
        if not state.get("app_version"):
            state["app_version"] = APP_VERSION
        return state

    def save_state(self, state: dict) -> None:
        state["schema_version"] = UPDATE_SCHEMA_VERSION
        UPDATE_STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
        UPDATE_STATE_PATH.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")

    def _record_error(self, state: dict, exc: Exception | str) -> None:
        self._log(f"erro: {exc}")
        state["last_error"] = str(exc)
        self.save_state(state)

    def _fetch_bytes(self, url: str, timeout: float) -> bytes:
        with urlopen(url, timeout=timeout) as response:
            return response.read()

    def _fetch_manifest(self) -> dict:
        if not self.manifest_url:
            self._log("manifest_url vazio, pulando checagem online.")
            return {}
        self._log(f"buscando manifesto: {self.manifest_url}")
        raw = self._fetch_bytes(self.manifest_url, self.check_timeout)
        manifest = json.loads(raw.decode("utf-8"))
        if not isinstance(manifest, dict):
            raise ValueError("Manifesto de update invalido.")
        self._log("manifesto recebido.")
        return manifest

    def _bundle_from_manifest(self, manifest: dict, name: str) -> BundleSpec | None:
        block = manifest.get(name)
        if not isinstance(block, dict):
            return None
        bundle_url = str(block.get("bundle_url", "") or "").strip()
        version = str(block.get("version", "") or "").strip()
        if not bundle_url or not version:
            return None
        return BundleSpec(
            name=name,
            version=version,
            forced=bool(block.get("forced", False)),
            bundle_url=resolve_bundle_url(self.manifest_url, bundle_url),
            sha256_encrypted=str(block.get("sha256_encrypted", "") or "").strip().lower(),
            sha256_decrypted_zip=str(block.get("sha256_decrypted_zip", "") or "").strip().lower(),
        )

    def _download_and_extract_bundle(self, spec: BundleSpec) -> tuple[Path, dict]:
        self._log(f"baixando pacote {spec.name} {spec.version}")
        encrypted = self._fetch_bytes(spec.bundle_url, self.bundle_timeout)
        if spec.sha256_encrypted and sha256_hex(encrypted) != spec.sha256_encrypted:
            raise ValueError(f"Hash do pacote {spec.name} nao confere.")
        self._log(f"descriptografando pacote {spec.name} {spec.version}")
        zip_bytes = decrypt_bytes(encrypted, self.password)
        if spec.sha256_decrypted_zip and sha256_hex(zip_bytes) != spec.sha256_decrypted_zip:
            raise ValueError(f"Hash interno do pacote {spec.name} nao confere.")

        work_dir = Path(tempfile.mkdtemp(prefix=f"etiquetas_{spec.name}_", dir=str(UPDATE_CACHE_DIR)))
        archive_path = work_dir / f"{spec.name}.zip"
        archive_path.write_bytes(zip_bytes)
        extract_dir = work_dir / "extract"
        extract_dir.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(archive_path, "r") as zf:
            zf.extractall(extract_dir)
        manifest_path = extract_dir / "bundle_manifest.json"
        if not manifest_path.exists():
            raise ValueError(f"Manifesto interno ausente no pacote {spec.name}.")
        bundle_manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        if not isinstance(bundle_manifest, dict):
            raise ValueError(f"Manifesto interno invalido no pacote {spec.name}.")
        self._log(f"pacote {spec.name} {spec.version} pronto para aplicar")
        return extract_dir, bundle_manifest

    def _backup_targets(self, relative_files: list[str], prefix: str) -> None:
        if not relative_files:
            return
        backup_root = UPDATE_BACKUP_DIR / f"{prefix}-{int(time.time())}"
        for rel in relative_files:
            src = PROJECT_ROOT / rel
            if not src.exists():
                continue
            dst = backup_root / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            if src.is_dir():
                if dst.exists():
                    shutil.rmtree(dst)
                shutil.copytree(src, dst)
            else:
                shutil.copy2(src, dst)

    def _remove_old_tracked_files(self, old_files: list[str], new_files: list[str]) -> None:
        old_set = {str(x).replace("\\", "/") for x in old_files if str(x).strip()}
        new_set = {str(x).replace("\\", "/") for x in new_files if str(x).strip()}
        for rel in sorted(old_set - new_set, reverse=True):
            path = PROJECT_ROOT / rel
            if not path.exists():
                continue
            try:
                if path.is_file():
                    path.unlink()
            except Exception:
                continue

    def _copy_relative_files(self, source_root: Path, relative_files: list[str]) -> None:
        for rel in relative_files:
            src = source_root / rel
            dst = PROJECT_ROOT / rel
            if not src.exists():
                continue
            dst.parent.mkdir(parents=True, exist_ok=True)
            if src.is_dir():
                if dst.exists():
                    shutil.rmtree(dst)
                shutil.copytree(src, dst)
            else:
                shutil.copy2(src, dst)

    def apply_data_update(self, spec: BundleSpec, state: dict) -> bool:
        self._log(f"atualizando dados: local={state.get('data_version', '0')} online={spec.version} forced={spec.forced}")
        extract_dir, bundle_manifest = self._download_and_extract_bundle(spec)
        files = [str(x).replace("\\", "/") for x in bundle_manifest.get("files", []) if str(x).strip()]
        if not files:
            raise ValueError("Pacote de dados sem lista de arquivos.")
        self._backup_targets(files, f"data-{spec.version}")
        self._remove_old_tracked_files(state.get("installed_data_files", []), files)
        self._copy_relative_files(extract_dir, files)
        state["data_version"] = spec.version
        state["installed_data_files"] = files
        state["available_data_version"] = spec.version
        state["last_data_update"] = _utc_now()
        state["last_error"] = ""
        self.save_state(state)
        shutil.rmtree(extract_dir.parent, ignore_errors=True)
        self._log(f"dados atualizados para {spec.version}")
        return True

    def stage_app_update(self, spec: BundleSpec, state: dict) -> bool:
        self._log(f"preparando update do programa: local={state.get('app_version', APP_VERSION)} online={spec.version} forced={spec.forced}")
        extract_dir, bundle_manifest = self._download_and_extract_bundle(spec)
        files = [str(x).replace("\\", "/") for x in bundle_manifest.get("files", []) if str(x).strip()]
        if not files:
            raise ValueError("Pacote de programa sem lista de arquivos.")
        stage_root = UPDATE_STAGE_DIR / f"app-{spec.version}"
        if stage_root.exists():
            shutil.rmtree(stage_root)
        shutil.move(str(extract_dir), str(stage_root))
        pending = {
            "version": spec.version,
            "forced": bool(spec.forced),
            "staged_at": _utc_now(),
            "stage_dir": str(stage_root),
            "files": files,
        }
        PENDING_APP_UPDATE_PATH.parent.mkdir(parents=True, exist_ok=True)
        PENDING_APP_UPDATE_PATH.write_text(json.dumps(pending, ensure_ascii=False, indent=2), encoding="utf-8")
        state["pending_app_version"] = spec.version
        state["available_app_version"] = spec.version
        state["last_app_stage"] = _utc_now()
        state["last_error"] = ""
        self.save_state(state)
        self._log(f"update do programa {spec.version} preparado")
        return True

    def startup_sync(self) -> dict:
        state = self.load_state()
        result = {"state": state, "restart_required": False}
        self._log("procurando atualizacoes...")
        self._log(f"versoes atuais: app={state.get('app_version', APP_VERSION)} data={state.get('data_version', '0')}")
        state["last_check"] = _utc_now()
        self.save_state(state)
        if not self.manifest_url:
            result["state"] = state
            return result
        try:
            manifest = self._fetch_manifest()
            app_spec = self._bundle_from_manifest(manifest, "app")
            data_spec = self._bundle_from_manifest(manifest, "data")
            if data_spec:
                self._log(f"versao online de dados: {data_spec.version} forced={data_spec.forced}")
                state["available_data_version"] = data_spec.version
                if self.auto_apply_data and _is_newer(data_spec.version, str(state.get("data_version", "0"))):
                    self.apply_data_update(data_spec, state)
                    state = self.load_state()
                else:
                    self._log("dados ja estao atualizados.")
            if app_spec:
                local_app_version = str(state.get("app_version", APP_VERSION) or APP_VERSION)
                self._log(f"versao online do programa: {app_spec.version} forced={app_spec.forced}")
                state["available_app_version"] = app_spec.version
                already_pending = str(state.get("pending_app_version", "") or "").strip() == app_spec.version
                staged_now = False
                if self.auto_stage_app and _is_newer(app_spec.version, local_app_version) and not already_pending:
                    self.stage_app_update(app_spec, state)
                    state = self.load_state()
                    staged_now = True
                elif already_pending:
                    self._log(f"update do programa {app_spec.version} ja estava preparado.")
                else:
                    self._log("programa ja esta atualizado.")
                if app_spec.forced and staged_now:
                    self._log("update forcado do programa preparado; reinicio imediato necessario.")
                    result["restart_required"] = True
            if not data_spec and not app_spec:
                self._log("manifesto sem pacotes validos de app/dados.")
            state["last_error"] = ""
            self.save_state(state)
            self._log("checagem de updates concluida.")
            result["state"] = state
            return result
        except Exception as exc:
            self._record_error(state, exc)
            self._log("seguindo sem bloquear a aplicacao.")
            result["state"] = state
            return result

    def _load_pending_update(self) -> dict | None:
        if not PENDING_APP_UPDATE_PATH.exists():
            return None
        try:
            payload = json.loads(PENDING_APP_UPDATE_PATH.read_text(encoding="utf-8"))
            if isinstance(payload, dict):
                return payload
        except Exception:
            return None
        return None

    def has_pending_app_update(self) -> bool:
        return self._load_pending_update() is not None

    def _apply_pending_app_update_once(self) -> bool:
        pending = self._load_pending_update()
        if not pending:
            return False
        version = str(pending.get("version", "") or "").strip()
        stage_dir = Path(str(pending.get("stage_dir", "") or "").strip())
        files = [str(x).replace("\\", "/") for x in pending.get("files", []) if str(x).strip()]
        if not version or not stage_dir.exists() or not files:
            return False
        self._log(f"aplicando update pendente do programa {version}")
        state = self.load_state()
        self._backup_targets(files, f"app-{version}")
        self._remove_old_tracked_files(state.get("installed_app_files", []), files)
        self._copy_relative_files(stage_dir, files)
        state["app_version"] = version
        state["pending_app_version"] = ""
        state["installed_app_files"] = files
        state["last_app_apply"] = _utc_now()
        state["last_error"] = ""
        self.save_state(state)
        try:
            PENDING_APP_UPDATE_PATH.unlink()
        except Exception:
            pass
        shutil.rmtree(stage_dir.parent, ignore_errors=True)
        self._log(f"update pendente do programa {version} aplicado")
        return True

    def apply_pending_app_update(self, wait_seconds: float = 25.0) -> bool:
        self._log("verificando se existe update pendente do programa...")
        deadline = time.time() + max(wait_seconds, 1.0)
        last_exc: Exception | None = None
        while time.time() < deadline:
            try:
                return self._apply_pending_app_update_once()
            except PermissionError as exc:
                last_exc = exc
                time.sleep(0.5)
            except Exception as exc:
                state = self.load_state()
                self._record_error(state, exc)
                return False
        if last_exc:
            state = self.load_state()
            self._record_error(state, last_exc)
        self._log("nenhum update pendente aplicado.")
        return False

    def _launch_runner(self, relaunch_cmd: list[str] | None = None) -> bool:
        pending = self._load_pending_update()
        if not pending:
            return False
        script_path = UPDATE_CACHE_DIR / "apply_pending_update_runner.py"
        relaunch_json = json.dumps(relaunch_cmd or [])
        script_path.write_text(
            (
                "import json, subprocess, sys, time\n"
                "from app.services.update_service import apply_pending_update_cli\n"
                "time.sleep(0.35)\n"
                f"cmd = json.loads({relaunch_json!r})\n"
                "code = apply_pending_update_cli(wait_seconds=25.0)\n"
                "if code == 0 and cmd:\n"
                f"    subprocess.Popen(cmd, cwd={str(PROJECT_ROOT)!r}, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL, start_new_session=True)\n"
            ),
            encoding="utf-8",
        )
        try:
            subprocess.Popen(
                [sys.executable, str(script_path)],
                cwd=str(PROJECT_ROOT),
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL,
                start_new_session=True,
            )
            return True
        except Exception:
            return False

    def launch_pending_app_update_after_exit(self, parent_pid: int) -> bool:
        return self._launch_runner()

    def launch_pending_app_update_and_restart(self, entry_script: str, extra_args: list[str] | None = None) -> bool:
        cmd = [sys.executable, entry_script]
        if extra_args:
            cmd.extend(extra_args)
        return self._launch_runner(relaunch_cmd=cmd)


def apply_pending_update_cli(wait_seconds: float = 25.0) -> int:
    service = UpdateService()
    return 0 if service.apply_pending_app_update(wait_seconds=wait_seconds) else 1
