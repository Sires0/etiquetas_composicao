import json
import os
import tkinter as tk
from tkinter import ttk

from app.domain.constants import PRINT_MODES, SIZE_OPTIONS
from app.paths import DATA_DIR
from app.services.print_service import PrintService
from app.storage.csv_store import CsvStore
from app.ui.main_window import MainWindow


class PrintWindow(MainWindow):
    def __init__(self, master):
        ttk.Frame.__init__(self, master)
        self.store = CsvStore("data")
        self.print_service = PrintService()
        self.current_preview_img = None
        self.defaults_path = ""
        self.ui_state_path = str(DATA_DIR / "ui_state_print.json")
        self._textile_options = []
        self._textile_option_by_display = {}

        self.pack(fill="both", expand=True)
        self._build_ui()
        self._bind_ctrl_a()
        self.refresh_labels_combo()
        self._load_printers()
        self._load_ui_state()
        self.winfo_toplevel().protocol("WM_DELETE_WINDOW", self._on_close)

    def _build_ui(self):
        outer = ttk.Frame(self)
        outer.pack(fill="both", expand=True, padx=10, pady=10)

        ttk.Label(outer, text="Impressao de Etiquetas", font=("TkDefaultFont", 14, "bold")).pack(anchor="w", pady=(0, 8))

        self.v_ref = tk.StringVar()
        self.v_color = tk.StringVar()
        self.v_textile = tk.StringVar()
        self.v_size = tk.StringVar(value="M")
        self.v_qty = tk.StringVar(value="1")
        self.v_mode = tk.StringVar(value="frente-verso-separados")
        self.v_printer = tk.StringVar()

        def row(parent, label, var, width=18):
            r = ttk.Frame(parent)
            r.pack(fill="x", padx=8, pady=3)
            ttk.Label(r, text=label, width=18).pack(side="left")
            ttk.Entry(r, textvariable=var, width=width).pack(side="left", fill="x", expand=True)

        manual = ttk.LabelFrame(outer, text="Dados")
        manual.pack(fill="x", padx=8, pady=8)

        row(manual, "REF do produto", self.v_ref)
        row(manual, "Cor do produto", self.v_color)

        rsize = ttk.Frame(manual)
        rsize.pack(fill="x", padx=8, pady=3)
        ttk.Label(rsize, text="Tamanho", width=18).pack(side="left")
        ttk.Combobox(rsize, values=SIZE_OPTIONS, textvariable=self.v_size, state="readonly", width=16).pack(side="left")

        rtextile = ttk.Frame(manual)
        rtextile.pack(fill="x", padx=8, pady=3)
        ttk.Label(rtextile, text="Tecido", width=18).pack(side="left")
        self.cmb_textile = ttk.Combobox(rtextile, textvariable=self.v_textile, state="readonly", width=28)
        self.cmb_textile.pack(side="left", fill="x", expand=True)

        row(manual, "Quantidade", self.v_qty)

        mode_box = ttk.LabelFrame(outer, text="Configuracao")
        mode_box.pack(fill="x", padx=8, pady=(0, 8))

        rmode = ttk.Frame(mode_box)
        rmode.pack(fill="x", padx=8, pady=(8, 3))
        ttk.Label(rmode, text="Modo", width=18).pack(side="left")
        ttk.Combobox(rmode, values=PRINT_MODES, textvariable=self.v_mode, state="readonly", width=22).pack(side="left")

        prow_manual = ttk.Frame(mode_box)
        prow_manual.pack(fill="x", padx=8, pady=(6, 3))
        ttk.Label(prow_manual, text="Impressora", width=18).pack(side="left")
        self.cmb_printer = ttk.Combobox(prow_manual, textvariable=self.v_printer, width=28)
        self.cmb_printer.pack(side="left", fill="x", expand=True)
        ttk.Button(prow_manual, text="Detectar", command=self._load_printers).pack(side="left", padx=(6, 0))

        ttk.Button(outer, text="Imprimir", command=self.print_manual).pack(anchor="w", padx=8, pady=(0, 6))

        self.v_ref.trace_add("write", self._refresh_textile_options)
        self.v_color.trace_add("write", self._refresh_textile_options)
        self._refresh_textile_options()

    def _load_ui_state(self):
        if not os.path.exists(self.ui_state_path):
            return
        try:
            with open(self.ui_state_path, "r", encoding="utf-8") as f:
                json.load(f)
        except Exception:
            return

    def _save_ui_state(self):
        state = {}
        os.makedirs(os.path.dirname(self.ui_state_path), exist_ok=True)
        with open(self.ui_state_path, "w", encoding="utf-8") as f:
            json.dump(state, f, ensure_ascii=False, indent=2)

    def _on_close(self):
        try:
            self._save_ui_state()
        finally:
            self.winfo_toplevel().destroy()
