import json
import os
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from app.domain.constants import PRINT_MODES, SIZE_OPTIONS
from app.domain.models import PrintRequest
from app.paths import DATA_DIR
from app.services.import_service import ImportErrorReport, parse_print_requests
from app.services.print_service import PrintService
from app.storage.csv_store import CsvStore
from app.ui.main_window import MainWindow


class PrintWindow(MainWindow):
    def __init__(self, master):
        ttk.Frame.__init__(self, master)
        self.store = CsvStore("data")
        self.print_service = PrintService()
        self.current_preview_img = None
        self.defaults_path = ""
        self.ui_state_path = str(DATA_DIR / "ui_state_print.json")
        self.pending_import_requests = []
        self.import_path = ""
        self.print_summary = tk.StringVar(value="Nenhum lote carregado.")
        self._textile_options = []
        self._textile_option_by_display = {}

        self.pack(fill="both", expand=True)
        self._build_ui()
        self._bind_ctrl_a()
        self.refresh_labels_combo()
        self._load_printers()
        self._load_ui_state()
        self._refresh_print_summary()
        self.winfo_toplevel().protocol("WM_DELETE_WINDOW", self._on_close)

    def _build_ui(self):
        outer = ttk.Frame(self)
        outer.pack(fill="both", expand=True, padx=10, pady=10)

        ttk.Label(outer, text="Impressao de Etiquetas", font=("TkDefaultFont", 14, "bold")).pack(anchor="w", pady=(0, 8))

        self.v_ref = tk.StringVar()
        self.v_color = tk.StringVar()
        self.v_textile = tk.StringVar()
        self.v_size = tk.StringVar(value="M")
        self.v_qty = tk.StringVar(value="1")
        self.v_mode = tk.StringVar(value="frente-verso-separados")
        self.v_printer = tk.StringVar()

        self.print_notebook = ttk.Notebook(outer)
        self.print_notebook.pack(fill="both", expand=True)

        tab_manual = ttk.Frame(self.print_notebook)
        tab_batch = ttk.Frame(self.print_notebook)
        self.print_notebook.add(tab_manual, text="Impressao manual")
        self.print_notebook.add(tab_batch, text="Impressao por arquivo")

        def row(parent, label, var, width=18):
            r = ttk.Frame(parent)
            r.pack(fill="x", padx=8, pady=3)
            ttk.Label(r, text=label, width=18).pack(side="left")
            ttk.Entry(r, textvariable=var, width=width).pack(side="left", fill="x", expand=True)

        manual = ttk.LabelFrame(tab_manual, text="Dados")
        manual.pack(fill="x", padx=8, pady=8)

        row(manual, "REF do produto", self.v_ref)
        row(manual, "Cor do produto", self.v_color)

        rsize = ttk.Frame(manual)
        rsize.pack(fill="x", padx=8, pady=3)
        ttk.Label(rsize, text="Tamanho", width=18).pack(side="left")
        ttk.Combobox(rsize, values=SIZE_OPTIONS, textvariable=self.v_size, state="readonly", width=16).pack(side="left")

        rtextile = ttk.Frame(manual)
        rtextile.pack(fill="x", padx=8, pady=3)
        ttk.Label(rtextile, text="Tecido", width=18).pack(side="left")
        self.cmb_textile = ttk.Combobox(rtextile, textvariable=self.v_textile, state="readonly", width=28)
        self.cmb_textile.pack(side="left", fill="x", expand=True)

        row(manual, "Quantidade", self.v_qty)

        mode_box = ttk.LabelFrame(tab_manual, text="Configuracao")
        mode_box.pack(fill="x", padx=8, pady=(0, 8))

        rmode = ttk.Frame(mode_box)
        rmode.pack(fill="x", padx=8, pady=(8, 3))
        ttk.Label(rmode, text="Modo", width=18).pack(side="left")
        ttk.Combobox(rmode, values=PRINT_MODES, textvariable=self.v_mode, state="readonly", width=22).pack(side="left")

        prow_manual = ttk.Frame(mode_box)
        prow_manual.pack(fill="x", padx=8, pady=(6, 3))
        ttk.Label(prow_manual, text="Impressora", width=18).pack(side="left")
        self.cmb_printer = ttk.Combobox(prow_manual, textvariable=self.v_printer, width=28)
        self.cmb_printer.pack(side="left", fill="x", expand=True)
        ttk.Button(prow_manual, text="Detectar", command=self._load_printers).pack(side="left", padx=(6, 0))

        ttk.Button(tab_manual, text="Imprimir", command=self.print_manual).pack(anchor="w", padx=8, pady=(0, 6))

        batch = ttk.LabelFrame(tab_batch, text="Arquivo")
        batch.pack(fill="x", padx=8, pady=8)

        imp = ttk.Frame(batch)
        imp.pack(fill="x", padx=8, pady=(8, 4))
        ttk.Button(imp, text="Carregar arquivo", command=self.import_print_requests).pack(side="left")
        ttk.Button(imp, text="Imprimir lote", command=self.print_imported_requests).pack(side="left", padx=6)
        ttk.Button(imp, text="Limpar tabela", command=self.clear_print_table).pack(side="left", padx=6)
        ttk.Label(batch, text="Formato: CODE,COLOR,SIZE[,QTD] (QTD opcional; padrao 1)", foreground="#4a4a4a").pack(fill="x", padx=8, pady=(0, 6))

        prow = ttk.Frame(batch)
        prow.pack(fill="x", padx=8, pady=(6, 6))
        ttk.Label(prow, text="Impressora", width=12).pack(side="left")
        self.cmb_printer_batch = ttk.Combobox(prow, textvariable=self.v_printer, width=28)
        self.cmb_printer_batch.pack(side="left", fill="x", expand=True)
        ttk.Button(prow, text="Detectar", command=self._load_printers).pack(side="left", padx=(6, 0))

        self.v_ref.trace_add("write", self._refresh_textile_options)
        self.v_color.trace_add("write", self._refresh_textile_options)
        self._refresh_textile_options()

        self.lbl_import = ttk.Label(batch, text="Nenhum arquivo carregado.", foreground="#4a4a4a")
        self.lbl_import.pack(fill="x", padx=8, pady=(0, 8))

        ttk.Label(tab_batch, textvariable=self.print_summary, foreground="#1f4f82").pack(fill="x", padx=8, pady=(0, 8))

        history = ttk.LabelFrame(tab_batch, text="Fila")
        history.pack(fill="both", expand=True, padx=8, pady=(0, 8))

        cols = ("produto", "etiq", "tam", "tecido", "qtd", "status")
        wrap = ttk.Frame(history)
        wrap.pack(fill="both", expand=True)
        self.tr_print = ttk.Treeview(wrap, columns=cols, show="headings")
        self.tr_print.heading("produto", text="Produto")
        self.tr_print.heading("etiq", text="ETIQ")
        self.tr_print.heading("tam", text="Tamanho")
        self.tr_print.heading("tecido", text="Tecido")
        self.tr_print.heading("qtd", text="Qtd")
        self.tr_print.heading("status", text="Status")
        self.tr_print.column("produto", width=220, anchor="w")
        self.tr_print.column("etiq", width=80, anchor="center")
        self.tr_print.column("tam", width=80, anchor="center")
        self.tr_print.column("tecido", width=180, anchor="w")
        self.tr_print.column("qtd", width=60, anchor="center")
        self.tr_print.column("status", width=520, anchor="w")
        y = ttk.Scrollbar(wrap, orient="vertical", command=self.tr_print.yview)
        self.tr_print.configure(yscrollcommand=y.set)
        self.tr_print.pack(side="left", fill="both", expand=True)
        y.pack(side="right", fill="y")

    def _load_ui_state(self):
        if not os.path.exists(self.ui_state_path):
            return
        try:
            with open(self.ui_state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
        except Exception:
            return

        tab_index = int(state.get("tab_index", 0) or 0)
        if hasattr(self, "print_notebook"):
            tabs = self.print_notebook.tabs()
            if 0 <= tab_index < len(tabs):
                self.print_notebook.select(tab_index)

        widths = state.get("tree_columns", {})
        if hasattr(self, "tr_print") and isinstance(widths, dict):
            for col, width in widths.items():
                if col in self.tr_print["columns"]:
                    try:
                        self.tr_print.column(col, width=int(width))
                    except Exception:
                        continue

    def _save_ui_state(self):
        state = {
            "tab_index": self.print_notebook.index(self.print_notebook.select()) if hasattr(self, "print_notebook") else 0,
            "tree_columns": {},
        }
        if hasattr(self, "tr_print"):
            for col in self.tr_print["columns"]:
                state["tree_columns"][col] = int(self.tr_print.column(col, "width"))
        os.makedirs(os.path.dirname(self.ui_state_path), exist_ok=True)
        with open(self.ui_state_path, "w", encoding="utf-8") as f:
            json.dump(state, f, ensure_ascii=False, indent=2)

    def _on_close(self):
        try:
            self._save_ui_state()
        finally:
            self.winfo_toplevel().destroy()

    def _refresh_print_summary(self):
        loaded = len(self.pending_import_requests or [])
        rows = len(self.tr_print.get_children()) if hasattr(self, "tr_print") else 0
        printer = self.v_printer.get().strip() if hasattr(self, "v_printer") else ""
        printer_txt = printer if printer else "nenhuma selecionada"
        self.print_summary.set(f"Lote: {loaded} | Tabela: {rows} | Impressora: {printer_txt}")

    def _load_printers(self):
        super()._load_printers()
        self._refresh_print_summary()

    def _add_print_row(self, ref: str, etiq: str, tecido: str, tam: str, qtd, modo: str, frente, verso, status: str):
        self.tr_print.insert("", "end", values=(ref, etiq, tam, tecido, qtd, status))
        self._refresh_print_summary()

    def clear_print_table(self):
        super().clear_print_table()
        self._refresh_print_summary()

    def print_manual(self):
        super().print_manual()
        self._refresh_print_summary()

    def import_print_requests(self):
        path = filedialog.askopenfilename(filetypes=[("CSV/XLSX", "*.csv *.xlsx")])
        if not path:
            return
        try:
            reqs = parse_print_requests(path, mode=self.v_mode.get().strip())
            self.import_path = path
            self.pending_import_requests = reqs
            self.clear_print_table()
            for r in reqs:
                fcnt, vcnt = self._counts_for_mode(r.mode, r.quantity)
                try:
                    tpl = self._resolve_template(r.ref_code, getattr(r, "color_code", ""), getattr(r, "textile_name", ""))
                    etiq = tpl.label_code
                    status = "Pronto para imprimir"
                except Exception as e:
                    etiq = "-"
                    status = f"ERRO: {e}"
                ref_display = r.ref_code
                if getattr(r, "color_code", ""):
                    ref_display = f"{r.ref_code} / COR {r.color_code}"
                self._add_print_row(ref_display, etiq, getattr(r, "textile_name", "-"), r.size, r.quantity, r.mode, fcnt, vcnt, status)
            self.lbl_import.configure(text=path)
            self._refresh_print_summary()
            messagebox.showinfo("Importado", f"Arquivo carregado: {len(reqs)} linhas. Revise a tabela e clique em 'Imprimir lote'.")
        except ImportErrorReport as e:
            messagebox.showerror("Erro de importacao", "\n".join(e.errors))
        except Exception as e:
            messagebox.showerror("Erro de importacao", str(e))

    def print_imported_requests(self):
        super().print_imported_requests()
        self._refresh_print_summary()
