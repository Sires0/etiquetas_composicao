import sys
from pathlib import Path

from app.paths import TMP_DIR
from app.storage.csv_store import CsvStore
from app.domain.zpl_builder import build_front_zpl, build_back_zpl
from app.services.preview_service import fetch_labelary_png
from app.domain.constants import DPI_DEFAULT


def main() -> int:
    label_code = sys.argv[1] if len(sys.argv) > 1 else "C03"
    product_code = sys.argv[2] if len(sys.argv) > 2 else label_code
    color_code = sys.argv[3] if len(sys.argv) > 3 else ""
    size = sys.argv[4] if len(sys.argv) > 4 else "M"
    store = CsvStore("data")
    labels = {x.label_code: x for x in store.list_labels()}
    tpl = labels.get(label_code)
    if not tpl:
        print(f"ERRO: etiqueta {label_code} nao encontrada em data/labels.csv")
        return 1

    out_dir = TMP_DIR
    out_dir.mkdir(parents=True, exist_ok=True)
    slug = label_code.lower()

    parts = []
    if product_code:
        parts.append(f"REF: {product_code}")
    if color_code:
        parts.append(f"COR: {color_code}")
    if size:
        parts.append(f"TAM: {size}")
    produto_info = " - ".join(parts)
    zpl_front = build_front_zpl(tpl, dpi=DPI_DEFAULT, produto_info=produto_info)
    zpl_back = build_back_zpl(tpl, size=size, dpi=DPI_DEFAULT)

    (out_dir / f"{slug}_front.zpl").write_text(zpl_front, encoding="utf-8")
    (out_dir / f"{slug}_back.zpl").write_text(zpl_back, encoding="utf-8")

    png_front = fetch_labelary_png(zpl_front, dpi=DPI_DEFAULT, width_mm=tpl.width_mm, height_mm=tpl.height_mm, timeout=10)
    png_back = fetch_labelary_png(zpl_back, dpi=DPI_DEFAULT, width_mm=tpl.width_mm, height_mm=tpl.height_mm, timeout=10)

    if png_front:
        (out_dir / f"{slug}_front.png").write_bytes(png_front)
        print(f"OK: {out_dir / f'{slug}_front.png'}")
    else:
        print("ERRO: Labelary nao retornou frente")

    if png_back:
        (out_dir / f"{slug}_back.png").write_bytes(png_back)
        print(f"OK: {out_dir / f'{slug}_back.png'}")
    else:
        print("ERRO: Labelary nao retornou verso")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
