import io
import json
import os
import tkinter as tk
from tkinter import messagebox, ttk

from app.domain.constants import DPI_DEFAULT, PRINT_MODES, SIZE_OPTIONS
from app.domain.layout import build_back_layout, build_front_layout
from app.domain.zpl_builder import build_back_zpl, build_front_zpl
from app.paths import DATA_DIR
from app.services.of_service import OfResolvedRow, OfServiceError, build_of_rows, format_quantity
from app.services.preview_service import fetch_labelary_png
from app.services.print_service import PrintService
from app.storage.csv_store import CsvStore
from app.ui.main_window import MainWindow
from app.version import APP_VERSION

try:
    from PIL import Image, ImageTk
except Exception:
    Image = None
    ImageTk = None


class PrintWindow(MainWindow):
    def __init__(self, master):
        ttk.Frame.__init__(self, master)
        self.store = CsvStore("data")
        self.print_service = PrintService()
        self.current_preview_img = None
        self.defaults_path = ""
        self.ui_state_path = str(DATA_DIR / "ui_state_print.json")
        self._textile_options = []
        self._textile_option_by_display = {}
        self._of_rows: list[OfResolvedRow] = []
        self._of_edit_textile_options = []
        self._of_edit_option_by_display = {}
        self._of_updating_editor = False
        self._calibration_scale = 1.0
        self._calibration_drag_px = 0.0
        self._calibration_last_x = 0.0
        self._calibration_raw_images = {}
        self._calibration_photo_refs = []
        self._calibration_anchor_item = None
        self._calibration_anchor_x = 0.0
        self._correction_autosave_guard = False

        self.pack(fill="both", expand=True)
        self._build_ui()
        self._bind_ctrl_a()
        self.refresh_labels_combo()
        self._load_printers()
        self._load_ui_state()
        self._draw_calibration_preview()
        self.winfo_toplevel().title(f"Etiquetas Composicao - Impressao v{APP_VERSION}")
        self.winfo_toplevel().protocol("WM_DELETE_WINDOW", self._on_close)

    def _build_ui(self):
        outer = ttk.Frame(self)
        outer.pack(fill="both", expand=True, padx=10, pady=10)

        ttk.Label(outer, text="Impressao de Etiquetas", font=("TkDefaultFont", 14, "bold")).pack(anchor="w", pady=(0, 8))

        self.v_ref = tk.StringVar()
        self.v_color = tk.StringVar()
        self.v_textile = tk.StringVar()
        self.v_size = tk.StringVar(value="M")
        self.v_qty = tk.StringVar(value="1")
        self.v_mode = tk.StringVar(value="frente-verso-separados")
        self.v_printer = tk.StringVar()
        self.v_of_number = tk.StringVar()
        self.v_of_extra = tk.StringVar(value="10")
        self.v_of_status = tk.StringVar(value="")
        self.v_of_edit_ref = tk.StringVar()
        self.v_of_edit_color = tk.StringVar()
        self.v_of_edit_size = tk.StringVar(value="M")
        self.v_of_edit_qty = tk.StringVar()
        self.v_of_edit_textile = tk.StringVar()
        self.v_of_edit_base_qty = tk.StringVar()
        self.v_y_offset_dots = tk.StringVar(value="0")
        self.v_calibration_pending = tk.StringVar(value="Correção a aplicar: 0 dots")

        def row(parent, label, var, width=18):
            r = ttk.Frame(parent)
            r.pack(fill="x", padx=8, pady=3)
            ttk.Label(r, text=label, width=18).pack(side="left")
            ttk.Entry(r, textvariable=var, width=width).pack(side="left", fill="x", expand=True)

        notebook = ttk.Notebook(outer)
        notebook.pack(fill="both", expand=True)
        tab_manual = ttk.Frame(notebook)
        tab_of = ttk.Frame(notebook)
        tab_config = ttk.Frame(notebook)
        notebook.add(tab_of, text="Imprimir OF")
        notebook.add(tab_config, text="Configuração")
        notebook.add(tab_manual, text="Impressão Manual")
        notebook.select(tab_of)

        manual = ttk.LabelFrame(tab_manual, text="Dados")
        manual.pack(fill="x", padx=8, pady=8)

        row(manual, "REF do produto", self.v_ref)
        row(manual, "Cor do produto", self.v_color)

        rsize = ttk.Frame(manual)
        rsize.pack(fill="x", padx=8, pady=3)
        ttk.Label(rsize, text="Tamanho", width=18).pack(side="left")
        ttk.Combobox(rsize, values=SIZE_OPTIONS, textvariable=self.v_size, state="readonly", width=16).pack(side="left")

        rtextile = ttk.Frame(manual)
        rtextile.pack(fill="x", padx=8, pady=3)
        ttk.Label(rtextile, text="Tecido", width=18).pack(side="left")
        self.cmb_textile = ttk.Combobox(rtextile, textvariable=self.v_textile, state="readonly", width=28)
        self.cmb_textile.pack(side="left", fill="x", expand=True)

        row(manual, "Quantidade", self.v_qty)

        ttk.Button(tab_manual, text="Imprimir", command=self.print_manual).pack(anchor="w", padx=8, pady=(0, 6))

        self._build_of_tab(tab_of)

        mode_box = ttk.LabelFrame(tab_config, text="Configuração")
        mode_box.pack(fill="x", padx=8, pady=8)

        rmode = ttk.Frame(mode_box)
        rmode.pack(fill="x", padx=8, pady=(8, 3))
        ttk.Label(rmode, text="Modo", width=18).pack(side="left")
        ttk.Combobox(rmode, values=PRINT_MODES, textvariable=self.v_mode, state="readonly", width=22).pack(side="left")

        prow_manual = ttk.Frame(mode_box)
        prow_manual.pack(fill="x", padx=8, pady=(6, 3))
        ttk.Label(prow_manual, text="Impressora", width=18).pack(side="left")
        self.cmb_printer = ttk.Combobox(prow_manual, textvariable=self.v_printer, width=28)
        self.cmb_printer.pack(side="left", fill="x", expand=True)
        ttk.Button(prow_manual, text="Detectar", command=self._load_printers).pack(side="left", padx=(6, 0))

        offset_row = ttk.Frame(mode_box)
        offset_row.pack(fill="x", padx=8, pady=(6, 3))
        ttk.Label(offset_row, text="Correção aplicada", width=18).pack(side="left")
        ttk.Entry(offset_row, textvariable=self.v_y_offset_dots, width=8).pack(side="left")
        ttk.Label(offset_row, text="dots").pack(side="left", padx=(4, 12))
        ttk.Button(offset_row, text="Limpar correção", command=self._reset_y_offset).pack(side="left")
        ttk.Button(offset_row, text="Aplicar correção", command=self._apply_calibration_drag).pack(side="left", padx=(8, 0))
        ttk.Label(offset_row, textvariable=self.v_calibration_pending).pack(side="left", padx=(12, 0))
        ttk.Button(offset_row, text="Imprimir amostra", command=self.print_calibration_sample).pack(side="right")

        calib = ttk.Frame(tab_config)
        calib.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        self.calibration_canvas = tk.Canvas(calib, height=430, background="white", highlightthickness=1, highlightbackground="#999999")
        self.calibration_canvas.pack(fill="both", expand=True)
        self.calibration_canvas.bind("<Configure>", lambda _event: self._draw_calibration_preview())
        self.calibration_canvas.tag_bind("calib_text", "<ButtonPress-1>", self._start_calibration_drag)
        self.calibration_canvas.tag_bind("calib_text", "<B1-Motion>", self._drag_calibration_text)
        self.calibration_canvas.tag_bind("calib_text", "<ButtonRelease-1>", self._end_calibration_drag)

        calib_actions = ttk.Frame(tab_config)
        calib_actions.pack(fill="x", padx=8, pady=(0, 8))
        ttk.Button(calib_actions, text="Redesenhar amostra", command=self._draw_calibration_preview).pack(side="right")

        self.v_ref.trace_add("write", self._refresh_textile_options)
        self.v_color.trace_add("write", self._refresh_textile_options)
        self.v_of_edit_ref.trace_add("write", self._refresh_of_edit_textiles)
        self.v_of_edit_color.trace_add("write", self._refresh_of_edit_textiles)
        self.v_y_offset_dots.trace_add("write", self._autosave_y_offset)
        self._refresh_textile_options()
        self._refresh_of_edit_textiles()

    def _build_of_tab(self, parent):
        controls = ttk.Frame(parent)
        controls.pack(fill="x", padx=8, pady=(8, 4))

        row1 = ttk.Frame(controls)
        row1.pack(fill="x", pady=(0, 4))
        ttk.Label(row1, text="Numero OF", width=16).pack(side="left")
        self.ent_of_number = ttk.Entry(row1, textvariable=self.v_of_number, width=8)
        self.ent_of_number.pack(side="left")
        self.ent_of_number.bind("<Return>", lambda _event: self.fetch_of_rows())
        ttk.Button(row1, text="Buscar OF", command=self.fetch_of_rows).pack(side="left", padx=(8, 0))

        row2 = ttk.Frame(controls)
        row2.pack(fill="x")
        ttk.Label(row2, text="Porcentagem extra", width=16).pack(side="left")
        ttk.Entry(row2, textvariable=self.v_of_extra, width=8).pack(side="left")
        ttk.Button(row2, text="Imprimir OF", command=self.print_of_rows).pack(side="left", padx=(8, 0))

        ttk.Label(parent, textvariable=self.v_of_status).pack(anchor="w", padx=8, pady=(0, 6))

        grid_wrap = ttk.Frame(parent)
        grid_wrap.pack(fill="both", expand=True, padx=8, pady=6)
        cols = ("sel", "ref", "cor", "tam", "qtd_base", "qtd_final", "tecido", "etiq")
        self.tr_of = ttk.Treeview(grid_wrap, columns=cols, show="headings")
        self.tr_of.heading("sel", text="✓")
        self.tr_of.heading("ref", text="REF")
        self.tr_of.heading("cor", text="Cor")
        self.tr_of.heading("tam", text="Tam")
        self.tr_of.heading("qtd_base", text="Qtd base")
        self.tr_of.heading("qtd_final", text="Qtd final")
        self.tr_of.heading("tecido", text="Tecido")
        self.tr_of.heading("etiq", text="ETIQ")
        self.tr_of.column("sel", width=34, anchor="center", stretch=False)
        self.tr_of.column("ref", width=80, anchor="center")
        self.tr_of.column("cor", width=90, anchor="center")
        self.tr_of.column("tam", width=60, anchor="center")
        self.tr_of.column("qtd_base", width=80, anchor="center")
        self.tr_of.column("qtd_final", width=80, anchor="center")
        self.tr_of.column("tecido", width=260, anchor="w")
        self.tr_of.column("etiq", width=60, anchor="center")
        sy = ttk.Scrollbar(grid_wrap, orient="vertical", command=self.tr_of.yview)
        self.tr_of.configure(yscrollcommand=sy.set)
        self.tr_of.pack(side="left", fill="both", expand=True)
        sy.pack(side="right", fill="y")
        self.tr_of.bind("<<TreeviewSelect>>", self._on_select_of_row)
        self.tr_of.bind("<Double-1>", self._on_double_click_of_row)

        edit = ttk.Frame(parent)
        edit.pack(fill="x", padx=8, pady=(0, 8))

        line1 = ttk.Frame(edit)
        line1.pack(fill="x", pady=(0, 4))
        ttk.Label(line1, text="REF", width=10).pack(side="left")
        ttk.Entry(line1, textvariable=self.v_of_edit_ref, width=12).pack(side="left")
        ttk.Label(line1, text="Cor", width=6).pack(side="left", padx=(8, 0))
        ttk.Entry(line1, textvariable=self.v_of_edit_color, width=12).pack(side="left")
        ttk.Label(line1, text="Qtd final", width=8).pack(side="left", padx=(8, 0))
        ttk.Entry(line1, textvariable=self.v_of_edit_qty, width=12).pack(side="left")
        ttk.Label(line1, text="Tamanho", width=8).pack(side="left", padx=(8, 0))
        ttk.Combobox(line1, values=SIZE_OPTIONS, textvariable=self.v_of_edit_size, state="readonly", width=10).pack(side="left")

        line2 = ttk.Frame(edit)
        line2.pack(fill="x", pady=4)
        ttk.Label(line2, text="Tecido", width=10).pack(side="left")
        self.cmb_of_textile = ttk.Combobox(line2, textvariable=self.v_of_edit_textile, state="readonly", width=42)
        self.cmb_of_textile.pack(side="left", fill="x", expand=True)
        ttk.Button(line2, text="Atualizar linha", command=self.apply_of_row_edits).pack(side="left", padx=(8, 0))

    def _load_ui_state(self):
        if not os.path.exists(self.ui_state_path):
            return
        try:
            with open(self.ui_state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
        except Exception:
            return
        if not isinstance(state, dict):
            return
        self.v_mode.set(str(state.get("mode", self.v_mode.get()) or self.v_mode.get()))
        self.v_printer.set(str(state.get("printer", self.v_printer.get()) or self.v_printer.get()))
        self.v_of_extra.set(str(state.get("of_extra_percent", self.v_of_extra.get()) or self.v_of_extra.get()))
        self.v_y_offset_dots.set(str(state.get("label_y_offset_dots", self.v_y_offset_dots.get()) or "0"))
        self._sync_print_y_offset()

    def _save_ui_state(self):
        state = {
            "mode": self.v_mode.get().strip(),
            "printer": self.v_printer.get().strip(),
            "of_extra_percent": self.v_of_extra.get().strip(),
            "label_y_offset_dots": self._current_y_offset(),
        }
        os.makedirs(os.path.dirname(self.ui_state_path), exist_ok=True)
        with open(self.ui_state_path, "w", encoding="utf-8") as f:
            json.dump(state, f, ensure_ascii=False, indent=2)

    def _current_y_offset(self) -> int:
        try:
            return int(float((self.v_y_offset_dots.get().strip() or "0").replace(",", ".")))
        except Exception:
            return 0

    def _set_y_offset(self, value: int) -> None:
        value = int(value)
        self._correction_autosave_guard = True
        try:
            self.v_y_offset_dots.set(str(value))
            self.print_service.label_y_offset_dots = value
        finally:
            self._correction_autosave_guard = False

    def _sync_print_y_offset(self) -> None:
        self.print_service.label_y_offset_dots = self._current_y_offset()

    def _autosave_y_offset(self, *_args) -> None:
        if self._correction_autosave_guard:
            return
        self._sync_print_y_offset()
        self._save_ui_state()
        self._update_calibration_pending()
        self.after_idle(self._draw_calibration_preview)

    def _reset_y_offset(self) -> None:
        self._set_y_offset(0)
        self._calibration_drag_px = 0.0
        self._update_calibration_pending()

    def _on_close(self):
        try:
            self._save_ui_state()
        finally:
            self.winfo_toplevel().destroy()

    def _sample_template_for_calibration(self):
        labels = getattr(self, "labels_by_code", {}) or {}
        options = self.store.list_product_textiles_for_ref("30154")
        if options:
            four_line = [opt for opt in options if opt.label_code == "L03"]
            pool = four_line or options
            candidates = [labels.get(opt.label_code) for opt in pool if labels.get(opt.label_code)]
        else:
            candidates = list(labels.values())
        if not candidates:
            return None

        def score(tpl) -> tuple[int, int]:
            parts = [tpl.tecido_principal or "", tpl.forro or "", tpl.bojo or ""]
            line_count = sum(len([x for x in p.replace(",", "\n").splitlines() if x.strip()]) for p in parts)
            char_count = sum(len(p) for p in parts)
            return line_count, char_count

        return max(candidates, key=score)

    def _draw_rotated_text_block(self, x: float, y: float, text: str, tag: tuple[str, ...], fill: str = "#222222", bold: bool = False) -> None:
        font = ("TkDefaultFont", 8, "bold" if bold else "normal")
        kwargs = {"anchor": "nw", "text": text, "fill": fill, "font": font, "tags": tag}
        try:
            self.calibration_canvas.create_text(x, y, angle=90, **kwargs)
        except Exception:
            # Older Tk builds may not support angled text; stacked text keeps the calibration drag usable.
            self.calibration_canvas.create_text(x, y, text="\n".join(text), fill=fill, font=font, tags=tag, anchor="nw")

    def _map_calibration_point(self, x0: float, y0: float, label_w: float, _label_h: float, dot_x: float, dot_y: float, scale: float) -> tuple[float, float]:
        return x0 + (dot_y * scale), y0 + ((label_w - dot_x) * scale)

    def _draw_layout_blocks(self, layout: dict, origin_x: float, origin_y: float, scale: float, side_tag: str) -> None:
        drag_y = self._calibration_drag_px
        canvas_w_dots = float(layout.get("canvas", {}).get("width_dots", 1) or 1)
        canvas_h_dots = float(layout.get("canvas", {}).get("height_dots", 1) or 1)
        for block in layout.get("blocks", []):
            block_x = float(block.get("x", 0))
            block_y = float(block.get("y", 0))
            x, y = self._map_calibration_point(origin_x, origin_y, canvas_w_dots, canvas_h_dots, block_x, block_y, scale)
            w = max(2, float(block.get("w", 1)) * scale)
            h = max(2, float(block.get("h", 1)) * scale)
            block_id = str(block.get("id", "block"))
            if block_id == "symbols":
                self.calibration_canvas.create_rectangle(x, y, x + h, y + w, outline="#999999", dash=(3, 2), tags=("calib_static", side_tag))
                self.calibration_canvas.create_text(x + h / 2, y + w / 2, text="SIMB.", fill="#777777", font=("TkDefaultFont", 8), tags=("calib_static", side_tag))
                continue
            text = str(block.get("text", "") or "")
            if not text:
                continue
            tag = ("calib_text", side_tag)
            if str(block.get("orientation", "") or "").upper() == "R":
                self._draw_rotated_text_block(x + drag_y, y, text, tag, bold=bool(block.get("bold", False)))
            else:
                self.calibration_canvas.create_text(
                    x + drag_y,
                    y,
                    anchor="nw",
                    text=text,
                    fill="#222222",
                    font=("TkDefaultFont", 8, "bold" if block.get("bold", False) else "normal"),
                    tags=tag,
                )

    def _calibration_labelary_images(self, tpl):
        if Image is None or ImageTk is None:
            return None
        key = (tpl.label_code, float(tpl.width_mm), float(tpl.height_mm), tpl.tecido_principal, tpl.forro, tpl.bojo)
        if key in self._calibration_raw_images:
            return self._calibration_raw_images[key]
        cache_dir = DATA_DIR / "calibration_preview_cache"
        cache_dir.mkdir(parents=True, exist_ok=True)
        front_cache = cache_dir / f"30154_002_P_{tpl.label_code}_front.png"
        back_cache = cache_dir / f"30154_002_P_{tpl.label_code}_verso.png"
        if front_cache.exists() and back_cache.exists():
            try:
                images = {
                    "back": Image.open(back_cache).convert("RGBA"),
                    "front": Image.open(front_cache).convert("RGBA"),
                }
                self._calibration_raw_images[key] = images
                return images
            except Exception:
                pass
        try:
            back_png = fetch_labelary_png(build_back_zpl(tpl, "P", DPI_DEFAULT), DPI_DEFAULT, tpl.width_mm, tpl.height_mm, timeout=4)
            front_png = fetch_labelary_png(
                build_front_zpl(tpl, DPI_DEFAULT, produto_info="REF: 30154 - COR: 002 - TAM: P"),
                DPI_DEFAULT,
                tpl.width_mm,
                tpl.height_mm,
                timeout=4,
            )
            if not back_png or not front_png:
                return None
            back_cache.write_bytes(back_png)
            front_cache.write_bytes(front_png)
            images = {
                "back": Image.open(io.BytesIO(back_png)).convert("RGBA"),
                "front": Image.open(io.BytesIO(front_png)).convert("RGBA"),
            }
            self._calibration_raw_images[key] = images
            return images
        except Exception:
            return None

    def _draw_labelary_calibration_images(self, tpl, back_x: float, top_y: float, front_x: float, draw_w: float, draw_h: float) -> bool:
        images = self._calibration_labelary_images(tpl)
        if not images:
            return False
        self._calibration_photo_refs = []
        self._calibration_anchor_item = None
        self._calibration_anchor_x = float(back_x)
        target_size = (max(1, int(round(draw_w))), max(1, int(round(draw_h))))
        for side, x in (("back", back_x), ("front", front_x)):
            im = images[side].rotate(90, expand=True).resize(target_size, Image.Resampling.LANCZOS)
            photo = ImageTk.PhotoImage(im)
            self._calibration_photo_refs.append(photo)
            item = self.calibration_canvas.create_image(
                x + self._calibration_drag_px,
                top_y,
                anchor="nw",
                image=photo,
                tags=("calib_text", side),
            )
            if side == "back":
                self._calibration_anchor_item = item
        return True

    def _draw_calibration_preview(self) -> None:
        canvas = getattr(self, "calibration_canvas", None)
        if canvas is None:
            return
        canvas.delete("all")
        tpl = self._sample_template_for_calibration()
        if not tpl:
            canvas.create_text(20, 20, anchor="nw", text="Sem etiqueta de exemplo carregada.", fill="#444444")
            return

        canvas_w = max(360, canvas.winfo_width() or 500)
        canvas_h = max(320, canvas.winfo_height() or 430)
        raw_images = self._calibration_labelary_images(tpl)
        if raw_images:
            label_w = max(raw_images["back"].height, raw_images["front"].height)
            label_h = max(raw_images["back"].width, raw_images["front"].width)
        else:
            label_w = max(1, float(tpl.height_mm) * DPI_DEFAULT / 25.4)
            label_h = max(1, float(tpl.width_mm) * DPI_DEFAULT / 25.4)
        scale = min((canvas_w - 72) / (label_w * 2), (canvas_h - 72) / label_h)
        scale = max(0.12, min(scale, 1.2))
        self._calibration_scale = scale
        draw_w = label_w * scale
        draw_h = label_h * scale
        x0 = (canvas_w - (draw_w * 2)) / 2
        y0 = 38
        top_y = y0
        bottom_y = y0
        front_x = x0 + draw_w

        used_labelary = self._draw_labelary_calibration_images(tpl, x0, top_y, front_x, draw_w, draw_h)
        canvas.create_rectangle(x0, top_y, x0 + draw_w, top_y + draw_h, outline="#111111", width=2)
        canvas.create_rectangle(front_x, bottom_y, front_x + draw_w, bottom_y + draw_h, outline="#111111", width=2)
        canvas.create_line(front_x, top_y, front_x, top_y + draw_h, fill="#111111", width=2)
        canvas.create_text(x0 + 8, top_y - 8, anchor="sw", text="VERSO", fill="#555555", font=("TkDefaultFont", 8, "bold"))
        canvas.create_text(front_x + 8, bottom_y - 8, anchor="sw", text="FRENTE", fill="#555555", font=("TkDefaultFont", 8, "bold"))
        canvas.create_text(
            x0,
            y0 + draw_h + 10,
            anchor="nw",
            text=f"Amostra: {tpl.label_code} | produto 30154 cor 002 tam P | correção atual {self._current_y_offset()} dots",
            fill="#555555",
            font=("TkDefaultFont", 8),
        )

        if not used_labelary:
            canvas.create_text(x0, y0 - 14, anchor="nw", text="Labelary indisponivel; usando esquema local.", fill="#AA6600", font=("TkDefaultFont", 8))
            try:
                back_layout = build_back_layout(tpl, "P", DPI_DEFAULT)
                front_layout = build_front_layout(tpl, DPI_DEFAULT, produto_info="REF: 30154 - COR: 002 - TAM: P")
                self._draw_layout_blocks(back_layout, x0, top_y, scale, "verso")
                self._draw_layout_blocks(front_layout, front_x, bottom_y, scale, "frente")
            except Exception as exc:
                canvas.create_text(20, 20, anchor="nw", text=f"Falha ao montar amostra: {exc}", fill="#AA0000")
        self._update_calibration_pending()

    def _calibration_delta_dots(self) -> int:
        if not self._calibration_scale:
            return 0
        px = self._calibration_drag_px
        if self._calibration_anchor_item is not None:
            try:
                coords = self.calibration_canvas.coords(self._calibration_anchor_item)
                if coords:
                    px = float(coords[0]) - float(self._calibration_anchor_x)
                    self._calibration_drag_px = px
            except Exception:
                pass
        return int(round(px / self._calibration_scale))

    def _update_calibration_pending(self) -> None:
        dragged = self._calibration_delta_dots()
        correction = int(round(-dragged * 1.25))
        self.v_calibration_pending.set(
            f"Correção a aplicar: {correction:+d} dots"
        )

    def _start_calibration_drag(self, event) -> None:
        self._calibration_last_x = float(event.x)

    def _drag_calibration_text(self, event) -> None:
        dx = float(event.x) - self._calibration_last_x
        self._calibration_last_x = float(event.x)
        self._calibration_drag_px += dx
        self.calibration_canvas.move("calib_text", dx, 0)
        self._update_calibration_pending()

    def _end_calibration_drag(self, _event) -> None:
        self._update_calibration_pending()

    def _reset_calibration_drag_visual(self) -> None:
        current_px = self._calibration_drag_px
        if self._calibration_anchor_item is not None:
            try:
                coords = self.calibration_canvas.coords(self._calibration_anchor_item)
                if coords:
                    current_px = float(coords[0]) - float(self._calibration_anchor_x)
            except Exception:
                pass
        if current_px:
            try:
                self.calibration_canvas.move("calib_text", -current_px, 0)
            except Exception:
                pass
        self._calibration_drag_px = 0.0

    def _apply_calibration_drag(self) -> None:
        correction = int(round(-self._calibration_delta_dots() * 1.25))
        if correction:
            new_offset = self._current_y_offset() + correction
            self._set_y_offset(new_offset)
        self._reset_calibration_drag_visual()
        self._update_calibration_pending()
        self._save_ui_state()
        self._draw_calibration_preview()

    def print_calibration_sample(self) -> None:
        tpl = self._sample_template_for_calibration()
        if not tpl:
            messagebox.showerror("Erro", "Etiqueta de amostra nao encontrada.")
            return
        try:
            from app.domain.models import PrintRequest

            row_count = max(1, int(getattr(tpl, "labels_per_row", 6) or 6))
            req = PrintRequest(
                ref_code="30154",
                color_code="002",
                size="P",
                quantity=row_count,
                mode="frente-verso-separados",
                textile_name="TRILOBAL",
                company="lua morena",
            )
            self._run_print_requests([req], direct=True)
        except Exception as e:
            messagebox.showerror("Erro de impressao", str(e))

    def _display_textile_option(self, option, option_pool) -> str:
        textile = (getattr(option, "textile_name", "") or "").strip()
        color_type = (getattr(option, "color_type", "") or "").strip().upper()
        company = (getattr(option, "company", "") or "").strip()
        display = textile
        if color_type:
            display = f"{display} [{color_type}]"
        if company and len({o.company for o in option_pool}) > 1:
            display = f"{company.title()} - {display}"
        siblings = [
            o for o in option_pool
            if (getattr(o, "textile_name", "") or "").strip().lower() == textile.lower()
            and (getattr(o, "color_type", "") or "").strip().upper() == color_type
            and (getattr(o, "company", "") or "").strip().lower() == company.lower()
        ]
        if len(siblings) > 1:
            suffix = self._textile_variant_suffix(option)
            display = f"{display} - {suffix}"
        return display

    def _textile_variant_suffix(self, option) -> str:
        tpl = self.labels_by_code.get(getattr(option, "label_code", ""))
        if not tpl:
            return (getattr(option, "label_code", "") or "").strip() or "variante"
        parts = []
        if tpl.forro:
            parts.append("forro")
        if tpl.bojo:
            parts.append("bojo")
        if not parts:
            parts.append("principal")
        return " + ".join(parts)

    def _refresh_textile_options(self, *_args):
        ref_code = self.v_ref.get().strip()
        color_code = self.v_color.get().strip()
        if not ref_code:
            options = []
        else:
            options = self.store.list_product_textiles_for_ref(ref_code)
        self._textile_options = options
        self._textile_option_by_display = {}

        displays = []
        for opt in options:
            display = self._display_textile_option(opt, options)
            displays.append(display)
            self._textile_option_by_display[display] = opt

        self.cmb_textile["values"] = displays
        self.cmb_textile.configure(state="readonly" if displays else "disabled")
        selected_display = ""
        if options:
            match = None
            company_guess = options[0].company if len({o.company for o in options}) == 1 else ""
            from app.services.textile_importer import classify_color_type

            classified = classify_color_type(company_guess, color_code, "")
            if color_code:
                for opt in options:
                    if opt.color_type and (opt.color_type in color_code.upper() or opt.color_type == classified):
                        match = opt
                        break
            if match is None:
                match = options[0]
            selected_display = self._display_textile_option(match, options)

        if self.v_textile.get().strip() != selected_display:
            self.v_textile.set(selected_display)

    def _selected_textile_option(self):
        display = self.v_textile.get().strip()
        if display and display in self._textile_option_by_display:
            return self._textile_option_by_display[display]
        if len(self._textile_options) == 1:
            return self._textile_options[0]
        return None

    def _refresh_of_edit_textiles(self, *_args, force: bool = False):
        if self._of_updating_editor and not force:
            return
        ref_code = self.v_of_edit_ref.get().strip()
        options = self.store.list_product_textiles_for_ref(ref_code) if ref_code else []
        self._of_edit_textile_options = options
        self._of_edit_option_by_display = {}
        displays = []
        for opt in options:
            display = self._display_textile_option(opt, options)
            displays.append(display)
            self._of_edit_option_by_display[display] = opt
        self.cmb_of_textile["values"] = displays
        self.cmb_of_textile.configure(state="readonly" if displays else "disabled")

    def _selected_of_textile_option(self):
        display = self.v_of_edit_textile.get().strip()
        if display and display in self._of_edit_option_by_display:
            return self._of_edit_option_by_display[display]
        if len(self._of_edit_textile_options) == 1:
            return self._of_edit_textile_options[0]
        return None

    def _populate_of_tree(self):
        for item in self.tr_of.get_children():
            self.tr_of.delete(item)
        for idx, row in enumerate(self._of_rows):
            textile = row.textile_option.textile_name if row.textile_option else ""
            self.tr_of.insert(
                "",
                "end",
                iid=str(idx),
                values=(
                    "✓" if row.selected else "",
                    row.ref_code,
                    row.color_code,
                    row.size,
                    format_quantity(row.base_quantity),
                    row.final_quantity,
                    textile,
                    row.label_code,
                ),
            )

    def fetch_of_rows(self):
        numero = self.v_of_number.get().strip()
        try:
            extra = float((self.v_of_extra.get().strip() or "0").replace(",", "."))
        except Exception:
            messagebox.showerror("Erro", "Percentual extra invalido.")
            return
        try:
            payload, rows = build_of_rows(self.store, numero, extra)
        except OfServiceError as e:
            messagebox.showerror("Erro da OF", str(e))
            return
        except Exception as e:
            messagebox.showerror("Erro da OF", str(e))
            return
        self._of_rows = rows
        self._populate_of_tree()
        of_info = payload.get("of") or {}
        self.v_of_status.set(
            f"OF {of_info.get('numero', numero)} carregada: {len(rows)} item(ns), produto {of_info.get('produto_codigo', '')} {of_info.get('produto_descricao', '')}".strip()
        )
        if rows:
            self.tr_of.selection_set("0")
            self._on_select_of_row()

    def _toggle_of_row_selected(self, idx: int):
        if idx < 0 or idx >= len(self._of_rows):
            return
        row = self._of_rows[idx]
        row.selected = not row.selected
        self._populate_of_tree()
        self.tr_of.selection_set(str(idx))
        self._on_select_of_row()

    def _toggle_all_of_rows(self):
        if not self._of_rows:
            return
        mark_all = not all(row.selected for row in self._of_rows)
        for row in self._of_rows:
            row.selected = mark_all
        self._populate_of_tree()
        current = self.tr_of.selection()
        if current:
            self.tr_of.selection_set(current[0])
            self._on_select_of_row()

    def _on_double_click_of_row(self, event):
        region = self.tr_of.identify("region", event.x, event.y)
        if region == "heading":
            column = self.tr_of.identify_column(event.x)
            if column == "#1":
                self._toggle_all_of_rows()
                return "break"
            return None
        row_id = self.tr_of.identify_row(event.y)
        if row_id:
            self._toggle_of_row_selected(int(row_id))
            return "break"
        return None

    def _on_select_of_row(self, _event=None):
        sel = self.tr_of.selection()
        if not sel:
            return
        idx = int(sel[0])
        if idx < 0 or idx >= len(self._of_rows):
            return
        row = self._of_rows[idx]
        self._of_updating_editor = True
        try:
            self.v_of_edit_ref.set(row.ref_code)
            self.v_of_edit_color.set(row.color_code)
            self.v_of_edit_size.set(row.size)
            self.v_of_edit_base_qty.set(format_quantity(row.base_quantity))
            self.v_of_edit_qty.set(str(row.final_quantity))
            self._refresh_of_edit_textiles(force=True)
            if row.textile_option:
                pool = self._of_edit_textile_options or [row.textile_option]
                self.v_of_edit_textile.set(self._display_textile_option(row.textile_option, pool))
            else:
                self.v_of_edit_textile.set("")
        finally:
            self._of_updating_editor = False

    def apply_of_row_edits(self):
        sel = self.tr_of.selection()
        if not sel:
            messagebox.showerror("Erro", "Selecione uma linha da OF.")
            return
        idx = int(sel[0])
        row = self._of_rows[idx]
        try:
            qty = int(float((self.v_of_edit_qty.get().strip() or "0").replace(",", ".")))
        except Exception:
            messagebox.showerror("Erro", "Quantidade final invalida.")
            return
        if qty <= 0:
            messagebox.showerror("Erro", "Quantidade final deve ser positiva.")
            return
        row.ref_code = self.v_of_edit_ref.get().strip()
        row.color_code = self.v_of_edit_color.get().strip()
        row.size = self.v_of_edit_size.get().strip().upper()
        row.final_quantity = qty
        option = self._selected_of_textile_option()
        row.textile_option = option
        row.company = option.company if option else ""
        row.label_code = option.label_code if option else ""
        row.status = "OK manual" if option else "Sem tecido correspondente"
        self._populate_of_tree()
        self.tr_of.selection_set(str(idx))
        self._on_select_of_row()

    def print_of_rows(self):
        if not self._of_rows:
            messagebox.showerror("Erro", "Nenhuma OF carregada.")
            return
        unresolved = []
        requests = []
        for row in self._of_rows:
            if not row.selected:
                continue
            if not row.textile_option:
                unresolved.append(f"{row.ref_code} cor {row.color_code} tam {row.size}: sem tecido")
                continue
            if row.final_quantity <= 0:
                unresolved.append(f"{row.ref_code} cor {row.color_code} tam {row.size}: quantidade invalida")
                continue
            requests.append(row.to_print_request(self.v_mode.get().strip()))
        if unresolved:
            messagebox.showerror("Erro", "Corrija as linhas antes de imprimir:\n" + "\n".join(unresolved[:12]))
            return
        try:
            self._run_print_requests(requests, direct=True)
            self.v_of_status.set(f"Impressao da OF executada para {len(requests)} linha(s).")
        except Exception as e:
            messagebox.showerror("Erro de impressao", str(e))

    def _run_print_requests(self, requests, direct: bool):
        self._sync_print_y_offset()
        return super()._run_print_requests(requests, direct)

    def print_manual(self):
        try:
            qty = int(self.v_qty.get())
            if qty <= 0:
                raise ValueError("Quantidade deve ser positiva.")
            selected_textile = self._selected_textile_option()
            if self._textile_options and not selected_textile:
                raise ValueError("Selecione um tecido para o produto.")
            from app.domain.models import PrintRequest

            req = PrintRequest(
                ref_code=self.v_ref.get().strip(),
                size=self.v_size.get().strip().upper(),
                quantity=qty,
                mode=self.v_mode.get().strip(),
                color_code=self.v_color.get().strip(),
                textile_name=selected_textile.textile_name if selected_textile else "",
                company=selected_textile.company if selected_textile else "",
            )
            self._run_print_requests([req], direct=True)
        except Exception as e:
            messagebox.showerror("Erro de impressao", str(e))

    def _refresh_print_summary(self):
        return None

    def _add_print_row(self, *args, **kwargs):
        return None

    def clear_print_table(self):
        return None
