from __future__ import annotations

import csv
from dataclasses import replace
from pathlib import Path
from typing import Iterable

from openpyxl import load_workbook

from app.domain.constants import SIZE_OPTIONS
from app.domain.models import LabelTemplate, ProductTextileOption
from app.storage.csv_store import CsvStore

COMPANY_ALIASES = {
    "la playa": ("La Playa", "la playa", "C"),
    "lua morena": ("lua morena", "lua morena", "L"),
}

DEFAULT_SYMBOLS = [
    "lavar_30.png",
    "nao_alvejar_extra.png",
    "secadora_baixa_extra.png",
    "passar_media.png",
    "nao_lavar_seco_extra.png",
]

COMPOSITION_HEADER_MAP = {
    "MODELO": "MODELO",
    "TECIDO": "TECIDO",
    "TECIDO PRINCIPAL": "TECIDO PRINCIPAL",
    "FORRO:": "FORRO",
    "FORRO": "FORRO",
    "BOJO:": "BOJO",
    "BOJO": "BOJO",
    "COR": "COR",
}


def normalize_text(value: object) -> str:
    text = str(value or "").strip()
    return " ".join(text.split())


def normalize_company_name(value: str) -> str:
    raw = normalize_text(value).lower()
    raw = raw.replace("_", " ")
    return " ".join(raw.split())


def classify_color_type(company_name: str, color_value: str, fallback: str = "") -> str:
    company_key = normalize_company_name(company_name)
    color_text = normalize_text(color_value)
    fallback_type = normalize_text(fallback).upper()
    if company_key == "la playa" and color_text.startswith("3"):
        return "ESTAMPADO"
    if fallback_type in {"LISO", "ESTAMPADO"}:
        return fallback_type
    if color_text:
        upper = color_text.upper()
        if "ESTAMP" in upper:
            return "ESTAMPADO"
        if "LISO" in upper:
            return "LISO"
    return fallback_type


def company_defaults(company_name: str) -> dict:
    company_key = normalize_company_name(company_name)
    if company_key in COMPANY_ALIASES:
        fabricante, logo_text, prefix = COMPANY_ALIASES[company_key]
    else:
        fabricante = company_name.strip()
        logo_text = company_key
        prefix = "".join(ch for ch in company_key.upper() if ch.isalnum())[:1] or "X"
    return {
        "company_key": company_key,
        "fabricante": fabricante,
        "logo_text": logo_text,
        "prefix": prefix,
        "cnpj": "03.630.203/0001-50",
        "pais_origem": "FEITO NO BRASIL",
        "layout_preset": "etiqueta_pequena",
        "width_mm": 16.0,
        "height_mm": 55.0,
        "labels_per_row": 6,
        "text_size_mm": 3.0,
        "symbol_size_mm": 7.0,
        "left_margin_mm": 0.0,
        "top_margin_mm": 7.0,
        "right_margin_mm": 0.0,
        "bottom_margin_mm": 0.0,
        "symbol_x_offset_mm": 0.0,
        "allowed_sizes": list(SIZE_OPTIONS),
        "symbols": list(DEFAULT_SYMBOLS),
    }


def _header_index_map(rows: list[list[str]]) -> dict[str, int]:
    if not rows:
        return {}
    header = [normalize_text(c).upper() for c in rows[0]]
    return {name: idx for idx, name in enumerate(header) if name}


def _row_value(row: list[str], idx_map: dict[str, int], *names: str) -> str:
    for name in names:
        idx = idx_map.get(name.upper())
        if idx is not None and idx < len(row):
            return normalize_text(row[idx])
    return ""


def _read_workbook_rows(path: str) -> list[list[str]]:
    wb = load_workbook(path, read_only=True, data_only=True)
    try:
        ws = wb.active
        rows: list[list[str]] = []
        for r in ws.iter_rows(values_only=True):
            rows.append(["" if c is None else str(c) for c in r])
        return rows
    finally:
        wb.close()


def _normalize_composition_key(tecido_principal: str, forro: str, bojo: str) -> str:
    parts = [normalize_text(tecido_principal), normalize_text(forro), normalize_text(bojo)]
    return " | ".join(parts)


def _label_company_key(label: LabelTemplate) -> str:
    return normalize_company_name(label.fabricante or label.logo_text or "")


def _label_composition_key(label: LabelTemplate) -> str:
    return _normalize_composition_key(label.tecido_principal, label.forro, label.bojo)


def _next_label_code(prefix: str, existing: Iterable[LabelTemplate]) -> str:
    max_num = 0
    for label in existing:
        code = normalize_text(label.label_code)
        if not code.startswith(prefix):
            continue
        suffix = code[len(prefix):]
        if suffix.isdigit():
            max_num = max(max_num, int(suffix))
    return f"{prefix}{max_num + 1:02d}"


def _find_label(existing: list[LabelTemplate], company_key: str, comp_key: str) -> LabelTemplate | None:
    for label in existing:
        if _label_company_key(label) != company_key:
            continue
        if _label_composition_key(label) == comp_key:
            return label
    return None


def _build_label_template(label_code: str, company_name: str, defaults: dict, tecido_principal: str, forro: str, bojo: str) -> LabelTemplate:
    return LabelTemplate(
        label_code=label_code,
        layout_preset=defaults["layout_preset"],
        width_mm=defaults["width_mm"],
        height_mm=defaults["height_mm"],
        labels_per_row=defaults["labels_per_row"],
        text_size_mm=defaults["text_size_mm"],
        symbol_size_mm=defaults["symbol_size_mm"],
        left_margin_mm=defaults["left_margin_mm"],
        top_margin_mm=defaults["top_margin_mm"],
        right_margin_mm=defaults["right_margin_mm"],
        bottom_margin_mm=defaults["bottom_margin_mm"],
        symbol_x_offset_mm=defaults["symbol_x_offset_mm"],
        tecido_principal=tecido_principal,
        forro=forro,
        bojo=bojo,
        allowed_sizes=list(defaults["allowed_sizes"]),
        symbols=list(defaults["symbols"]),
        fabricante=defaults["fabricante"],
        cnpj=defaults["cnpj"],
        pais_origem=defaults["pais_origem"],
        logo_text=defaults["logo_text"],
        vertical_code=label_code,
    )


def import_company_textiles(xlsx_path: str, company_name: str, store: CsvStore | None = None) -> dict:
    store = store or CsvStore("data")
    defaults = company_defaults(company_name)
    rows = _read_workbook_rows(xlsx_path)
    if len(rows) < 2:
        raise ValueError("Planilha sem linhas de dados.")

    idx_map = _header_index_map(rows)
    required = ["MODELO", "TECIDO", "TECIDO PRINCIPAL"]
    missing = [name for name in required if name not in idx_map]
    if missing:
        raise ValueError(f"Cabecalho ausente: {', '.join(missing)}")

    existing_labels = store.list_labels()
    labels_by_key = {
        (_label_company_key(lbl), _label_composition_key(lbl)): lbl
        for lbl in existing_labels
    }
    product_key_seen = set()
    product_options: list[ProductTextileOption] = []
    new_labels = list(existing_labels)
    labels_created = 0

    for row in rows[1:]:
        ref = _row_value(row, idx_map, "MODELO")
        textile = _row_value(row, idx_map, "TECIDO")
        tecido_principal = _row_value(row, idx_map, "TECIDO PRINCIPAL")
        forro = _row_value(row, idx_map, "FORRO", "FORRO:")
        bojo = _row_value(row, idx_map, "BOJO", "BOJO:")
        color_type = classify_color_type(company_name, _row_value(row, idx_map, "COR"), _row_value(row, idx_map, "COR"))
        if not ref or not textile or not tecido_principal:
            continue

        comp_key = _normalize_composition_key(tecido_principal, forro, bojo)
        label_key = (defaults["company_key"], comp_key)
        label = labels_by_key.get(label_key)
        if label is None:
            label_code = _next_label_code(defaults["prefix"], new_labels)
            label = _build_label_template(label_code, company_name, defaults, tecido_principal, forro, bojo)
            new_labels.append(label)
            labels_by_key[label_key] = label
            labels_created += 1

        option_key = (
            defaults["company_key"],
            ref,
            textile,
            color_type,
            label.label_code,
        )
        if option_key in product_key_seen:
            continue
        product_key_seen.add(option_key)
        product_options.append(ProductTextileOption(
            company=defaults["company_key"],
            ref_code=ref,
            textile_name=textile,
            color_type=color_type,
            label_code=label.label_code,
        ))

    existing_other_companies = [
        opt for opt in store.list_product_textiles()
        if normalize_company_name(opt.company) != defaults["company_key"]
    ]
    store.save_labels(new_labels)
    store.save_product_textiles(existing_other_companies + product_options)

    return {
        "company": defaults["company_key"],
        "rows_read": max(0, len(rows) - 1),
        "labels_created": labels_created,
        "options_created": len(product_options),
    }
