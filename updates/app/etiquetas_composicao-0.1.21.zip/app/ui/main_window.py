import io
import json
import os
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

from app.domain.constants import DPI_DEFAULT, PRINT_MODES, SIZE_OPTIONS
from app.domain.models import LabelTemplate, Assignment, AssignmentRule, PrintRequest
from app.domain.layout import build_front_layout, build_back_layout
from app.domain.compliance import min_text_dots
from app.domain.zpl_builder import build_front_zpl, build_back_zpl
from app.domain.layout_presets import LAYOUT_PRESETS, get_layout_preset
from app.paths import DATA_DIR, SYMBOLS_DIR
from app.storage.csv_store import CsvStore
from app.services.import_service import parse_assignments, parse_print_requests, ImportErrorReport
from app.services.textile_importer import classify_color_type
from app.services.preview_service import fetch_labelary_png
from app.services.print_service import PrintService, TEST_PRINTER_NAME

try:
    from PIL import Image, ImageTk
except Exception:
    Image = None
    ImageTk = None


class MainWindow(ttk.Frame):
    def __init__(self, master):
        super().__init__(master)
        self.store = CsvStore("data")
        self.print_service = PrintService()
        self.current_preview_img = None
        self.defaults_path = str(DATA_DIR / "defaults_criacao.json")

        self.pack(fill="both", expand=True)
        self._build_ui()
        self._bind_ctrl_a()
        self._bind_global_scroll()
        self._load_defaults()
        self.refresh_labels_combo()
        self.refresh_assignment_table()
        self._load_printers()

    def _build_ui(self):
        nb = ttk.Notebook(self)
        nb.pack(fill="both", expand=True, padx=8, pady=8)

        self.tab_create = ttk.Frame(nb)
        self.tab_assign = ttk.Frame(nb)
        self.tab_print = ttk.Frame(nb)

        nb.add(self.tab_create, text="Criacao de Etiqueta")
        nb.add(self.tab_assign, text="Vinculo de Etiquetas")
        nb.add(self.tab_print, text="Impressao")

        self._build_create_tab()
        self._build_assign_tab()
        self._build_print_tab()

    def _build_create_tab(self):
        left_wrap = ttk.Frame(self.tab_create)
        left_wrap.pack(side="left", fill="both", padx=6, pady=6)
        right = ttk.Frame(self.tab_create)
        right.pack(side="left", fill="both", expand=True, padx=6, pady=6)

        self.create_canvas = tk.Canvas(left_wrap, highlightthickness=0, width=430)
        self.create_scroll = ttk.Scrollbar(left_wrap, orient="vertical", command=self.create_canvas.yview)
        self.create_canvas.configure(yscrollcommand=self.create_scroll.set)
        self.create_scroll.pack(side="right", fill="y")
        self.create_canvas.pack(side="left", fill="both", expand=True)

        left = ttk.Frame(self.create_canvas)
        self.create_canvas_window = self.create_canvas.create_window((0, 0), window=left, anchor="nw")
        left.bind("<Configure>", self._on_create_left_configure)
        self.create_canvas.bind("<Configure>", self._on_create_canvas_configure)

        def row(label, var, width=30):
            frm = ttk.Frame(left)
            frm.pack(fill="x", pady=2)
            ttk.Label(frm, text=label, width=20).pack(side="left")
            ttk.Entry(frm, textvariable=var, width=width).pack(side="left", fill="x", expand=True)

        self.v_label_code = tk.StringVar()
        self.v_width = tk.StringVar(value="47")
        self.v_height = tk.StringVar(value="25")
        self.v_labels_per_row = tk.StringVar(value="1")
        self.v_text_size = tk.StringVar(value="2.0")
        self.v_symbol_size = tk.StringVar(value="4.0")
        self.v_left_margin = tk.StringVar(value="0.0")
        self.v_top_margin = tk.StringVar(value="0.0")
        self.v_right_margin = tk.StringVar(value="0.0")
        self.v_bottom_margin = tk.StringVar(value="0.0")
        self.v_symbol_x_offset = tk.StringVar(value="-4.0")
        self.v_tecido = tk.StringVar()
        self.v_forro = tk.StringVar()
        self.v_bojo = tk.StringVar()
        self.v_sizes = tk.StringVar(value=",".join(SIZE_OPTIONS))
        self.v_fabricante = tk.StringVar()
        self.v_cnpj = tk.StringVar()
        self.v_origem = tk.StringVar(value="FEITO NO BRASIL")
        self.v_logo = tk.StringVar(value="la playa")
        self.v_vertical = tk.StringVar()
        self.preset_key_by_label = {v["label"]: k for k, v in LAYOUT_PRESETS.items()}
        self.preset_label_by_key = {k: v["label"] for k, v in LAYOUT_PRESETS.items()}
        self.v_layout_preset = tk.StringVar(value=self.preset_label_by_key.get("padrao", "Padrao"))

        sel_row = ttk.Frame(left)
        sel_row.pack(fill="x", pady=(2, 4))
        sel_row.columnconfigure(1, weight=1)
        ttk.Label(sel_row, text="Editar existente", width=20).grid(row=0, column=0, sticky="w")
        self.v_edit_code = tk.StringVar()
        self.cmb_edit_code = ttk.Combobox(sel_row, textvariable=self.v_edit_code, state="readonly", width=24)
        self.cmb_edit_code.grid(row=0, column=1, sticky="ew", padx=(0, 4))
        ttk.Button(sel_row, text="Carregar", width=12, command=self.load_selected_template).grid(row=0, column=2, sticky="e")

        layout_row = ttk.Frame(left)
        layout_row.pack(fill="x", pady=(2, 4))
        layout_row.columnconfigure(1, weight=1)
        ttk.Label(layout_row, text="Layout", width=20).grid(row=0, column=0, sticky="w")
        self.cmb_layout = ttk.Combobox(layout_row, textvariable=self.v_layout_preset, state="readonly", values=list(self.preset_key_by_label.keys()), width=24)
        self.cmb_layout.grid(row=0, column=1, sticky="ew", padx=(0, 4))
        self.cmb_layout.bind("<<ComboboxSelected>>", self._on_layout_preset_selected)

        row("Codigo da etiqueta", self.v_label_code)
        row("Tecido principal", self.v_tecido)
        row("Forro", self.v_forro)
        row("Bojo", self.v_bojo)
        row("Tamanhos (virgula)", self.v_sizes)
        row("Fabricante", self.v_fabricante)
        row("CNPJ", self.v_cnpj)
        row("Pais de origem", self.v_origem)
        row("Texto da marca", self.v_logo)
        row("Codigo vertical", self.v_vertical)

        self.dim_open = False
        dim_toggle = ttk.Frame(left)
        dim_toggle.pack(fill="x", pady=(6, 2))
        self.btn_dim_toggle = ttk.Button(dim_toggle, text="Mostrar dimensoes", command=self._toggle_dimensoes)
        self.btn_dim_toggle.pack(side="left")

        self.dim_frame = ttk.LabelFrame(left, text="Dimensoes e Escalas")
        # Comeca oculto por padrao

        row_dim = lambda label, var: self._row_in_parent(self.dim_frame, label, var)
        row_dim("Largura (mm)", self.v_width)
        row_dim("Altura (mm)", self.v_height)
        row_dim("Etiquetas por linha", self.v_labels_per_row)
        row_dim("Tamanho texto (mm)", self.v_text_size)
        row_dim("Tamanho simbologia (mm)", self.v_symbol_size)
        row_dim("Margem esquerda (mm)", self.v_left_margin)
        row_dim("Margem superior (mm)", self.v_top_margin)
        row_dim("Margem direita (mm)", self.v_right_margin)
        row_dim("Margem inferior (mm)", self.v_bottom_margin)
        row_dim("Ajuste X simbologia (mm)", self.v_symbol_x_offset)

        self.sym_frm = ttk.LabelFrame(left, text="Simbologia")
        self.sym_frm.pack(fill="x", pady=6)
        self.sym_files = self._list_symbol_files()
        self.v_symbol_pick = tk.StringVar(value=self.sym_files[0] if self.sym_files else "")
        self.sym_combo = ttk.Combobox(self.sym_frm, values=self.sym_files, textvariable=self.v_symbol_pick, state="readonly", width=34)
        self.sym_combo.pack(fill="x", padx=4, pady=4)
        self.sym_combo.bind("<<ComboboxSelected>>", lambda e: self._update_symbol_thumb())
        self.lbl_sym_img = ttk.Label(self.sym_frm, text="Sem imagem")
        self.lbl_sym_img.pack(padx=4, pady=4)
        self.after_idle(self._update_symbol_thumb)

        btn_row = ttk.Frame(self.sym_frm)
        btn_row.pack(fill="x", padx=4, pady=4)
        ttk.Button(btn_row, text="Adicionar simbolo", command=self._add_symbol).pack(side="left")
        ttk.Button(btn_row, text="Remover selecionado", command=self._remove_symbol).pack(side="left", padx=4)

        self.lst_symbols = tk.Listbox(self.sym_frm, height=5)
        self.lst_symbols.pack(fill="x", padx=4, pady=4)

        act = ttk.Frame(left)
        act.pack(fill="x", pady=8)
        ttk.Button(act, text="Salvar modelo", command=self.save_template).pack(side="left")
        ttk.Button(act, text="Preview Frente", command=lambda: self.preview("front")).pack(side="left", padx=4)
        ttk.Button(act, text="Preview Verso", command=lambda: self.preview("back")).pack(side="left", padx=4)

        self.preview_status = tk.StringVar(value="")
        ttk.Label(left, textvariable=self.preview_status, foreground="blue").pack(fill="x", pady=4)

        self.canvas = tk.Canvas(right, bg="white", width=520, height=320)
        self.canvas.pack(fill="both", expand=True)

    def _on_create_left_configure(self, _event=None):
        self.create_canvas.configure(scrollregion=self.create_canvas.bbox("all"))

    def _on_create_canvas_configure(self, event):
        self.create_canvas.itemconfigure(self.create_canvas_window, width=event.width)

    def _on_create_mousewheel(self, event):
        if not self._pointer_in_create_panel():
            return
        delta = int(-event.delta / 120) if event.delta else 0
        if delta:
            self.create_canvas.yview_scroll(delta, "units")

    def _on_create_mousewheel_linux_up(self, _event):
        if not self._pointer_in_create_panel():
            return
        self.create_canvas.yview_scroll(-1, "units")

    def _on_create_mousewheel_linux_down(self, _event):
        if not self._pointer_in_create_panel():
            return
        self.create_canvas.yview_scroll(1, "units")

    def _pointer_in_create_panel(self) -> bool:
        px = self.winfo_pointerx()
        py = self.winfo_pointery()
        try:
            w = self.winfo_containing(px, py)
        except KeyError:
            # Tk transient widgets (e.g. ttk.Combobox popdown) may not be
            # resolvable through nametowidget; treat as outside panel.
            return False
        while w is not None:
            if w == self.create_canvas:
                return True
            w = w.master
        return False

    def _bind_global_scroll(self):
        self.bind_all("<MouseWheel>", self._on_create_mousewheel, add="+")
        self.bind_all("<Button-4>", self._on_create_mousewheel_linux_up, add="+")
        self.bind_all("<Button-5>", self._on_create_mousewheel_linux_down, add="+")

    def _row_in_parent(self, parent, label, var, width=30):
        frm = ttk.Frame(parent)
        frm.pack(fill="x", pady=2)
        ttk.Label(frm, text=label, width=20).pack(side="left")
        ttk.Entry(frm, textvariable=var, width=width).pack(side="left", fill="x", expand=True)

    def _toggle_dimensoes(self):
        self.dim_open = not self.dim_open
        if self.dim_open:
            self.dim_frame.pack(fill="x", pady=4, before=self.sym_frm)
            self.btn_dim_toggle.configure(text="Ocultar dimensoes")
        else:
            self.dim_frame.pack_forget()
            self.btn_dim_toggle.configure(text="Mostrar dimensoes")

    def _build_assign_tab(self):
        top = ttk.Frame(self.tab_assign)
        top.pack(fill="x", padx=6, pady=6)
        ttk.Button(top, text="Importar CSV/XLSX", command=self.import_assignments).pack(side="left")
        ttk.Button(top, text="Recarregar", command=self.refresh_assignment_table).pack(side="left", padx=4)

        self.tr_assign = ttk.Treeview(self.tab_assign, columns=("ref", "etiq"), show="headings")
        self.tr_assign.heading("ref", text="REF")
        self.tr_assign.heading("etiq", text="ETIQ")
        self.tr_assign.pack(fill="both", expand=True, padx=6, pady=6)

        edit = ttk.Frame(self.tab_assign)
        edit.pack(fill="x", padx=6, pady=4)
        self.v_assign_ref = tk.StringVar()
        self.v_assign_etiq = tk.StringVar()
        ttk.Label(edit, text="REF", width=8).pack(side="left")
        ttk.Entry(edit, textvariable=self.v_assign_ref, width=16).pack(side="left")
        ttk.Label(edit, text="ETIQ", width=8).pack(side="left", padx=(8, 0))
        ttk.Entry(edit, textvariable=self.v_assign_etiq, width=16).pack(side="left")
        ttk.Button(edit, text="Adicionar/Atualizar", command=self.add_or_update_assignment).pack(side="left", padx=8)
        ttk.Button(edit, text="Remover REF", command=self.remove_assignment).pack(side="left")
        self.tr_assign.bind("<<TreeviewSelect>>", self._on_select_assignment)

        rules_box = ttk.LabelFrame(self.tab_assign, text="Regras (REF/COR)")
        rules_box.pack(fill="both", expand=True, padx=6, pady=(6, 8))

        self.tr_rules = ttk.Treeview(rules_box, columns=("prio", "suffix", "color", "etiq"), show="headings", height=6)
        self.tr_rules.heading("prio", text="Prioridade")
        self.tr_rules.heading("suffix", text="Sufixo REF")
        self.tr_rules.heading("color", text="Prefixo COR")
        self.tr_rules.heading("etiq", text="ETIQ")
        self.tr_rules.column("prio", width=80, anchor="center")
        self.tr_rules.column("suffix", width=120, anchor="center")
        self.tr_rules.column("color", width=120, anchor="center")
        self.tr_rules.column("etiq", width=120, anchor="center")
        self.tr_rules.pack(fill="x", padx=6, pady=6)
        self.tr_rules.bind("<<TreeviewSelect>>", self._on_select_rule)

        rule_edit = ttk.Frame(rules_box)
        rule_edit.pack(fill="x", padx=6, pady=(0, 6))
        self.v_rule_prio = tk.StringVar(value="100")
        self.v_rule_suffix = tk.StringVar()
        self.v_rule_color = tk.StringVar()
        self.v_rule_etiq = tk.StringVar()
        ttk.Label(rule_edit, text="Prio", width=6).pack(side="left")
        ttk.Entry(rule_edit, textvariable=self.v_rule_prio, width=6).pack(side="left")
        ttk.Label(rule_edit, text="Sufixo REF", width=10).pack(side="left", padx=(8, 0))
        ttk.Entry(rule_edit, textvariable=self.v_rule_suffix, width=10).pack(side="left")
        ttk.Label(rule_edit, text="Prefixo COR", width=10).pack(side="left", padx=(8, 0))
        ttk.Entry(rule_edit, textvariable=self.v_rule_color, width=10).pack(side="left")
        ttk.Label(rule_edit, text="ETIQ", width=6).pack(side="left", padx=(8, 0))
        ttk.Entry(rule_edit, textvariable=self.v_rule_etiq, width=10).pack(side="left")
        ttk.Button(rule_edit, text="Salvar regra", command=self.add_or_update_rule).pack(side="left", padx=8)
        ttk.Button(rule_edit, text="Remover regra", command=self.remove_rule).pack(side="left")

    def _build_print_tab(self):
        frm = ttk.Frame(self.tab_print)
        frm.pack(fill="x", padx=6, pady=6)
        self.pending_import_requests = []

        self.v_ref = tk.StringVar()
        self.v_color = tk.StringVar()
        self.v_textile = tk.StringVar()
        self.v_size = tk.StringVar(value="M")
        self.v_qty = tk.StringVar(value="1")
        self.v_mode = tk.StringVar(value="frente-verso-separados")
        self.v_printer = tk.StringVar()
        self._textile_options = []
        self._textile_option_by_display = {}

        def row(label, var, width=20):
            r = ttk.Frame(frm)
            r.pack(fill="x", pady=2)
            ttk.Label(r, text=label, width=16).pack(side="left")
            ttk.Entry(r, textvariable=var, width=width).pack(side="left")

        row("Codigo do produto", self.v_ref)
        row("Cor do produto", self.v_color)

        rsize = ttk.Frame(frm)
        rsize.pack(fill="x", pady=2)
        ttk.Label(rsize, text="Tamanho", width=16).pack(side="left")
        ttk.Combobox(rsize, values=SIZE_OPTIONS, textvariable=self.v_size, state="readonly", width=18).pack(side="left")

        rtextile = ttk.Frame(frm)
        rtextile.pack(fill="x", pady=2)
        ttk.Label(rtextile, text="Tecido", width=16).pack(side="left")
        self.cmb_textile = ttk.Combobox(rtextile, textvariable=self.v_textile, state="readonly", width=34)
        self.cmb_textile.pack(side="left")
        ttk.Label(frm, text="Informe o codigo do produto para carregar as opcoes de tecido.", foreground="#666").pack(anchor="w", padx=18, pady=(0, 2))

        row("Quantidade", self.v_qty)

        rmode = ttk.Frame(frm)
        rmode.pack(fill="x", pady=2)
        ttk.Label(rmode, text="Modo", width=16).pack(side="left")
        ttk.Combobox(rmode, values=PRINT_MODES, textvariable=self.v_mode, state="readonly", width=18).pack(side="left")

        prow = ttk.Frame(frm)
        prow.pack(fill="x", pady=2)
        ttk.Label(prow, text="Impressora", width=16).pack(side="left")
        self.cmb_printer = ttk.Combobox(prow, textvariable=self.v_printer, width=30)
        self.cmb_printer.pack(side="left")
        ttk.Button(prow, text="Detectar", command=self._load_printers).pack(side="left", padx=4)

        self.v_ref.trace_add("write", self._refresh_textile_options)
        self.v_color.trace_add("write", self._refresh_textile_options)
        self._refresh_textile_options()

        actions = ttk.Frame(frm)
        actions.pack(fill="x", pady=8)
        ttk.Button(actions, text="Imprimir manual", command=self.print_manual).pack(side="left")
        ttk.Button(actions, text="Importar lote CSV/XLSX", command=self.import_print_requests).pack(side="left", padx=4)
        ttk.Button(actions, text="Imprimir arquivo importado", command=self.print_imported_requests).pack(side="left", padx=4)
        ttk.Button(actions, text="Limpar tabela", command=self.clear_print_table).pack(side="left", padx=4)

        cols = ("ref", "etiq", "tam", "tecido", "qtd", "modo", "frente", "verso", "status")
        wrap = ttk.Frame(self.tab_print)
        wrap.pack(fill="both", expand=True, padx=6, pady=6)
        self.tr_print = ttk.Treeview(wrap, columns=cols, show="headings")
        self.tr_print.heading("ref", text="REF")
        self.tr_print.heading("etiq", text="ETIQ")
        self.tr_print.heading("tam", text="Tamanho")
        self.tr_print.heading("tecido", text="Tecido")
        self.tr_print.heading("qtd", text="Qtd")
        self.tr_print.heading("modo", text="Modo")
        self.tr_print.heading("frente", text="Frente")
        self.tr_print.heading("verso", text="Verso")
        self.tr_print.heading("status", text="Status")
        self.tr_print.column("ref", width=95, anchor="w")
        self.tr_print.column("etiq", width=70, anchor="center")
        self.tr_print.column("tam", width=75, anchor="center")
        self.tr_print.column("tecido", width=180, anchor="w")
        self.tr_print.column("qtd", width=55, anchor="center")
        self.tr_print.column("modo", width=190, anchor="w")
        self.tr_print.column("frente", width=65, anchor="center")
        self.tr_print.column("verso", width=65, anchor="center")
        self.tr_print.column("status", width=260, anchor="w")
        y = ttk.Scrollbar(wrap, orient="vertical", command=self.tr_print.yview)
        self.tr_print.configure(yscrollcommand=y.set)
        self.tr_print.pack(side="left", fill="both", expand=True)
        y.pack(side="right", fill="y")

    def _list_symbol_files(self):
        folder = SYMBOLS_DIR
        if not folder.is_dir():
            return []
        files = []
        for name in sorted(os.listdir(folder)):
            if name.lower().endswith((".png", ".gif", ".ppm", ".pgm")):
                files.append(name)
        return files

    def _update_symbol_thumb(self):
        name = self.v_symbol_pick.get().strip()
        if not name:
            return
        path = SYMBOLS_DIR / name
        if Image is not None and path.exists():
            img = Image.open(path).convert("RGBA")
            bg = Image.new("RGBA", img.size, (255, 255, 255, 255))
            bg.alpha_composite(img)
            img = bg.convert("RGB")
            img.thumbnail((80, 80))
            tkimg = ImageTk.PhotoImage(img)
            self.lbl_sym_img.configure(image=tkimg, text="")
            self.lbl_sym_img.image = tkimg
        else:
            self.lbl_sym_img.configure(text=name, image="")

    def _textile_display(self, option) -> str:
        textile = (getattr(option, "textile_name", "") or "").strip()
        color_type = (getattr(option, "color_type", "") or "").strip().upper()
        company = (getattr(option, "company", "") or "").strip()
        display = textile
        if color_type:
            display = f"{display} [{color_type}]"
        if company and len({o.company for o in self._textile_options}) > 1:
            display = f"{company.title()} - {display}"
        siblings = [
            o for o in self._textile_options
            if (getattr(o, "textile_name", "") or "").strip().lower() == textile.lower()
            and (getattr(o, "color_type", "") or "").strip().upper() == color_type
            and (getattr(o, "company", "") or "").strip().lower() == company.lower()
        ]
        if len(siblings) > 1:
            suffix = self._textile_variant_suffix(option)
            display = f"{display} - {suffix}"
        return display

    def _textile_variant_suffix(self, option) -> str:
        tpl = self.labels_by_code.get(getattr(option, "label_code", ""))
        if not tpl:
            return (getattr(option, "label_code", "") or "").strip() or "variante"
        parts = []
        if tpl.forro:
            parts.append("forro")
        if tpl.bojo:
            parts.append("bojo")
        if not parts:
            parts.append("principal")
        return " + ".join(parts)

    def _refresh_textile_options(self, *_args):
        ref_code = self.v_ref.get().strip()
        color_code = self.v_color.get().strip()
        if not ref_code:
            options = []
        else:
            options = self.store.list_product_textiles_for_ref(ref_code)
        self._textile_options = options
        self._textile_option_by_display = {}

        displays: list[str] = []
        if options:
            for opt in options:
                display = self._textile_display(opt)
                displays.append(display)
                self._textile_option_by_display[display] = opt

        self.cmb_textile["values"] = displays
        self.cmb_textile.configure(state="readonly" if displays else "disabled")
        selected_display = ""
        if options:
            match = None
            company_guess = options[0].company if len({o.company for o in options}) == 1 else ""
            classified = classify_color_type(company_guess, color_code, "")
            if color_code:
                for opt in options:
                    if opt.color_type and (
                        opt.color_type in color_code.upper()
                        or opt.color_type == classified
                    ):
                        match = opt
                        break
            if match is None:
                match = options[0]
            selected_display = self._textile_display(match)

        current = self.v_textile.get().strip()
        if current == selected_display:
            return
        self.v_textile.set(selected_display)

    def _selected_textile_option(self):
        display = self.v_textile.get().strip()
        if display and display in self._textile_option_by_display:
            return self._textile_option_by_display[display]
        if len(self._textile_options) == 1:
            return self._textile_options[0]
        return None

    def _bind_ctrl_a(self):
        def handler(event):
            w = event.widget
            if isinstance(w, (tk.Entry, ttk.Entry, ttk.Combobox)):
                w.select_range(0, "end")
                w.icursor("end")
                return "break"
            if isinstance(w, tk.Text):
                w.tag_add("sel", "1.0", "end-1c")
                return "break"
            return None

        self.bind_all("<Control-a>", handler)
        self.bind_all("<Control-A>", handler)

    def _add_symbol(self):
        s = self.v_symbol_pick.get().strip()
        if s:
            self.lst_symbols.insert("end", s)

    def _remove_symbol(self):
        sel = list(self.lst_symbols.curselection())
        for i in reversed(sel):
            self.lst_symbols.delete(i)

    def _build_template_from_form(self) -> LabelTemplate:
        code = self.v_label_code.get().strip()
        if not code:
            raise ValueError("Codigo da etiqueta e obrigatorio.")
        width_mm = float(self.v_width.get().strip())
        height_mm = float(self.v_height.get().strip())
        labels_per_row = int(self.v_labels_per_row.get().strip())
        if labels_per_row < 1:
            raise ValueError("Etiquetas por linha deve ser no minimo 1.")
        text_size_mm = float(self.v_text_size.get().strip())
        if text_size_mm < 2.0:
            raise ValueError("Tamanho do texto deve ser no minimo 2.0 mm.")
        symbol_size_mm = float(self.v_symbol_size.get().strip())
        if symbol_size_mm < 4.0:
            raise ValueError("Tamanho da simbologia deve ser no minimo 4.0 mm.")
        left_margin_mm = float(self.v_left_margin.get().strip())
        if left_margin_mm < 0.0:
            raise ValueError("Margem esquerda nao pode ser negativa.")
        top_margin_mm = float(self.v_top_margin.get().strip())
        right_margin_mm = float(self.v_right_margin.get().strip())
        bottom_margin_mm = float(self.v_bottom_margin.get().strip())
        if top_margin_mm < 0.0 or right_margin_mm < 0.0 or bottom_margin_mm < 0.0:
            raise ValueError("Margens superior/direita/inferior nao podem ser negativas.")
        symbol_x_offset_mm = float(self.v_symbol_x_offset.get().strip())
        preset_label = self.v_layout_preset.get().strip()
        layout_preset = self.preset_key_by_label.get(preset_label, "padrao")
        symbols = [self.lst_symbols.get(i) for i in range(self.lst_symbols.size())]

        tpl = LabelTemplate(
            label_code=code,
            layout_preset=layout_preset,
            width_mm=width_mm,
            height_mm=height_mm,
            labels_per_row=labels_per_row,
            text_size_mm=text_size_mm,
            symbol_size_mm=symbol_size_mm,
            left_margin_mm=left_margin_mm,
            top_margin_mm=top_margin_mm,
            right_margin_mm=right_margin_mm,
            bottom_margin_mm=bottom_margin_mm,
            symbol_x_offset_mm=symbol_x_offset_mm,
            tecido_principal=self.v_tecido.get().strip(),
            forro=self.v_forro.get().strip(),
            bojo=self.v_bojo.get().strip(),
            allowed_sizes=[x.strip().upper() for x in self.v_sizes.get().split(",") if x.strip()],
            symbols=symbols,
            fabricante=self.v_fabricante.get().strip(),
            cnpj=self.v_cnpj.get().strip(),
            pais_origem=self.v_origem.get().strip(),
            logo_text=self.v_logo.get().strip(),
            vertical_code=self.v_vertical.get().strip(),
        )
        return tpl

    def load_selected_template(self):
        code = self.v_edit_code.get().strip()
        if not code:
            messagebox.showerror("Erro", "Selecione uma etiqueta para editar.")
            return
        tpl = self.labels_by_code.get(code)
        if not tpl:
            messagebox.showerror("Erro", f"Etiqueta {code} nao encontrada.")
            return

        self.v_label_code.set(tpl.label_code)
        self.v_width.set(str(tpl.width_mm))
        self.v_height.set(str(tpl.height_mm))
        self.v_labels_per_row.set(str(getattr(tpl, "labels_per_row", 1)))
        self.v_layout_preset.set(self.preset_label_by_key.get(getattr(tpl, "layout_preset", "padrao"), self.preset_label_by_key.get("padrao", "Padrao")))
        self.v_text_size.set(str(getattr(tpl, "text_size_mm", 2.0)))
        self.v_symbol_size.set(str(getattr(tpl, "symbol_size_mm", 4.0)))
        self.v_left_margin.set(str(getattr(tpl, "left_margin_mm", 0.0)))
        self.v_top_margin.set(str(getattr(tpl, "top_margin_mm", 0.0)))
        self.v_right_margin.set(str(getattr(tpl, "right_margin_mm", 0.0)))
        self.v_bottom_margin.set(str(getattr(tpl, "bottom_margin_mm", 0.0)))
        self.v_symbol_x_offset.set(str(getattr(tpl, "symbol_x_offset_mm", -4.0)))
        self.v_tecido.set(tpl.tecido_principal)
        self.v_forro.set(tpl.forro)
        self.v_bojo.set(tpl.bojo)
        self.v_sizes.set(",".join(tpl.allowed_sizes or []))
        self.v_fabricante.set(tpl.fabricante)
        self.v_cnpj.set(tpl.cnpj)
        self.v_origem.set(tpl.pais_origem)
        self.v_logo.set(tpl.logo_text)
        self.v_vertical.set(tpl.vertical_code)

        self.lst_symbols.delete(0, "end")
        for s in (tpl.symbols or []):
            self.lst_symbols.insert("end", s)
        self._update_symbol_thumb()
        self.preview_status.set(f"Etiqueta {code} carregada para edicao.")

    def _save_defaults(self):
        payload = {
            "layout_preset": self.v_layout_preset.get().strip(),
            "width_mm": self.v_width.get().strip(),
            "height_mm": self.v_height.get().strip(),
            "labels_per_row": self.v_labels_per_row.get().strip(),
            "text_size_mm": self.v_text_size.get().strip(),
            "symbol_size_mm": self.v_symbol_size.get().strip(),
            "left_margin_mm": self.v_left_margin.get().strip(),
            "top_margin_mm": self.v_top_margin.get().strip(),
            "right_margin_mm": self.v_right_margin.get().strip(),
            "bottom_margin_mm": self.v_bottom_margin.get().strip(),
            "symbol_x_offset_mm": self.v_symbol_x_offset.get().strip(),
            "tecido_principal": self.v_tecido.get().strip(),
            "forro": self.v_forro.get().strip(),
            "bojo": self.v_bojo.get().strip(),
            "sizes": self.v_sizes.get().strip(),
            "fabricante": self.v_fabricante.get().strip(),
            "cnpj": self.v_cnpj.get().strip(),
            "origem": self.v_origem.get().strip(),
            "logo": self.v_logo.get().strip(),
            "vertical": self.v_vertical.get().strip(),
            "symbols": [self.lst_symbols.get(i) for i in range(self.lst_symbols.size())],
        }
        with open(self.defaults_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)

    def _load_defaults(self):
        if not os.path.exists(self.defaults_path):
            return
        with open(self.defaults_path, "r", encoding="utf-8") as f:
            p = json.load(f)
        self.v_layout_preset.set(p.get("layout_preset", self.v_layout_preset.get()))
        self.v_width.set(p.get("width_mm", self.v_width.get()))
        self.v_height.set(p.get("height_mm", self.v_height.get()))
        self.v_labels_per_row.set(p.get("labels_per_row", self.v_labels_per_row.get()))
        self.v_text_size.set(p.get("text_size_mm", self.v_text_size.get()))
        self.v_symbol_size.set(p.get("symbol_size_mm", self.v_symbol_size.get()))
        self.v_left_margin.set(p.get("left_margin_mm", self.v_left_margin.get()))
        self.v_top_margin.set(p.get("top_margin_mm", self.v_top_margin.get()))
        self.v_right_margin.set(p.get("right_margin_mm", self.v_right_margin.get()))
        self.v_bottom_margin.set(p.get("bottom_margin_mm", self.v_bottom_margin.get()))
        self.v_symbol_x_offset.set(p.get("symbol_x_offset_mm", self.v_symbol_x_offset.get()))
        self.v_tecido.set(p.get("tecido_principal", ""))
        self.v_forro.set(p.get("forro", ""))
        self.v_bojo.set(p.get("bojo", ""))
        self.v_sizes.set(p.get("sizes", self.v_sizes.get()))
        self.v_fabricante.set(p.get("fabricante", ""))
        self.v_cnpj.set(p.get("cnpj", ""))
        self.v_origem.set(p.get("origem", self.v_origem.get()))
        self.v_logo.set(p.get("logo", self.v_logo.get()))
        self.v_vertical.set(p.get("vertical", ""))
        self.lst_symbols.delete(0, "end")
        for s in p.get("symbols", []):
            self.lst_symbols.insert("end", s)
        self.after_idle(self._update_symbol_thumb)

    def _on_layout_preset_selected(self, _event=None):
        preset_label = self.v_layout_preset.get().strip()
        preset_key = self.preset_key_by_label.get(preset_label, "padrao")
        preset = get_layout_preset(preset_key)
        self.v_width.set(str(preset.get("width_mm", self.v_width.get())))
        self.v_height.set(str(preset.get("height_mm", self.v_height.get())))
        if "labels_per_row" in preset:
            self.v_labels_per_row.set(str(preset["labels_per_row"]))
        if "text_size_mm" in preset:
            self.v_text_size.set(str(preset["text_size_mm"]))
        if "symbol_size_mm" in preset:
            self.v_symbol_size.set(str(preset["symbol_size_mm"]))
        if "symbol_x_offset_mm" in preset:
            self.v_symbol_x_offset.set(str(preset["symbol_x_offset_mm"]))

    def save_template(self):
        try:
            tpl = self._build_template_from_form()
            if not tpl.cnpj:
                raise ValueError("CNPJ e obrigatorio para o verso.")
            if not tpl.pais_origem:
                raise ValueError("Pais de origem e obrigatorio para o verso.")

            front = build_front_layout(tpl, DPI_DEFAULT)
            back = build_back_layout(tpl, "M", DPI_DEFAULT)
            min_d = min_text_dots(DPI_DEFAULT)

            self.store.save_label(tpl)
            self._save_defaults()
            self.refresh_labels_combo()
            warnings = []
            if front["errors"] or back["errors"]:
                warnings.extend(front["errors"] + back["errors"])
            if front["text_height_dots"] < min_d or back["text_height_dots"] < min_d:
                warnings.append(f"Altura de texto abaixo do minimo de 2mm ({min_d} dots).")
            if warnings:
                self.preview_status.set("Modelo salvo com avisos de layout.")
                messagebox.showwarning("Salvo com avisos", "Modelo salvo.\n\nAvisos:\n" + "\n".join(warnings[:12]))
            else:
                messagebox.showinfo("Sucesso", "Modelo de etiqueta salvo.")
        except Exception as e:
            messagebox.showerror("Erro de validacao", str(e))

    def preview(self, side: str):
        try:
            tpl = self._build_template_from_form()
            layout_warnings = []
            if side == "front":
                layout_warnings = build_front_layout(tpl, DPI_DEFAULT)["errors"]
            else:
                layout_warnings = build_back_layout(tpl, "M", DPI_DEFAULT)["errors"]
            zpl = build_front_zpl(tpl, DPI_DEFAULT) if side == "front" else build_back_zpl(tpl, size="M", dpi=DPI_DEFAULT)
            png = fetch_labelary_png(zpl, DPI_DEFAULT, tpl.width_mm, tpl.height_mm)
            self.canvas.delete("all")
            cw = max(self.canvas.winfo_width(), 520)
            ch = max(self.canvas.winfo_height(), 320)
            margin = 16
            if png and Image is not None:
                img = Image.open(io.BytesIO(png))
                max_w = cw - margin * 2
                max_h = ch - margin * 2
                scale = min(max_w / img.width, max_h / img.height)
                new_w = max(1, int(img.width * scale))
                new_h = max(1, int(img.height * scale))
                img = img.resize((new_w, new_h))
                self.current_preview_img = ImageTk.PhotoImage(img)
                x0 = (cw - new_w) // 2
                y0 = (ch - new_h) // 2
                self.canvas.create_rectangle(x0 - 1, y0 - 1, x0 + new_w + 1, y0 + new_h + 1, outline="#333", width=2)
                self.canvas.create_image(cw // 2, ch // 2, image=self.current_preview_img)
                if layout_warnings:
                    self.preview_status.set(f"Preview de {('frente' if side == 'front' else 'verso')} via Labelary com avisos")
                else:
                    self.preview_status.set(f"Preview de {('frente' if side == 'front' else 'verso')} via Labelary")
            else:
                self.canvas.create_rectangle(margin, margin, cw - margin, ch - margin, outline="#333", width=2)
                self.canvas.create_text(margin + 4, margin + 4, anchor="nw", text="Labelary indisponivel. Exibindo ZPL:", font=("TkDefaultFont", 10, "bold"))
                self.canvas.create_text(margin + 4, margin + 26, anchor="nw", text=zpl[:2000], font=("TkFixedFont", 8), width=cw - (margin + 8) * 2)
                if layout_warnings:
                    self.preview_status.set(f"Preview de {('frente' if side == 'front' else 'verso')} em fallback (ZPL) com avisos")
                else:
                    self.preview_status.set(f"Preview de {('frente' if side == 'front' else 'verso')} em fallback (ZPL)")
        except Exception as e:
            messagebox.showerror("Erro de preview", str(e))

    def refresh_labels_combo(self):
        self.labels_by_code = {x.label_code: x for x in self.store.list_labels()}
        codes = sorted(self.labels_by_code.keys())
        if hasattr(self, "cmb_edit_code"):
            self.cmb_edit_code["values"] = codes
            if codes and not self.v_edit_code.get().strip():
                self.v_edit_code.set(codes[0])

    def refresh_assignment_table(self):
        for i in self.tr_assign.get_children():
            self.tr_assign.delete(i)
        for a in self.store.list_assignments():
            self.tr_assign.insert("", "end", values=(a.ref_code, a.label_code))
        if hasattr(self, "tr_rules"):
            self.refresh_rules_table()

    def import_assignments(self):
        path = filedialog.askopenfilename(filetypes=[("CSV/XLSX", "*.csv *.xlsx")])
        if not path:
            return
        try:
            items = parse_assignments(path)
            self.store.save_assignments(items)
            self.refresh_assignment_table()
            messagebox.showinfo("Importado", f"Foram importados {len(items)} vinculos.")
        except ImportErrorReport as e:
            messagebox.showerror("Erro de importacao", "\n".join(e.errors))
        except Exception as e:
            messagebox.showerror("Erro de importacao", str(e))

    def _on_select_assignment(self, _event=None):
        sel = self.tr_assign.selection()
        if not sel:
            return
        vals = self.tr_assign.item(sel[0], "values")
        if len(vals) >= 2:
            self.v_assign_ref.set(vals[0])
            self.v_assign_etiq.set(vals[1])

    def refresh_rules_table(self):
        if not hasattr(self, "tr_rules"):
            return
        for i in self.tr_rules.get_children():
            self.tr_rules.delete(i)
        for r in self.store.list_assignment_rules():
            self.tr_rules.insert("", "end", values=(r.priority, r.ref_suffix, r.color_prefix, r.label_code))

    def _on_select_rule(self, _event=None):
        sel = self.tr_rules.selection()
        if not sel:
            return
        vals = self.tr_rules.item(sel[0], "values")
        if len(vals) >= 4:
            self.v_rule_prio.set(str(vals[0]))
            self.v_rule_suffix.set(str(vals[1]))
            self.v_rule_color.set(str(vals[2]))
            self.v_rule_etiq.set(str(vals[3]))

    def add_or_update_rule(self):
        try:
            prio = int(self.v_rule_prio.get().strip() or "100")
        except Exception:
            messagebox.showerror("Erro", "Prioridade deve ser numero inteiro.")
            return
        suffix = self.v_rule_suffix.get().strip()
        color_prefix = self.v_rule_color.get().strip()
        etiq = self.v_rule_etiq.get().strip()
        if not suffix or not etiq:
            messagebox.showerror("Erro", "Sufixo REF e ETIQ sao obrigatorios.")
            return
        rules = self.store.list_assignment_rules()
        replaced = False
        for idx, r in enumerate(rules):
            if r.priority == prio and r.ref_suffix == suffix and r.color_prefix == color_prefix:
                rules[idx] = AssignmentRule(priority=prio, ref_suffix=suffix, color_prefix=color_prefix, label_code=etiq)
                replaced = True
                break
        if not replaced:
            rules.append(AssignmentRule(priority=prio, ref_suffix=suffix, color_prefix=color_prefix, label_code=etiq))
        self.store.save_assignment_rules(rules)
        self.refresh_rules_table()
        self.preview_status.set("Regra salva.")

    def remove_rule(self):
        try:
            prio = int(self.v_rule_prio.get().strip() or "100")
        except Exception:
            messagebox.showerror("Erro", "Prioridade deve ser numero inteiro.")
            return
        suffix = self.v_rule_suffix.get().strip()
        color_prefix = self.v_rule_color.get().strip()
        if not suffix:
            messagebox.showerror("Erro", "Informe ao menos o Sufixo REF da regra.")
            return
        rules = [
            r for r in self.store.list_assignment_rules()
            if not (r.priority == prio and r.ref_suffix == suffix and r.color_prefix == color_prefix)
        ]
        self.store.save_assignment_rules(rules)
        self.refresh_rules_table()
        self.preview_status.set("Regra removida.")

    def add_or_update_assignment(self):
        ref = self.v_assign_ref.get().strip()
        etiq = self.v_assign_etiq.get().strip()
        if not ref or not etiq:
            messagebox.showerror("Erro", "REF e ETIQ sao obrigatorios.")
            return
        items = self.store.list_assignments()
        idx = {x.ref_code: x for x in items}
        idx[ref] = Assignment(ref_code=ref, label_code=etiq)
        self.store.save_assignments([idx[k] for k in sorted(idx.keys())])
        self.refresh_assignment_table()
        self.preview_status.set("Vinculo salvo.")

    def remove_assignment(self):
        ref = self.v_assign_ref.get().strip()
        if not ref:
            messagebox.showerror("Erro", "Informe um REF para remover.")
            return
        items = [x for x in self.store.list_assignments() if x.ref_code != ref]
        self.store.save_assignments(items)
        self.refresh_assignment_table()
        self.preview_status.set("Vinculo removido.")

    def _load_printers(self):
        try:
            names, default_name = self.print_service.list_printers()
            names = [TEST_PRINTER_NAME] + [name for name in names if name != TEST_PRINTER_NAME]
            preferred = self.print_service.pick_preferred_printer()
            self.cmb_printer["values"] = names
            if preferred:
                self.v_printer.set(preferred)
            elif default_name:
                self.v_printer.set(default_name)
        except Exception as e:
            self._add_print_row("-", "-", "-", "-", "-", "-", "-", "-", f"ERRO ao detectar impressoras: {e}")

    def _resolve_template(self, ref_code: str, color_code: str = "", textile_name: str = "", company: str = ""):
        ref_code = (ref_code or "").strip()
        color_code = (color_code or "").strip()
        textile_name = (textile_name or "").strip()
        company = (company or "").strip()

        options = self.store.list_product_textiles_for_ref(ref_code, company=company or None)
        if options and not company:
            companies = {o.company for o in options}
            if len(companies) == 1:
                company = next(iter(companies))
        if textile_name:
            target = textile_name.lower()
            for opt in options:
                display = self._textile_display(opt).lower()
                if opt.textile_name.strip().lower() == target or display == target:
                    tpl = self.labels_by_code.get(opt.label_code)
                    if not tpl:
                        raise ValueError(f"Etiqueta vinculada {opt.label_code} nao encontrada.")
                    return tpl
            raise ValueError(f"Tecido {textile_name} nao encontrado para o produto {ref_code}.")

        if options:
            classified = classify_color_type(company or (options[0].company if len({o.company for o in options}) == 1 else ""), color_code, "")
            if color_code:
                for opt in options:
                    if opt.color_type and (
                        opt.color_type in color_code.upper()
                        or opt.color_type == classified
                    ):
                        tpl = self.labels_by_code.get(opt.label_code)
                        if tpl:
                            return tpl
            tpl = self.labels_by_code.get(options[0].label_code)
            if tpl:
                return tpl

        for rule in sorted(self.store.list_assignment_rules(), key=lambda x: int(x.priority)):
            if rule.ref_suffix and not ref_code.endswith(rule.ref_suffix):
                continue
            if rule.color_prefix and not color_code.startswith(rule.color_prefix):
                continue
            tpl = self.labels_by_code.get(rule.label_code)
            if not tpl:
                raise ValueError(f"Etiqueta da regra nao encontrada: {rule.label_code}.")
            return tpl

        ass = {a.ref_code: a.label_code for a in self.store.list_assignments()}
        code = ass.get(ref_code)
        if not code:
            raise ValueError(f"Nenhum vinculo encontrado para REF {ref_code}.")
        tpl = self.labels_by_code.get(code)
        if not tpl:
            raise ValueError(f"Etiqueta vinculada {code} nao encontrada.")
        return tpl

    def _counts_for_mode(self, mode: str, qty: int) -> tuple[int, int]:
        if mode == "somente-frente":
            return qty, 0
        if mode == "somente-verso":
            return 0, qty
        return qty, qty

    def _add_print_row(self, ref: str, etiq: str, tecido: str, tam: str, qtd, modo: str, frente, verso, status: str):
        self.tr_print.insert("", "end", values=(ref, etiq, tam, tecido, qtd, modo, frente, verso, status))

    def _produto_info_from_request(self, request: PrintRequest) -> str:
        ref = (request.ref_code or "").strip()
        color = (getattr(request, "color_code", "") or "").strip()
        size = (request.size or "").strip().upper()
        parts = []
        if ref:
            parts.append(f"REF: {ref}")
        if color:
            parts.append(f"COR: {color}")
        if size:
            parts.append(f"TAM: {size}")
        return " - ".join(parts)

    def clear_print_table(self):
        for item in self.tr_print.get_children():
            self.tr_print.delete(item)

    def _run_print_requests(self, requests: list[PrintRequest], direct: bool):
        self.print_service.printer_name = self.v_printer.get().strip()
        front_units = []
        back_units = []
        front_sep_units = []
        back_sep_units = []
        paired_front_units = []
        paired_back_units = []
        successful = []

        for r in requests:
            fcnt, vcnt = self._counts_for_mode(r.mode, r.quantity)
            try:
                tpl = self._resolve_template(
                    r.ref_code,
                    getattr(r, "color_code", ""),
                    getattr(r, "textile_name", ""),
                    getattr(r, "company", ""),
                )
                if not tpl.cnpj or not tpl.pais_origem:
                    raise ValueError("Campos obrigatorios do verso ausentes (CNPJ/pais_origem).")
                produto_info = self._produto_info_from_request(r)
                warnings = []
                if fcnt > 0:
                    warnings.extend(build_front_layout(tpl, DPI_DEFAULT, produto_info=produto_info)["errors"])
                if vcnt > 0:
                    warnings.extend(build_back_layout(tpl, r.size, DPI_DEFAULT)["errors"])
                zpl_f = build_front_zpl(tpl, DPI_DEFAULT, produto_info=produto_info) if fcnt > 0 else None
                zpl_b = build_back_zpl(tpl, size=r.size, dpi=DPI_DEFAULT) if vcnt > 0 else None
                front_repeats = [(zpl_f, tpl)] * r.quantity if zpl_f else []
                back_repeats = [(zpl_b, tpl)] * r.quantity if zpl_b else []

                if r.mode == "somente-frente":
                    front_units.extend(front_repeats)
                elif r.mode == "somente-verso":
                    back_units.extend(back_repeats)
                elif r.mode == "frente-verso-separados":
                    front_sep_units.extend(front_repeats)
                    back_sep_units.extend(back_repeats)
                elif r.mode == "frente-e-verso":
                    paired_front_units.extend(front_repeats)
                    paired_back_units.extend(back_repeats)
                else:
                    raise ValueError(f"Modo de impressao desconhecido: {r.mode}")
                successful.append((r, tpl, fcnt, vcnt, warnings))
            except Exception as e:
                self.store.append_print_job(r.ref_code, r.size, r.quantity, r.mode, f"error: {e}")
                self._add_print_row(r.ref_code, "-", getattr(r, "textile_name", "-"), r.size, r.quantity, r.mode, fcnt, vcnt, f"ERRO: {e}")

        try:
            output_rows = []
            output_rows.extend(self.print_service.print_unit_rows(front_units, direct=direct))
            if paired_front_units or paired_back_units:
                paired_front_rows = self.print_service.row_zpls_for_units(paired_front_units)
                paired_back_rows = self.print_service.row_zpls_for_units(paired_back_units)
                for front_row, back_row in zip(paired_front_rows, paired_back_rows):
                    combined = "\n".join([front_row, back_row])
                    self.print_service.dispatch_zpls([combined], direct=direct)
                    output_rows.append(combined)
            if front_sep_units or back_sep_units:
                front_sep_rows = self.print_service.row_zpls_for_units(front_sep_units)
                back_sep_rows = self.print_service.row_zpls_for_units(back_sep_units)
                max_rows = max(len(front_sep_rows), len(back_sep_rows))
                for idx in range(max_rows):
                    chunk = []
                    if idx < len(front_sep_rows):
                        chunk.append(front_sep_rows[idx])
                    if idx < len(back_sep_rows):
                        chunk.append(back_sep_rows[idx])
                    combined = "\n".join(chunk)
                    self.print_service.dispatch_zpls([combined], direct=direct)
                    output_rows.append(combined)
            output_rows.extend(self.print_service.print_unit_rows(back_units, direct=direct))

            for r, tpl, fcnt, vcnt, warnings in successful:
                self.store.append_print_job(r.ref_code, r.size, r.quantity, r.mode, "ok")
                status = f"OK (linhas_zpl={len(output_rows)})"
                if warnings:
                    status += " com avisos"
                self._add_print_row(
                    r.ref_code, tpl.label_code, getattr(r, "textile_name", "-"), r.size, r.quantity, r.mode, fcnt, vcnt,
                    status
                )
        except Exception as e:
            for r, _tpl, _fcnt, _vcnt, _warnings in successful:
                self.store.append_print_job(r.ref_code, r.size, r.quantity, r.mode, f"error: {e}")
            self._add_print_row("-", "-", "-", "-", "-", "-", "-", "-", f"ERRO ao enviar impressao: {e}")

    def print_manual(self):
        try:
            qty = int(self.v_qty.get())
            if qty <= 0:
                raise ValueError("Quantidade deve ser positiva.")
            selected_textile = self._selected_textile_option()
            if self._textile_options and not selected_textile:
                raise ValueError("Selecione um tecido para o produto.")
            req = PrintRequest(
                ref_code=self.v_ref.get().strip(),
                size=self.v_size.get().strip().upper(),
                quantity=qty,
                mode=self.v_mode.get().strip(),
                color_code=self.v_color.get().strip(),
                textile_name=selected_textile.textile_name if selected_textile else "",
                company=selected_textile.company if selected_textile else "",
            )
            self._run_print_requests([req], direct=True)
        except Exception as e:
            messagebox.showerror("Erro de impressao", str(e))

    def import_print_requests(self):
        path = filedialog.askopenfilename(filetypes=[("CSV/XLSX", "*.csv *.xlsx")])
        if not path:
            return
        try:
            reqs = parse_print_requests(path, mode=self.v_mode.get().strip())
            self.pending_import_requests = reqs
            self.clear_print_table()
            for r in reqs:
                fcnt, vcnt = self._counts_for_mode(r.mode, r.quantity)
                try:
                    tpl = self._resolve_template(
                        r.ref_code,
                        getattr(r, "color_code", ""),
                        getattr(r, "textile_name", ""),
                        getattr(r, "company", ""),
                    )
                    etiq = tpl.label_code
                    status = "Pronto para imprimir"
                except Exception as e:
                    etiq = "-"
                    status = f"ERRO: {e}"
                self._add_print_row(r.ref_code, etiq, getattr(r, "textile_name", "-"), r.size, r.quantity, r.mode, fcnt, vcnt, status)
            messagebox.showinfo("Importado", f"Arquivo carregado: {len(reqs)} linhas. Revise a tabela e clique em 'Imprimir arquivo importado'.")
        except ImportErrorReport as e:
            messagebox.showerror("Erro de importacao", "\n".join(e.errors))
        except Exception as e:
            messagebox.showerror("Erro de importacao", str(e))

    def print_imported_requests(self):
        if not self.pending_import_requests:
            messagebox.showerror("Erro", "Nenhum arquivo importado para imprimir.")
            return
        self._run_print_requests(self.pending_import_requests, direct=True)
        messagebox.showinfo("Concluido", f"Impressao executada para {len(self.pending_import_requests)} linhas importadas.")
