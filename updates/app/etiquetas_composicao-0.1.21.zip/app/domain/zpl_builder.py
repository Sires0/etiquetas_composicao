import os
import re
from PIL import Image, ImageOps
from .compliance import mm_to_dots
from .layout_presets import get_layout_preset
from app.paths import SYMBOLS_DIR


def _escape_text(text: str) -> str:
    return (text or "").replace("^", " ").replace("~", " ")


def _wrap_lines(text: str, width_chars: int = 22) -> list[str]:
    if not text:
        return []
    normalized = _normalize_composition_lines(text)
    if normalized:
        text = "\n".join(normalized)
    out = []
    for line in text.splitlines() or [text]:
        line = line.strip()
        while len(line) > width_chars:
            cut = line.rfind(" ", 0, width_chars)
            if cut <= 0:
                cut = width_chars
            out.append(line[:cut])
            line = line[cut:].strip()
        if line:
            out.append(line)
    return out


def _normalize_composition_lines(text: str) -> list[str]:
    if not text:
        return []
    raw = " ".join((text or "").strip().split())
    raw = re.sub(r"(%)([A-Za-z])", r"\1 \2", raw)
    parts = [p.strip() for p in re.split(r"(?<!\d)(?=\d{1,3}%)", raw) if p.strip()]
    if len(parts) >= 2:
        return parts
    return [raw] if raw else []


def _normalize_composition_inline(text: str) -> str:
    parts = _normalize_composition_lines(text)
    return ", ".join(parts) if parts else ""


def _build_front_sections(template) -> list[tuple[str, str]]:
    sections = []
    preset = get_layout_preset(getattr(template, "layout_preset", "padrao"))
    front_cfg = preset["front"]
    enabled = set(front_cfg.get("sections", ["tecido_principal", "forro", "bojo"]))
    show_titles = bool(front_cfg.get("show_titles", True))
    tecido = (template.tecido_principal or "").strip()
    if "tecido_principal" in enabled and tecido:
        sections.append(("TECIDO PRINCIPAL:" if show_titles else "", tecido))
    forro = (template.forro or "").strip()
    if "forro" in enabled and forro:
        sections.append(("FORRO:" if show_titles else "", forro))
    bojo = (template.bojo or "").strip()
    if "bojo" in enabled and bojo:
        sections.append(("BOJO:" if show_titles else "", bojo))
    return sections


def _build_back_composition_sections(template) -> list[list[str]]:
    tecido_lines = _normalize_composition_lines((template.tecido_principal or "").strip())
    forro = _normalize_composition_inline((template.forro or "").strip())
    bojo = _normalize_composition_inline((template.bojo or "").strip())
    if tecido_lines:
        if len(tecido_lines) >= 2:
            tecido = [f"TECIDO PRINCIPAL: {tecido_lines[0]},", tecido_lines[1]]
        else:
            tecido = [f"TECIDO PRINCIPAL: {tecido_lines[0]}"]
    else:
        tecido = []
    return [
        tecido,
        [f"FORRO: {forro}".strip()] if forro else [],
        [f"BOJO: {bojo}".strip()] if bojo else [],
    ]


def _build_back_vertical_composition_zpl(template, w: int, h: int, back_cfg: dict, font_h: int, margin_left: int, margin_top: int, margin_right: int, dpi: int) -> str:
    content_y_offset = int(back_cfg.get("content_y_offset", 0))
    section_xs = list(back_cfg.get("section_xs", [6, 46, 86]))
    top_base = mm_to_dots(float(back_cfg["text_top_mm"]), dpi) if "text_top_mm" in back_cfg else int(back_cfg.get("text_top", 10))
    y = top_base + content_y_offset + (margin_top if bool(back_cfg.get("use_template_top_margin", True)) else 0)
    font_w = max(1, int(round(font_h * float(back_cfg.get("font_width_ratio", 0.75)))))
    advance_ratio = float(back_cfg.get("advance_ratio", 1.0))

    def vertical_advance(text: str) -> int:
        raw = len(text) * font_w
        return max(font_h, int(round(raw * advance_ratio)))

    z = ["^XA", f"^PW{w}", f"^LL{h}"]
    section_line_gap = int(back_cfg.get("section_line_gap", font_h))
    sections = _build_back_composition_sections(template)
    if bool(back_cfg.get("center_text_lanes", False)):
        lanes: list[str] = []
        for lines in sections:
            lanes.extend(line for line in lines if line.strip())
        if lanes:
            available_w = max(0, w - margin_left - margin_right - font_h)
            total_lanes_w = (len(lanes) - 1) * section_line_gap
            start_x = margin_left + max(0, (available_w - total_lanes_w) // 2) + total_lanes_w
            for lane_idx, line in enumerate(lanes):
                x = start_x - (lane_idx * section_line_gap)
                z += [f"^FO{x},{y}^A0R,{font_h},{font_w}^FD{_escape_text(line)}^FS"]
        z += ["^XZ"]
        return "\n".join(z)

    for idx, lines in enumerate(sections):
        lines = [line for line in lines if line.strip()]
        if not lines:
            continue
        x = (int(section_xs[idx]) if idx < len(section_xs) else int(section_xs[-1] - ((idx - len(section_xs) + 1) * section_line_gap))) + margin_left
        for line_idx, line in enumerate(lines):
            line_x = x - (line_idx * section_line_gap)
            z += [f"^FO{line_x},{y}^A0R,{font_h},{font_w}^FD{_escape_text(line)}^FS"]
    z += ["^XZ"]
    return "\n".join(z)


def _load_symbol_bw(symbol_name: str, target_w: int, target_h: int) -> Image.Image:
    path = SYMBOLS_DIR / symbol_name
    if not path.exists():
        raise ValueError(f"Simbolo nao encontrado: {symbol_name}")
    im = Image.open(path).convert("RGBA")
    bg = Image.new("RGBA", im.size, (255, 255, 255, 255))
    bg.alpha_composite(im)
    im = bg.convert("L")
    im = ImageOps.fit(im, (target_w, target_h), method=Image.Resampling.LANCZOS)
    im = im.point(lambda p: 0 if p < 180 else 255, mode="1")
    return im


def _img_to_gfa(im: Image.Image) -> tuple[int, int, int, str]:
    bw = im.convert("1")
    w, h = bw.size
    bytes_per_row = (w + 7) // 8
    data = bytearray()
    px = bw.load()
    for y in range(h):
        byte = 0
        bit_count = 0
        for x in range(w):
            bit = 1 if px[x, y] == 0 else 0
            byte = (byte << 1) | bit
            bit_count += 1
            if bit_count == 8:
                data.append(byte)
                byte = 0
                bit_count = 0
        if bit_count:
            byte <<= (8 - bit_count)
            data.append(byte)
    total = len(data)
    hex_data = data.hex().upper()
    return total, total, bytes_per_row, hex_data


def _zpl_body_without_label_commands(zpl: str) -> str:
    body = zpl or ""
    body = re.sub(r"\^XA", "", body)
    body = re.sub(r"\^XZ", "", body)
    body = re.sub(r"\^PW-?\d+", "", body)
    body = re.sub(r"\^LL-?\d+", "", body)
    return body.strip()


def _shift_fo_commands(zpl_body: str, x_offset: int) -> str:
    def repl(match: re.Match) -> str:
        x = int(match.group(1)) + x_offset
        y = int(match.group(2))
        return f"^FO{x},{y}"

    return re.sub(r"\^FO(-?\d+),(-?\d+)", repl, zpl_body)


def shift_zpl_y_offset(zpl: str, y_offset: int) -> str:
    if not zpl or not y_offset:
        return zpl
    # ^LH shifts the label home for every field without rewriting individual
    # coordinates. The vertical sign is opposite our correction convention.
    home_y = -int(y_offset)
    shifted = re.sub(r"\^XA", f"^XA\n^LH0,{home_y}", zpl)
    return re.sub(r"\^XZ", "^LH0,0\n^XZ", shifted)


def build_row_zpl(single_label_zpls: list[str], label_width_mm: float, label_height_mm: float, labels_per_row: int, dpi: int = 200) -> str:
    labels_per_row = max(1, int(labels_per_row or 1))
    labels = [z for z in single_label_zpls if z]
    if not labels:
        raise ValueError("Nenhum ZPL informado para compor a linha.")
    if labels_per_row == 1 and len(labels) == 1:
        return labels[0]
    if len(labels) > labels_per_row:
        raise ValueError("Quantidade de etiquetas maior que a capacidade da linha.")

    label_w = mm_to_dots(label_width_mm, dpi)
    label_h = mm_to_dots(label_height_mm, dpi)
    row_w = label_w * labels_per_row
    z = ["^XA", f"^PW{row_w}", f"^LL{label_h}"]
    for idx, label_zpl in enumerate(labels):
        body = _zpl_body_without_label_commands(label_zpl)
        z.append(_shift_fo_commands(body, idx * label_w))
    z.append("^XZ")
    return "\n".join(z)


def _build_symbols_cnpj_vertical_zpl(template, dpi: int, w: int, h: int, front_cfg: dict, font_h: int, font_w: int, margin_left: int, margin_top: int, margin_right: int, margin_bottom: int, produto_info: str = "") -> str:
    z = ["^XA", f"^PW{w}", f"^LL{h}"]
    content_y_offset = int(front_cfg.get("content_y_offset", 0))
    gap = int(front_cfg.get("symbol_col_gap", 6))
    symbol_top = int(front_cfg.get("symbol_top", 18))
    symbol_bottom = int(front_cfg.get("symbol_bottom", 18))
    box = mm_to_dots(max(4.0, float(getattr(template, "symbol_size_mm", 4.0))), dpi)
    symbol_x = int(round(w * float(front_cfg.get("symbol_x_ratio", 0.52))))
    symbol_x += mm_to_dots(float(getattr(template, "symbol_x_offset_mm", 0.0)), dpi)
    symbol_x += margin_left
    symbol_x = max(0, min(symbol_x, w - box - margin_right))

    symbols = template.symbols or []
    symbols_h = len(symbols) * box + max(0, len(symbols) - 1) * gap
    area_h = max(0, h - (symbol_top + margin_top) - (symbol_bottom + margin_bottom))
    y = symbol_top + content_y_offset + margin_top + max(0, (area_h - symbols_h) // 2)
    for symbol in symbols:
        sym_img = _load_symbol_bw(symbol, max(1, box - 4), max(1, box - 4))
        sym_img = sym_img.rotate(-90, expand=True)
        t, b, r, hd = _img_to_gfa(sym_img)
        z += [f"^FO{symbol_x+2},{y+2}^GFA,{t},{b},{r},{hd}^FS"]
        y += box + gap

    cnpj = (template.cnpj or "").strip()
    if not cnpj:
        raise ValueError("CNPJ e obrigatorio neste layout.")
    if bool(front_cfg.get("show_cnpj_prefix", True)):
        cnpj_text = f"CNPJ: {cnpj}"
    else:
        cnpj_text = cnpj
    origem = (template.pais_origem or "").strip()
    if origem:
        cnpj_text = f"{cnpj_text}   {origem}"
    produto = (produto_info or "").strip()
    cnpj_x = int(front_cfg.get("cnpj_x", 6)) + margin_left
    cnpj_y = int(front_cfg.get("cnpj_top", 10)) + content_y_offset + margin_top
    produto_x = int(front_cfg.get("produto_x", int(front_cfg.get("origem_x", cnpj_x)))) + margin_left
    produto_y = int(front_cfg.get("produto_top", int(front_cfg.get("origem_top", int(front_cfg.get("cnpj_top", 10)))))) + content_y_offset + margin_top
    cnpj_font_h = max(1, int(round(font_h * float(front_cfg.get("cnpj_font_scale", 1.0)))))
    produto_font_h = max(1, int(round(font_h * float(front_cfg.get("produto_font_scale", 1.0)))))
    requested_cnpj_font_w = int(round(cnpj_font_h * float(front_cfg.get("cnpj_font_width_ratio", font_w / font_h))))
    requested_produto_w = int(round(produto_font_h * float(front_cfg.get("produto_font_width_ratio", font_w / font_h))))
    cnpj_font_w = max(1, requested_cnpj_font_w)
    z += [f"^FO{cnpj_x},{cnpj_y}^A0R,{cnpj_font_h},{cnpj_font_w}^FD{_escape_text(cnpj_text)}^FS"]

    if produto:
        produto_w = max(1, requested_produto_w)
        z += [f"^FO{produto_x},{produto_y}^A0R,{produto_font_h},{produto_w}^FD{_escape_text(produto)}^FS"]
    z += ["^XZ"]
    return "\n".join(z)


def build_front_zpl(template, dpi: int = 200, produto_info: str = "") -> str:
    w = mm_to_dots(template.width_mm, dpi)
    h = mm_to_dots(template.height_mm, dpi)
    preset = get_layout_preset(getattr(template, "layout_preset", "padrao"))
    front_cfg = preset["front"]
    font_h = mm_to_dots(max(2.0, float(getattr(template, "text_size_mm", 2.0))), dpi)
    font_w = int(round(font_h * 0.75))
    margin_left = mm_to_dots(max(0.0, float(getattr(template, "left_margin_mm", 0.0))), dpi)
    margin_top = mm_to_dots(max(0.0, float(getattr(template, "top_margin_mm", 0.0))), dpi)
    margin_right = mm_to_dots(max(0.0, float(getattr(template, "right_margin_mm", 0.0))), dpi)
    margin_bottom = mm_to_dots(max(0.0, float(getattr(template, "bottom_margin_mm", 0.0))), dpi)
    if front_cfg.get("type") == "symbols_cnpj_vertical":
        return _build_symbols_cnpj_vertical_zpl(template, dpi, w, h, front_cfg, font_h, font_w, margin_left, margin_top, margin_right, margin_bottom, produto_info=produto_info)
    margin_x = margin_left
    x = int(front_cfg.get("text_x", 8)) + margin_x
    y = 10
    sym_x = int(round(w * float(front_cfg.get("symbol_x_ratio", 0.67)))) + margin_x
    sym_x += mm_to_dots(float(getattr(template, "symbol_x_offset_mm", -4.0)), dpi)
    sym_x = max(8, min(sym_x, w - 8))
    symbol_top = int(front_cfg.get("symbol_top", 8))
    symbol_bottom = int(front_cfg.get("symbol_bottom", 8))
    top_margin = int(front_cfg.get("top_margin", 8))
    bottom_margin = int(front_cfg.get("bottom_margin", 8))
    section_gap = int(front_cfg.get("section_gap", 4))
    title_body_gap = int(front_cfg.get("title_body_gap", 4))
    text_col_h = max(0, h - top_margin - bottom_margin)

    z = ["^XA", f"^PW{w}", f"^LL{h}"]
    sections = _build_front_sections(template)
    sections_meta = []
    total_h = 0
    for title, body in sections:
        lines = _wrap_lines(body)
        title_h = (font_h + 2) if title else 0
        gap_h = title_body_gap if title else 0
        sec_h = title_h + gap_h + len(lines) * (font_h + 2)
        sections_meta.append((title, lines, sec_h))
        total_h += sec_h
    if sections_meta:
        total_h += section_gap * (len(sections_meta) - 1)

    y = top_margin
    if total_h > 0:
        y = max(top_margin, top_margin + (text_col_h - total_h) // 2)
    for idx, (title, lines, _sec_h) in enumerate(sections_meta):
        if title:
            z += [f"^FO{x},{y}^A0N,{font_h+2},{font_w+1}^FD{_escape_text(title)}^FS"]
            y += font_h + title_body_gap
        for ln in lines:
            z += [f"^FO{x},{y}^A0N,{font_h},{font_w}^FD{_escape_text(ln)}^FS"]
            y += font_h + 2
        if idx < len(sections_meta) - 1:
            y += section_gap

    sy = 10
    min_symbol = mm_to_dots(max(4.0, float(getattr(template, "symbol_size_mm", 4.0))), dpi)
    symbol_area_h = max(0, h - symbol_top - symbol_bottom)
    symbol_area_w = max(0, w - sym_x - 8)
    cols = 1 if symbol_area_w < (min_symbol * 2 + 3) else 2
    rows = max(1, symbol_area_h // (min_symbol + 3))
    capacity = rows * cols
    box = min_symbol
    col_w = min_symbol + 3
    for idx, symbol in enumerate(template.symbols or []):
        row = idx % rows
        col = idx // rows
        sx = sym_x + (col * col_w)
        sy = symbol_top + row * (box + 3)
        sym_img = _load_symbol_bw(symbol, box - 4, box - 4)
        t, b, r, hd = _img_to_gfa(sym_img)
        z += [f"^FO{sx+2},{sy+2}^GFA,{t},{b},{r},{hd}^FS"]

    z += ["^XZ"]
    return "\n".join(z)


def build_back_zpl(template, size: str, dpi: int = 200) -> str:
    w = mm_to_dots(template.width_mm, dpi)
    h = mm_to_dots(template.height_mm, dpi)
    preset = get_layout_preset(getattr(template, "layout_preset", "padrao"))
    back_cfg = preset["back"]
    font_h = mm_to_dots(max(2.0, float(getattr(template, "text_size_mm", 2.0))), dpi)
    font_w = int(round(font_h * 0.75))
    margin_left = mm_to_dots(max(0.0, float(getattr(template, "left_margin_mm", 0.0))), dpi)
    margin_top = mm_to_dots(max(0.0, float(getattr(template, "top_margin_mm", 0.0))), dpi)
    margin_right = mm_to_dots(max(0.0, float(getattr(template, "right_margin_mm", 0.0))), dpi)
    if back_cfg.get("type") == "vertical_composition":
        return _build_back_vertical_composition_zpl(template, w, h, back_cfg, font_h, margin_left, margin_top, margin_right, dpi)
    margin_x = margin_left

    z = ["^XA", f"^PW{w}", f"^LL{h}"]
    if template.vertical_code and back_cfg.get("show_vertical_code", True):
        vx = int(back_cfg.get("vertical_x", 8)) + margin_x
        vy = int(h * float(back_cfg.get("vertical_y_ratio", 0.20)))
        z += [f"^FO{vx},{vy}^A0R,{font_h},{font_w}^FD{_escape_text(template.vertical_code)}^FS"]

    z += [f"^FO{int(w*float(back_cfg.get('size_x_ratio',0.53)))+margin_x},{int(h*float(back_cfg.get('size_y_ratio',0.12)))}^A0N,{font_h*2},{font_w*2}^FD{_escape_text(size)}^FS"]
    if back_cfg.get("show_logo", True):
        z += [f"^FO{int(w*float(back_cfg.get('logo_x_ratio',0.30)))+margin_x},{int(h*float(back_cfg.get('logo_y_ratio',0.40)))}^A0N,{font_h*2},{font_w*2}^FD{_escape_text(template.logo_text or 'LOGO')}^FS"]
    z += [f"^FO{int(w*float(back_cfg.get('cnpj_x_ratio',0.24)))+margin_x},{int(h*float(back_cfg.get('cnpj_y_ratio',0.64)))}^A0N,{font_h},{font_w}^FDCNPJ: {_escape_text(template.cnpj)}^FS"]
    z += [f"^FO{int(w*float(back_cfg.get('origem_x_ratio',0.24)))+margin_x},{int(h*float(back_cfg.get('origem_y_ratio',0.80)))}^A0N,{font_h},{font_w}^FD{_escape_text(template.pais_origem or 'FEITO NO BRASIL')}^FS"]
    z += ["^XZ"]
    return "\n".join(z)
