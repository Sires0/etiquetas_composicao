from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
import tempfile
import zipfile
from datetime import datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app.services.update_crypto import encrypt_bytes, sha256_file, sha256_hex
from app.update_config import load_update_password
from app.version import UPDATE_SCHEMA_VERSION


APP_INCLUDE = [
    "launcher_runtime.py",
    "main.py",
    "maintenance.py",
    "main.pyw",
    "maintenance.pyw",
    "requirements.txt",
    "update_config.json",
    "update_password.txt",
    "app",
    "tools",
]

DATA_INCLUDE = [
    "data/labels.csv",
    "data/product_textiles.csv",
    "data/assignments.csv",
    "data/assignment_rules.csv",
    "data/calibration_preview_cache",
    "data/of_cache.json",
    "simbologias",
]

EXCLUDE_NAMES = {
    "__pycache__",
    ".git",
    ".update_runtime",
    "tmp",
    ".codex",
    ".agents",
    ".claude",
}

TRACKED_OUTPUTS = [
    "app/version.py",
    "updates/manifest.json",
]


def log(message: str) -> None:
    print(f"[publish] {message}", flush=True)


def refresh_of_cache() -> None:
    try:
        from tools.export_local_ofs import refresh_cache_from_config

        result = refresh_cache_from_config()
        if result.get("enabled"):
            log(
                f"cache local de OFs atualizado: {result.get('of_count', 0)} OFs "
                f"({result.get('generated_at', '')})"
            )
        else:
            log("cache local de OFs desativado")
    except Exception as exc:
        cache_path = ROOT / "data" / "of_cache.json"
        if not cache_path.exists():
            raise RuntimeError(f"Falha ao gerar cache local de OFs: {exc}") from exc
        log(f"AVISO: falha ao atualizar cache local de OFs; preservando cache existente: {exc}")


def iter_relative_files(entries: list[str]) -> list[str]:
    collected: list[str] = []
    seen = set()
    for entry in entries:
        path = ROOT / entry
        if not path.exists():
            continue
        if path.is_file():
            rel = path.relative_to(ROOT).as_posix()
            if rel not in seen:
                collected.append(rel)
                seen.add(rel)
            continue
        for child in sorted(path.rglob("*")):
            rel = child.relative_to(ROOT).as_posix()
            parts = set(child.parts)
            if parts & EXCLUDE_NAMES:
                continue
            if child.is_file() and rel not in seen:
                collected.append(rel)
                seen.add(rel)
    return collected


def write_bundle(zip_path: Path, kind: str, version: str, files: list[str]) -> None:
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        zf.writestr(
            "bundle_manifest.json",
            json.dumps(
                {
                    "schema_version": UPDATE_SCHEMA_VERSION,
                    "kind": kind,
                    "version": version,
                    "files": files,
                },
                ensure_ascii=False,
                indent=2,
            ),
        )
        for rel in files:
            zf.write(ROOT / rel, rel)


def encrypt_bundle(zip_path: Path, enc_path: Path) -> tuple[str, str]:
    plaintext = zip_path.read_bytes()
    enc_path.parent.mkdir(parents=True, exist_ok=True)
    enc_path.write_bytes(encrypt_bytes(plaintext, load_update_password()))
    return sha256_file(enc_path), sha256_hex(plaintext)


def load_manifest() -> dict:
    manifest_path = ROOT / "updates" / "manifest.json"
    if manifest_path.exists():
        loaded = json.loads(manifest_path.read_text(encoding="utf-8"))
        if isinstance(loaded, dict):
            return loaded
    return {
        "schema_version": UPDATE_SCHEMA_VERSION,
        "app": {"version": "0.1.0", "forced": False, "bundle_url": "", "sha256_encrypted": "", "sha256_decrypted_zip": ""},
        "data": {"version": "0", "forced": False, "bundle_url": "", "sha256_encrypted": "", "sha256_decrypted_zip": ""},
    }


def save_manifest(manifest: dict) -> None:
    manifest_path = ROOT / "updates" / "manifest.json"
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def read_app_version() -> str:
    path = ROOT / "app" / "version.py"
    match = re.search(r'APP_VERSION = "([^"]+)"', path.read_text(encoding="utf-8"))
    if not match:
        raise ValueError("APP_VERSION nao encontrado em app/version.py.")
    return match.group(1)


def update_app_version_file(version: str) -> None:
    path = ROOT / "app" / "version.py"
    text = path.read_text(encoding="utf-8")
    updated = re.sub(r'APP_VERSION = ".*?"', f'APP_VERSION = "{version}"', text, count=1)
    path.write_text(updated, encoding="utf-8")


def next_app_version(current: str) -> str:
    parts = str(current or "").strip().split(".")
    nums = []
    for part in parts[:3]:
        nums.append(int(part) if part.isdigit() else 0)
    while len(nums) < 3:
        nums.append(0)
    nums[2] += 1
    return f"{nums[0]}.{nums[1]}.{nums[2]}"


def next_data_version(current: str) -> str:
    today = datetime.now().strftime("%Y-%m-%d")
    prefix = f"{today}-"
    if isinstance(current, str) and current.startswith(prefix):
        suffix = current[len(prefix):]
        try:
            seq = int(suffix)
        except Exception:
            seq = 0
        return f"{today}-{seq + 1:02d}"
    return f"{today}-01"


def package_app(version: str, forced: bool, manifest: dict) -> tuple[str, str]:
    update_app_version_file(version)
    files = iter_relative_files(APP_INCLUDE)
    enc_rel = f"updates/app/etiquetas_composicao-{version}.enc"
    zip_rel = f"updates/app/etiquetas_composicao-{version}.zip"
    with tempfile.TemporaryDirectory(prefix="etiquetas_app_publish_") as tmp:
        zip_path = Path(tmp) / f"etiquetas_composicao-{version}.zip"
        enc_path = ROOT / enc_rel
        write_bundle(zip_path, "app", version, files)
        zip_copy_path = ROOT / zip_rel
        zip_copy_path.parent.mkdir(parents=True, exist_ok=True)
        zip_copy_path.write_bytes(zip_path.read_bytes())
        sha_enc, sha_zip = encrypt_bundle(zip_path, enc_path)
    manifest["app"] = {
        "version": version,
        "forced": bool(forced),
        "bundle_url": f"app/etiquetas_composicao-{version}.enc",
        "manual_zip_url": f"app/etiquetas_composicao-{version}.zip",
        "sha256_encrypted": sha_enc,
        "sha256_decrypted_zip": sha_zip,
    }
    return enc_rel, zip_rel


def package_data(version: str, forced: bool, manifest: dict) -> tuple[str, str]:
    files = iter_relative_files(DATA_INCLUDE)
    enc_rel = f"updates/data/dados-{version}.enc"
    with tempfile.TemporaryDirectory(prefix="etiquetas_data_publish_") as tmp:
        zip_path = Path(tmp) / f"dados-{version}.zip"
        enc_path = ROOT / enc_rel
        write_bundle(zip_path, "data", version, files)
        sha_enc, sha_zip = encrypt_bundle(zip_path, enc_path)
    manifest["data"] = {
        "version": version,
        "forced": bool(forced),
        "bundle_url": f"data/dados-{version}.enc",
        "manual_zip_url": "",
        "sha256_encrypted": sha_enc,
        "sha256_decrypted_zip": sha_zip,
    }
    return enc_rel, ""


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Gera e prepara os updates do programa e dos dados.")
    parser.add_argument("--force", action="store_true", help="Marca programa e dados como forcados.")
    parser.add_argument("--force-app", action="store_true", help="Marca o update de programa como forcado.")
    parser.add_argument("--force-data", action="store_true", help="Marca o update de dados como forcado.")
    return parser.parse_args()


def git_run(*args: str) -> tuple[int, str, str]:
    proc = subprocess.run(
        ["git", *args],
        cwd=ROOT,
        text=True,
        capture_output=True,
    )
    return proc.returncode, proc.stdout.strip(), proc.stderr.strip()


def git_available() -> bool:
    code, _out, _err = git_run("rev-parse", "--show-toplevel")
    return code == 0


def stage_generated_files(paths: list[str]) -> str:
    unique_paths = []
    seen = set()
    for path in paths:
        norm = str(path).replace("\\", "/")
        if norm and norm not in seen:
            unique_paths.append(norm)
            seen.add(norm)
    if not git_available():
        return "Git indisponivel neste diretório; arquivos gerados sem stage automatico."
    code, _out, err = git_run("add", *unique_paths)
    if code != 0:
        return err or "Falha ao adicionar arquivos no git."
    return "Arquivos gerados e adicionados ao git."


def try_push_current_branch() -> tuple[bool, str]:
    if not git_available():
        return False, "Git indisponivel neste diretório; push ignorado."
    code, branch, err = git_run("branch", "--show-current")
    if code != 0 or not branch:
        return False, err or "Nao foi possivel descobrir a branch atual."
    code, out, err = git_run("push", "origin", branch)
    if code == 0:
        return True, out or f"Push para origin/{branch} concluido."
    return False, err or out or f"Falha ao dar push para origin/{branch}."


def commit_generated_files(app_version: str, data_version: str, force_app: bool, force_data: bool) -> tuple[bool, str]:
    if not git_available():
        return False, "Git indisponivel neste diretório; commit ignorado."
    force_bits = []
    if force_app:
        force_bits.append("app")
    if force_data:
        force_bits.append("data")
    force_suffix = f" forcado ({'+'.join(force_bits)})" if force_bits else ""
    message = f"Publica update app {app_version} data {data_version}{force_suffix}"
    code, out, err = git_run("commit", "-m", message)
    if code == 0:
        return True, out or message
    return False, err or out or "Falha ao criar commit do update."


def main() -> int:
    args = parse_args()
    log("iniciando publicacao de update")
    manifest = load_manifest()
    manifest["schema_version"] = UPDATE_SCHEMA_VERSION

    current_app_version = read_app_version()
    current_data_version = str(manifest.get("data", {}).get("version", "") or "0")
    app_version = next_app_version(current_app_version)
    data_version = next_data_version(current_data_version)
    log(f"versao atual app: {current_app_version}")
    log(f"proxima versao app: {app_version}")
    log(f"versao atual dados: {current_data_version}")
    log(f"proxima versao dados: {data_version}")

    force_app = bool(args.force or args.force_app)
    force_data = bool(args.force or args.force_data)
    log(f"flags forcadas: app={force_app} dados={force_data}")

    refresh_of_cache()

    log("gerando pacote do programa")
    app_bundle, app_zip_bundle = package_app(app_version, force_app, manifest)
    log(f"pacote do programa gerado: {app_bundle}")
    log("gerando pacote dos dados")
    data_bundle, data_zip_bundle = package_data(data_version, force_data, manifest)
    log(f"pacote dos dados gerado: {data_bundle}")
    save_manifest(manifest)
    log("manifesto atualizado")

    log("adicionando arquivos ao git")
    stage_message = stage_generated_files(TRACKED_OUTPUTS + [app_bundle, app_zip_bundle, data_bundle, data_zip_bundle])
    log(stage_message)
    log("criando commit do update")
    committed, commit_message = commit_generated_files(app_version, data_version, force_app, force_data)
    log(commit_message)
    log("tentando enviar para o remoto")
    pushed, push_message = try_push_current_branch()
    log(push_message)

    print(f"app_version={app_version}")
    print(f"data_version={data_version}")
    print(f"manifest={(ROOT / 'updates' / 'manifest.json').as_posix()}")
    print(stage_message)
    print(commit_message)
    print(push_message)
    if committed and not pushed:
        print("O commit foi criado, mas o push nao foi concluido.")
    elif not committed:
        print("Os arquivos do update foram gerados, mas o commit nao foi concluido.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
