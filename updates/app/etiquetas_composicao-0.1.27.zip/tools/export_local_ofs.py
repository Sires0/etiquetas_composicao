from __future__ import annotations

import importlib
import json
import os
import sys
import tempfile
import types
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
REPOS_ROOT = ROOT.parent.parent
CONFIG_PATH = ROOT / "tools" / "of_cache_config.json"
CACHE_PATH = ROOT / "data" / "of_cache.json"


def _load_json(path: Path) -> dict[str, Any]:
    loaded = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(loaded, dict):
        raise ValueError(f"Arquivo JSON deve conter um objeto: {path}")
    return loaded


def _load_ofservice_modules(ofservice_root: Path):
    package_name = "_etiquetas_ofservice"
    package = types.ModuleType(package_name)
    package.__path__ = [str(ofservice_root / "app")]
    package.__package__ = package_name
    sys.modules[package_name] = package
    return (
        importlib.import_module(f"{package_name}.config"),
        importlib.import_module(f"{package_name}.db"),
        importlib.import_module(f"{package_name}.repository"),
        importlib.import_module(f"{package_name}.service"),
    )


def _settings_from_local_files(config: dict[str, Any], settings_class):
    settings_path = Path(
        os.environ.get(
            "ETIQUETAS_SISPLAN_SETTINGS",
            str(REPOS_ROOT / "FabScript" / "settings.json"),
        )
    ).expanduser()
    postgres = _load_json(settings_path).get("postgres") or {}
    if not isinstance(postgres, dict):
        raise ValueError(f"Configuracao postgres ausente em {settings_path}")
    return settings_class(
        service_host="127.0.0.1",
        service_port=18095,
        bearer_token="offline-export-only",
        db_host=str(config.get("db_host_override") or postgres.get("host") or "").strip(),
        db_port=int(postgres.get("port", 5432)),
        db_name=str(postgres.get("database") or "14073P"),
        db_schema=str(postgres.get("schema") or "sisplan"),
        db_user=str(postgres.get("user") or "sisplan"),
        db_password=str(postgres.get("password") or ""),
        company_suffix=str(config.get("company_suffix") or "001"),
        db_connect_timeout=int(postgres.get("connect_timeout_seconds", 8)),
    )


def _write_cache(payload: dict[str, Any]) -> None:
    CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        "w",
        encoding="utf-8",
        dir=CACHE_PATH.parent,
        prefix="of_cache_",
        suffix=".json",
        delete=False,
    ) as handle:
        json.dump(payload, handle, ensure_ascii=False, separators=(",", ":"))
        temporary = Path(handle.name)
    temporary.replace(CACHE_PATH)


def _pick_fields(row: dict[str, Any], fields: tuple[str, ...]) -> dict[str, Any]:
    return {field: row.get(field) for field in fields}


def _minimize_payload(payload: dict[str, Any]) -> dict[str, Any]:
    of_data = payload.get("of") or {}
    return {
        "of": _pick_fields(
            of_data,
            ("numero", "produto_codigo", "produto_descricao"),
        ),
        "itens": [
            _pick_fields(
                row,
                (
                    "produto_codigo",
                    "cor_codigo",
                    "cor_descricao",
                    "tamanho",
                    "quantidade",
                ),
            )
            for row in payload.get("itens", [])
            if isinstance(row, dict)
        ],
        "consumos": [
            _pick_fields(
                row,
                (
                    "material_codigo",
                    "material_descricao",
                    "material_unidade",
                    "material_composicao",
                    "cor_codigo",
                    "cor_descricao",
                ),
            )
            for row in payload.get("consumos", [])
            if isinstance(row, dict)
        ],
        "resumo_itens": [
            _pick_fields(
                row,
                ("produto_codigo", "cor_codigo", "tamanho", "quantidade_total"),
            )
            for row in payload.get("resumo_itens", [])
            if isinstance(row, dict)
        ],
    }


def refresh_cache_from_config() -> dict[str, Any]:
    config = _load_json(CONFIG_PATH)
    generated_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
    if not bool(config.get("enabled", False)):
        result = {
            "schema_version": 1,
            "enabled": False,
            "generated_at": generated_at,
            "of_count": 0,
            "ofs": {},
        }
        _write_cache(result)
        return result

    ofservice_root = Path(
        os.environ.get("ETIQUETAS_OFSERVICE_ROOT", str(REPOS_ROOT / "OFService"))
    ).expanduser()
    config_module, db_module, repository_module, service_module = _load_ofservice_modules(ofservice_root)
    settings = _settings_from_local_files(config, config_module.Settings)
    db = db_module.SisplanDb(settings)
    repository = repository_module.OfRepository(settings, db)
    service = service_module.OfService(repository)
    lookback_days = max(1, int(config.get("lookback_days", 90)))
    suffixes = [str(value).strip() for value in config.get("product_suffixes", []) if str(value).strip()]
    if not suffixes:
        raise ValueError("product_suffixes deve conter ao menos um sufixo")

    ofs: dict[str, Any] = {}
    skipped: list[str] = []
    with db.connection() as connection:
        tables = repository._resolve_tables(connection)
        placeholders = ",".join(["%s"] * len(suffixes))
        query = (
            f'SELECT numero FROM "{settings.db_schema}"."{tables["of_header"]}" '
            f"WHERE dt_inicio >= CURRENT_DATE - %s AND RIGHT(BTRIM(codigo), 2) IN ({placeholders}) "
            "ORDER BY numero"
        )
        with connection.cursor() as cursor:
            cursor.execute(query, (lookback_days, *suffixes))
            numbers = [str(row["numero"] if isinstance(row, dict) else row[0]).strip() for row in cursor.fetchall()]

        for number in numbers:
            try:
                result = repository_module.RepositoryResult(
                    header=repository._fetch_header(connection, tables, number)[0],
                    items=repository._fetch_items(connection, tables, number),
                    consumptions=repository._fetch_consumptions(connection, tables, number),
                    tables=tables,
                )

                class SingleResultRepository:
                    def __init__(self):
                        self.settings = settings

                    def fetch_of(self, _numero: str):
                        return result

                payload = service_module.OfService(SingleResultRepository()).get_of(number)
                ofs[number] = _minimize_payload(payload.model_dump(mode="json"))
            except Exception:
                skipped.append(number)

    result = {
        "schema_version": 1,
        "enabled": True,
        "generated_at": generated_at,
        "lookback_days": lookback_days,
        "product_suffixes": suffixes,
        "of_count": len(ofs),
        "skipped_count": len(skipped),
        "skipped_ofs": skipped,
        "ofs": ofs,
    }
    _write_cache(result)
    return result


def main() -> int:
    result = refresh_cache_from_config()
    print(
        f"[of-cache] enabled={result.get('enabled')} "
        f"ofs={result.get('of_count', 0)} skipped={result.get('skipped_count', 0)} "
        f"generated_at={result.get('generated_at', '')}"
    )
    print(f"[of-cache] arquivo={CACHE_PATH}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
