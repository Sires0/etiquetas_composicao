#!/usr/bin/env python3
"""
Extrai símbolos do EPS usando Ghostscript (300 DPI) para saída de alta qualidade.

Correção vs. versão anterior:
- Células vazias no meio do grid eram atribuídas ao próximo nome, deslocando todos
  os nomes seguintes. Agora usa None como marcador de célula vazia.
- Renderização via GS em vez de PIL direto: pixels muito maiores e mais nítidos.
"""
import subprocess
import tempfile
from pathlib import Path
from PIL import Image, ImageOps

EPS = Path('simbologias/symbols.eps')
OUT = Path('simbologias')
DPI = 300
SCALE = DPI / 72  # coordenadas EPS estão em pontos PostScript (72pt = 1 pol)

# Coordenadas em espaço PIL 715×450 (y=0 no topo), serão escaladas por SCALE.
# None = célula visualmente vazia; é percorrida mas não salva.
SECOES = [
    {
        'bbox': (27, 102, 327, 264),
        'rows': 3,
        'cols': 7,
        'nomes': [
            # linha 1 – 7 símbolos
            'lavagem_normal', 'lavagem_permanente', 'lavagem_suave', 'nao_lavar', 'lavar_mao', 'nao_torcer', 'torcer',
            # linha 2 – 6 símbolos + 1 vazio
            'lavar_30', 'lavar_40', 'lavar_50', 'lavar_60', 'lavar_70', 'lavar_95', None,
            # linha 3 – 6 símbolos + 1 vazio
            'lavar_30_suave', 'lavar_40_suave', 'lavar_50_suave', 'lavar_60_suave', 'lavar_70_suave', 'lavar_95_suave', None,
        ],
        'top_ratio': 0.70,
    },
    {
        'bbox': (27, 297, 327, 420),
        'rows': 2,
        'cols': 9,
        'nomes': [
            # linha 1 – 9 símbolos
            'secar_natural', 'nao_secar', 'secar_varal', 'secar_plano', 'secar_gotejamento',
            'secar_sombra', 'varal_sombra', 'plano_sombra', 'gotejamento_sombra',
            # linha 2 – 8 símbolos + 1 vazio
            'secadora_normal', 'secadora_baixa', 'secadora_media', 'secadora_alta',
            'secadora_sem_calor', 'secadora_suave', 'secadora_muito_suave', 'nao_secadora', None,
        ],
        'top_ratio': 0.68,
    },
    {
        'bbox': (373, 20, 688, 111),
        'rows': 1,
        'cols': 7,
        'nomes': ['passar', 'nao_passar', 'passar_baixa', 'passar_media', 'passar_alta', 'vaporizar', 'nao_vaporizar'],
        'top_ratio': 0.72,
    },
    {
        'bbox': (373, 150, 688, 305),
        'rows': 2,
        'cols': 9,
        'nomes': [
            # linha 1 – 8 símbolos + 1 vazio
            'lavagem_seco_curta', 'lavagem_seco_suave', 'lavagem_seco_normal', 'lavagem_seco_sem_vapor',
            'lavagem_umida', 'nao_lavagem_umida', 'lavagem_umida_suave', 'lavagem_umida_muito_suave', None,
            # linha 2 – 9 símbolos
            'lavagem_seco', 'nao_lavagem_seco', 'solvente_A', 'solvente_F', 'solvente_F_suave',
            'solvente_F_muito_suave', 'solvente_P', 'solvente_P_suave', 'solvente_P_muito_suave',
        ],
        'top_ratio': 0.68,
    },
    {
        'bbox': (373, 355, 688, 420),
        'rows': 1,
        'cols': 6,
        'nomes': ['alvejar', 'nao_alvejar', 'sem_alvejante', 'alvejante_cloro', 'alvejante_sem_cloro', 'alvejante_sem_cloro_alt'],
        'top_ratio': 0.78,
    },
]


def trim_symbol(img: Image.Image) -> Image.Image:
    gray = img.convert('L')
    bw = gray.point(lambda p: 0 if p < 200 else 255, mode='1')
    bbox = ImageOps.invert(bw.convert('L')).getbbox()
    if bbox:
        pad = max(4, int(img.width * 0.04))
        x1 = max(0, bbox[0] - pad)
        y1 = max(0, bbox[1] - pad)
        x2 = min(img.width, bbox[2] + pad)
        y2 = min(img.height, bbox[3] + pad)
        img = img.crop((x1, y1, x2, y2))
    return img


def extract_grid(base: Image.Image, sec: dict) -> list:
    s = SCALE
    x1, y1, x2, y2 = (int(round(v * s)) for v in sec['bbox'])
    area = base.crop((x1, y1, x2, y2))
    w, h = area.size
    cw = w / sec['cols']
    ch = h / sec['rows']
    nomes = sec['nomes']
    idx = 0
    generated = []
    for r in range(sec['rows']):
        for c in range(sec['cols']):
            if idx >= len(nomes):
                return generated
            nome = nomes[idx]
            idx += 1
            if nome is None:
                continue
            cx1 = int(round(c * cw))
            cy1 = int(round(r * ch))
            cx2 = int(round((c + 1) * cw))
            cy2 = int(round((r + 1) * ch))
            cell = area.crop((cx1, cy1, cx2, cy2))
            icon_h = int(cell.height * sec['top_ratio'])
            cell = cell.crop((0, 0, cell.width, max(1, icon_h)))
            sym = trim_symbol(cell)
            if sym.width < 16 or sym.height < 16:
                print(f'  AVISO: {nome} muito pequeno ({sym.width}x{sym.height}), pulando')
                continue
            final = sym.convert('RGB')
            final.save(OUT / f'{nome}.png', optimize=True)
            generated.append(f'{nome}.png')
    return generated


def render_eps(eps_path: Path, dpi: int) -> Path:
    tmp = tempfile.NamedTemporaryFile(suffix='.png', delete=False)
    tmp.close()
    subprocess.run(
        ['gs', '-dBATCH', '-dNOPAUSE', '-sDEVICE=png16m',
         f'-r{dpi}', '-dEPSCrop', f'-sOutputFile={tmp.name}', str(eps_path)],
        check=True, capture_output=True,
    )
    return Path(tmp.name)


def main():
    if not EPS.exists():
        raise SystemExit(f'Arquivo não encontrado: {EPS}')

    print(f'Renderizando {EPS} com Ghostscript a {DPI} DPI...')
    tmp_png = render_eps(EPS, DPI)
    try:
        base = Image.open(tmp_png).convert('RGB')
        print(f'Imagem base: {base.width}x{base.height} px')
        all_files = []
        for sec in SECOES:
            files = extract_grid(base, sec)
            all_files.extend(files)
    finally:
        tmp_png.unlink(missing_ok=True)

    print(f'\nGerados {len(all_files)} arquivos em {OUT}/')
    for n in all_files:
        print(f'  {n}')


if __name__ == '__main__':
    main()
