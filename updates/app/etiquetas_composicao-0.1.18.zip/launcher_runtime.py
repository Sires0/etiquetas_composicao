from __future__ import annotations

import importlib
import json
import os
import re
import shutil
import sys
from datetime import datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parent
UPDATE_WORK_DIR = ROOT / ".update_runtime"
VERSIONS_DIR = UPDATE_WORK_DIR / "versions"
CURRENT_VERSION_PATH = UPDATE_WORK_DIR / "current_version.json"
SHARED_ROOT_ENV = "ETIQUETAS_SHARED_ROOT"

BOOTSTRAP_ENTRIES = [
    "app",
    "tools",
    "requirements.txt",
    "update_config.json",
    "update_password.txt",
]


def _read_root_app_version() -> str:
    version_path = ROOT / "app" / "version.py"
    text = version_path.read_text(encoding="utf-8")
    match = re.search(r'APP_VERSION = "([^"]+)"', text)
    if not match:
        raise RuntimeError("APP_VERSION nao encontrado em app/version.py.")
    return match.group(1).strip()


def _copy_entry(src: Path, dst: Path) -> None:
    if src.is_dir():
        if dst.exists():
            shutil.rmtree(dst)
        shutil.copytree(src, dst)
    else:
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def _read_version_from_dir(version_dir: Path) -> str:
    version_path = version_dir / "app" / "version.py"
    if not version_path.exists():
        return ""
    text = version_path.read_text(encoding="utf-8")
    match = re.search(r'APP_VERSION = "([^"]+)"', text)
    return match.group(1).strip() if match else ""


def _validate_version_dir(version_dir: Path, expected_version: str | None = None) -> bool:
    if not version_dir.is_dir():
        return False
    if not (version_dir / "app" / "launch.py").exists():
        return False
    actual_version = _read_version_from_dir(version_dir)
    if not actual_version:
        return False
    if expected_version and actual_version != expected_version:
        return False
    return True


def _read_current_version() -> dict:
    if not CURRENT_VERSION_PATH.exists():
        return {}
    try:
        payload = json.loads(CURRENT_VERSION_PATH.read_text(encoding="utf-8"))
        return payload if isinstance(payload, dict) else {}
    except Exception:
        return {}


def write_current_version(version: str, version_dir: Path) -> None:
    UPDATE_WORK_DIR.mkdir(parents=True, exist_ok=True)
    CURRENT_VERSION_PATH.write_text(
        json.dumps(
            {
                "app_version": version,
                "version_path": str(version_dir),
                "activated_at": datetime.utcnow().replace(microsecond=0).isoformat() + "Z",
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )


def _bootstrap_root_version() -> Path:
    version = _read_root_app_version()
    version_dir = VERSIONS_DIR / version
    VERSIONS_DIR.mkdir(parents=True, exist_ok=True)
    if not _validate_version_dir(version_dir, version):
        if version_dir.exists():
            shutil.rmtree(version_dir)
        version_dir.mkdir(parents=True, exist_ok=True)
        for entry in BOOTSTRAP_ENTRIES:
            src = ROOT / entry
            if not src.exists():
                continue
            _copy_entry(src, version_dir / entry)
    write_current_version(version, version_dir)
    return version_dir


def ensure_active_version() -> Path:
    current = _read_current_version()
    version = str(current.get("app_version", "") or "").strip()
    version_path = Path(str(current.get("version_path", "") or "").strip()) if current.get("version_path") else None
    if version and version_path and _validate_version_dir(version_path, version):
        return version_path
    return _bootstrap_root_version()


def activate_version(version_dir: Path) -> None:
    os.environ[SHARED_ROOT_ENV] = str(ROOT)
    version_root = str(version_dir)
    if version_root in sys.path:
        sys.path.remove(version_root)
    sys.path.insert(0, version_root)


def launch_mode(mode: str, launcher_script: str, argv: list[str] | None = None) -> None:
    os.chdir(ROOT)
    version_dir = ensure_active_version()
    activate_version(version_dir)
    launch_module = importlib.import_module("app.launch")
    args = list(argv or [])
    if mode == "print":
        launch_module.run_print_app(launcher_script, args)
        return
    if mode == "maintenance":
        launch_module.run_maintenance_app(launcher_script, args)
        return
    raise RuntimeError(f"Modo de launcher desconhecido: {mode}")
