import sys

from launcher_runtime import launch_mode


def main() -> None:
    launch_mode("print", __file__, sys.argv[1:])


if __name__ == "__main__":
    main()
