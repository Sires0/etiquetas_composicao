from __future__ import annotations

import json
from urllib.parse import urljoin

from app.paths import PROJECT_ROOT, UPDATE_CONFIG_PATH


DEFAULT_UPDATE_PASSWORD = 'M57i1?|Yj"@<'
UPDATE_PASSWORD_PATH = PROJECT_ROOT / "update_password.txt"
DEFAULT_MANIFEST_URL = "https://raw.githubusercontent.com/Sires0/etiquetas_composicao/master/updates/manifest.json"
DEFAULT_CHECK_TIMEOUT_SECONDS = 3.0
DEFAULT_BUNDLE_TIMEOUT_SECONDS = 20.0
DEFAULT_AUTO_APPLY_DATA = True
DEFAULT_AUTO_STAGE_APP = True


def load_update_password() -> str:
    if UPDATE_PASSWORD_PATH.exists():
        try:
            password = UPDATE_PASSWORD_PATH.read_text(encoding="utf-8").strip()
            if password:
                return password
        except Exception:
            pass
    return DEFAULT_UPDATE_PASSWORD


def load_update_config() -> dict:
    config = {
        "manifest_url": DEFAULT_MANIFEST_URL,
        "check_timeout_seconds": DEFAULT_CHECK_TIMEOUT_SECONDS,
        "bundle_timeout_seconds": DEFAULT_BUNDLE_TIMEOUT_SECONDS,
        "password": load_update_password(),
        "auto_apply_data": DEFAULT_AUTO_APPLY_DATA,
        "auto_stage_app": DEFAULT_AUTO_STAGE_APP,
    }
    if UPDATE_CONFIG_PATH.exists():
        try:
            loaded = json.loads(UPDATE_CONFIG_PATH.read_text(encoding="utf-8"))
            if isinstance(loaded, dict):
                config.update({k: v for k, v in loaded.items() if v not in (None, "")})
        except Exception:
            pass
    return config


def resolve_bundle_url(manifest_url: str, bundle_url: str) -> str:
    return urljoin(manifest_url, bundle_url)
