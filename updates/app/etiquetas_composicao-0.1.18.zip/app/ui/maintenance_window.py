import os
import tkinter as tk
from tkinter import ttk

from app.paths import DATA_DIR
from app.services.print_service import PrintService
from app.storage.csv_store import CsvStore
from app.ui.main_window import MainWindow


class MaintenanceWindow(MainWindow):
    def __init__(self, master):
        ttk.Frame.__init__(self, master)
        self.store = CsvStore("data")
        self.print_service = PrintService()
        self.current_preview_img = None
        self.defaults_path = str(DATA_DIR / "defaults_criacao.json")

        self.pack(fill="both", expand=True)
        self._build_ui()
        self._bind_ctrl_a()
        self._bind_global_scroll()
        self._load_defaults()
        self.refresh_labels_combo()
        self.refresh_assignment_table()

    def _build_ui(self):
        nb = ttk.Notebook(self)
        nb.pack(fill="both", expand=True, padx=8, pady=8)

        self.tab_create = ttk.Frame(nb)
        self.tab_assign = ttk.Frame(nb)

        nb.add(self.tab_create, text="Criacao de Etiqueta")
        nb.add(self.tab_assign, text="Vinculo de Etiquetas")

        self._build_create_tab()
        self._build_assign_tab()
