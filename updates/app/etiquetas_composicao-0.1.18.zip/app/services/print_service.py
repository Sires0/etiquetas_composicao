import os
import tempfile
import subprocess
from app.domain.zpl_builder import build_front_zpl, build_back_zpl, build_row_zpl, shift_zpl_y_offset

try:
    import cups
except Exception:
    cups = None

try:
    import win32print
except Exception:
    win32print = None


class PrintService:
    def __init__(self, printer_name: str = ""):
        self.printer_name = printer_name.strip()
        self.label_y_offset_dots = 0

    def list_printers(self) -> tuple[list[str], str]:
        names = []
        default_name = ""
        if cups is not None:
            try:
                conn = cups.Connection()
                printers = conn.getPrinters() or {}
                names = sorted(printers.keys())
                default_uri = conn.getDefault()
                default_name = default_uri or ""
            except Exception:
                names, default_name = self._list_printers_via_lp()
        elif win32print is not None:
            try:
                flags = win32print.PRINTER_ENUM_LOCAL | win32print.PRINTER_ENUM_CONNECTIONS
                data = win32print.EnumPrinters(flags)
                names = sorted([x[2] for x in data])
                default_name = win32print.GetDefaultPrinter() or ""
            except Exception:
                names, default_name = [], ""
        else:
            # Linux fallback when python-cups is unavailable.
            names, default_name = self._list_printers_via_lp()
        return names, default_name

    def _list_printers_via_lp(self) -> tuple[list[str], str]:
        names = []
        default_name = ""
        try:
            out = subprocess.check_output(["lpstat", "-p"], text=True, stderr=subprocess.DEVNULL)
            for line in out.splitlines():
                line = line.strip()
                if line.startswith("printer "):
                    parts = line.split()
                    if len(parts) >= 2:
                        names.append(parts[1])
        except Exception:
            pass

        if not names:
            try:
                out = subprocess.check_output(["lpoptions", "-p"], text=True, stderr=subprocess.DEVNULL)
                for line in out.splitlines():
                    line = line.strip()
                    if not line:
                        continue
                    parts = line.split()
                    if parts and parts[0] == "default" and len(parts) >= 2:
                        default_name = parts[1]
                        names.append(parts[1])
                    elif parts:
                        names.append(parts[0])
            except Exception:
                pass

        try:
            out = subprocess.check_output(["lpstat", "-d"], text=True, stderr=subprocess.DEVNULL).strip()
            # expected: "system default destination: PRINTER"
            marker = "system default destination:"
            if marker in out:
                default_name = out.split(marker, 1)[1].strip()
        except Exception:
            pass

        names = sorted({n for n in names if n})
        return names, default_name

    def pick_preferred_printer(self) -> str:
        names, default_name = self.list_printers()
        if not names:
            return ""

        zpl_names = [n for n in names if "zpl" in n.lower()]
        if default_name and "zpl" in default_name.lower():
            return default_name
        if zpl_names:
            return zpl_names[0]
        if default_name:
            return default_name
        return names[0]

    def _dispatch_raw(self, zpl: str):
        with tempfile.NamedTemporaryFile("w", suffix=".zpl", delete=False, encoding="utf-8") as tmp:
            tmp.write(zpl)
            path = tmp.name
        try:
            if cups is not None:
                conn = cups.Connection()
                target = self.printer_name or conn.getDefault()
                if not target:
                    raise RuntimeError("Nenhuma impressora CUPS disponivel.")
                conn.printFile(target, path, "Etiqueta ZPL", {})
            elif win32print is not None:
                target = self.printer_name or win32print.GetDefaultPrinter()
                if not target:
                    raise RuntimeError("Nenhuma impressora Windows disponivel.")
                with open(path, "rb") as fh:
                    raw = fh.read()
                h_printer = win32print.OpenPrinter(target)
                try:
                    h_job = win32print.StartDocPrinter(h_printer, 1, ("Etiqueta ZPL", None, "RAW"))
                    try:
                        win32print.StartPagePrinter(h_printer)
                        win32print.WritePrinter(h_printer, raw)
                        win32print.EndPagePrinter(h_printer)
                    finally:
                        win32print.EndDocPrinter(h_printer)
                finally:
                    win32print.ClosePrinter(h_printer)
            else:
                cmd = ["lp"]
                if self.printer_name:
                    cmd.extend(["-d", self.printer_name])
                cmd.append(path)
                subprocess.run(cmd, check=True)
        finally:
            if os.path.exists(path):
                os.unlink(path)

    def row_zpls_for_units(self, units: list[tuple[str, object]]) -> list[str]:
        rows = []
        current_zpls = []
        current_template = None
        current_key = None

        def flush_current():
            nonlocal current_zpls, current_template, current_key
            if not current_zpls:
                return
            labels_per_row = max(1, int(getattr(current_template, "labels_per_row", 1) or 1))
            if labels_per_row == 1:
                rows.extend(current_zpls)
            else:
                rows.append(build_row_zpl(
                    current_zpls,
                    label_width_mm=current_template.width_mm,
                    label_height_mm=current_template.height_mm,
                    labels_per_row=labels_per_row,
                ))
            current_zpls = []
            current_template = None
            current_key = None

        for unit_zpl, template in units:
            labels_per_row = max(1, int(getattr(template, "labels_per_row", 1) or 1))
            key = (float(template.width_mm), float(template.height_mm), labels_per_row)
            if labels_per_row == 1:
                flush_current()
                rows.append(unit_zpl)
                continue
            if current_key != key or len(current_zpls) >= labels_per_row:
                flush_current()
            current_key = key
            current_template = template
            current_zpls.append(unit_zpl)
            if len(current_zpls) >= labels_per_row:
                flush_current()

        flush_current()
        return rows

    def _row_zpls_for_quantity(self, unit_zpl: str, template, quantity: int) -> list[str]:
        return self.row_zpls_for_units([(unit_zpl, template)] * quantity)

    def print_unit_rows(self, units: list[tuple[str, object]], direct: bool = False) -> list[str]:
        rows = self.row_zpls_for_units(units)
        self._dispatch_many(rows, direct)
        return rows

    def _dispatch_many(self, zpls: list[str], direct: bool):
        zpls = [shift_zpl_y_offset(zpl, int(self.label_y_offset_dots or 0)) for zpl in zpls]
        if not direct:
            return
        for zpl in zpls:
            self._dispatch_raw(zpl)

    def dispatch_zpls(self, zpls: list[str], direct: bool = False):
        self._dispatch_many(zpls, direct)

    def print_template(self, template, size: str, quantity: int, mode: str = "frente-e-verso", direct: bool = False) -> list[str]:
        outputs = []
        if mode in ("somente-frente", "frente-e-verso", "frente-verso-separados"):
            zpl_f = build_front_zpl(template)
            front_rows = self._row_zpls_for_quantity(zpl_f, template, quantity)
            if mode == "frente-e-verso":
                zpl_b = build_back_zpl(template, size=size)
                back_rows = self._row_zpls_for_quantity(zpl_b, template, quantity)
                # Modo legado: alterna frente/verso por unidade.
                for front_row, back_row in zip(front_rows, back_rows):
                    combined = "\n".join([front_row, back_row])
                    self._dispatch_many([combined], direct)
                    outputs.append(combined)
            elif mode == "frente-verso-separados":
                zpl_b = build_back_zpl(template, size=size)
                back_rows = self._row_zpls_for_quantity(zpl_b, template, quantity)
                # Alterna por linha: uma linha de frentes, depois a linha correspondente de versos.
                max_rows = max(len(front_rows), len(back_rows))
                for idx in range(max_rows):
                    chunk = []
                    if idx < len(front_rows):
                        chunk.append(front_rows[idx])
                    if idx < len(back_rows):
                        chunk.append(back_rows[idx])
                    combined = "\n".join(chunk)
                    self._dispatch_many([combined], direct)
                    outputs.append(combined)
            else:
                self._dispatch_many(front_rows, direct)
                outputs.extend(front_rows)
            return outputs

        if mode == "somente-verso":
            zpl_b = build_back_zpl(template, size=size)
            back_rows = self._row_zpls_for_quantity(zpl_b, template, quantity)
            self._dispatch_many(back_rows, direct)
            outputs.extend(back_rows)
        return outputs
