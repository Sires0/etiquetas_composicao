import csv
from pathlib import Path
from app.domain.models import Assignment, PrintRequest

try:
    import openpyxl
except Exception:
    openpyxl = None


class ImportErrorReport(Exception):
    def __init__(self, errors: list[str]):
        self.errors = errors
        super().__init__("; ".join(errors))


def _read_rows(path: str) -> list[list[str]]:
    p = Path(path)
    if p.suffix.lower() == ".csv":
        with p.open("r", newline="", encoding="utf-8-sig") as f:
            return [list(row) for row in csv.reader(f)]
    if p.suffix.lower() in {".xlsx", ".xlsm"}:
        if openpyxl is None:
            raise ImportErrorReport(["openpyxl e obrigatorio para importar XLSX."])
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
        ws = wb.active
        rows = []
        for r in ws.iter_rows(values_only=True):
            rows.append(["" if c is None else str(c) for c in r])
        wb.close()
        return rows
    raise ImportErrorReport(["Formato nao suportado. Use CSV ou XLSX."])


def parse_assignments(path: str) -> list[Assignment]:
    rows = _read_rows(path)
    if len(rows) < 2:
        raise ImportErrorReport(["O arquivo precisa ter cabecalho e ao menos uma linha de dados."])

    errors = []
    out = []
    for i, row in enumerate(rows[1:], start=2):
        if len(row) < 2:
            errors.append(f"Linha {i}: esperado no minimo 2 colunas (REF, ETIQ).")
            continue
        ref = str(row[0]).strip()
        etiq = str(row[1]).strip()
        if not ref or not etiq:
            errors.append(f"Linha {i}: REF e ETIQ nao podem ser vazios.")
            continue
        out.append(Assignment(ref_code=ref, label_code=etiq))

    if errors:
        raise ImportErrorReport(errors)
    return out


def parse_print_requests(path: str, mode: str) -> list[PrintRequest]:
    rows = _read_rows(path)
    if len(rows) < 2:
        raise ImportErrorReport(["O arquivo precisa ter cabecalho e ao menos uma linha de dados."])

    errors = []
    out = []
    known_sizes = {"P", "M", "G", "GG", "XG", "XXG"}
    for i, row in enumerate(rows[1:], start=2):
        if len(row) < 3:
            errors.append(f"Linha {i}: esperado no minimo 3 colunas (CODE, COLOR, SIZE).")
            continue
        ref = str(row[0]).strip()
        c1 = str(row[1]).strip()
        c2 = str(row[2]).strip()
        c3 = str(row[3]).strip() if len(row) >= 4 else ""

        # Formato novo (preferencial): CODE,COLOR,SIZE[,QTD]
        color = c1
        size = c2.upper()
        qty_s = c3

        # Compatibilidade com formato antigo: REF,SIZE,QTD[,COR]
        if c1.upper() in known_sizes:
            size = c1.upper()
            qty_s = c2
            color = c3 if len(row) >= 4 else ""

        if not ref or not size:
            errors.append(f"Linha {i}: CODE e SIZE nao podem ser vazios.")
            continue
        if size not in known_sizes:
            errors.append(f"Linha {i}: SIZE invalido '{size}' (use P,M,G,GG,XG,XXG).")
            continue

        qty = 1
        if qty_s:
            try:
                qty = int(float(qty_s))
                if qty <= 0:
                    raise ValueError
            except Exception:
                errors.append(f"Linha {i}: QTD deve ser inteiro positivo quando informada.")
                continue

        out.append(PrintRequest(ref_code=ref, size=size, quantity=qty, mode=mode, color_code=color))

    if errors:
        raise ImportErrorReport(errors)
    return out
