import urllib.parse
import urllib.request


def _dpi_to_labelary_dpmm(dpi: int) -> int:
    return max(6, int(round(float(dpi) / 25.4)))


def build_labelary_url(zpl: str, dpi: int = 200, width_mm: float = 47.0, height_mm: float = 25.0) -> str:
    width_in = width_mm / 25.4
    height_in = height_mm / 25.4
    encoded = urllib.parse.quote(zpl)
    dpmm = _dpi_to_labelary_dpmm(dpi)
    return f"https://api.labelary.com/v1/printers/{dpmm}dpmm/labels/{width_in:.2f}x{height_in:.2f}/0/{encoded}"


def fetch_labelary_png(zpl: str, dpi: int = 200, width_mm: float = 47.0, height_mm: float = 25.0, timeout: int = 5) -> bytes | None:
    dpmm = _dpi_to_labelary_dpmm(dpi)
    width_in = width_mm / 25.4
    height_in = height_mm / 25.4
    url = f"https://api.labelary.com/v1/printers/{dpmm}dpmm/labels/{width_in:.2f}x{height_in:.2f}/0/"
    req = urllib.request.Request(url, data=zpl.encode("utf-8"), method="POST")
    req.add_header("Accept", "image/png")
    req.add_header("Content-Type", "application/x-www-form-urlencoded")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.read()
    except Exception:
        return None
