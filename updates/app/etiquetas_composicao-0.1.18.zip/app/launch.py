from __future__ import annotations

import json
import os
import sys
from pathlib import Path
import tkinter as tk
from tkinter import ttk

from app.paths import DATA_DIR, PROJECT_ROOT
from app.services.update_service import UpdateService
from app.version import APP_VERSION


def _updates_disabled(argv: list[str] | None = None) -> bool:
    args = argv if argv is not None else sys.argv[1:]
    return "--no-update" in args


def maximize_window(root: tk.Tk) -> None:
    if sys.platform.startswith("win"):
        try:
            root.state("zoomed")
            return
        except Exception:
            pass

    if not sys.platform.startswith("win"):
        for attempt in (
            lambda: root.wm_attributes("-zoomed", 1),
            lambda: root.attributes("-zoomed", True),
            lambda: root.wm_state("zoomed"),
        ):
            try:
                attempt()
                root.update_idletasks()
                current_w = root.winfo_width()
                current_h = root.winfo_height()
                if current_w > 1200 or current_h > 700:
                    return
            except Exception:
                continue


def _load_window_state(root: tk.Tk, path: Path) -> bool:
    if not path.exists():
        return False
    try:
        state = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return False

    geometry = str(state.get("geometry", "") or "").strip()
    zoomed = bool(state.get("zoomed", False))
    try:
        if geometry:
            root.geometry(geometry)
        if zoomed:
            if sys.platform.startswith("win"):
                root.state("zoomed")
            else:
                try:
                    root.wm_attributes("-zoomed", 1)
                except Exception:
                    try:
                        root.attributes("-zoomed", True)
                    except Exception:
                        root.wm_state("zoomed")
        return True
    except Exception:
        return False


def _save_window_state(root: tk.Tk, path: Path) -> None:
    zoomed = False
    try:
        zoomed = root.state() == "zoomed"
    except Exception:
        try:
            zoomed = bool(root.wm_attributes("-zoomed"))
        except Exception:
            zoomed = False
    state = {
        "geometry": root.geometry(),
        "zoomed": zoomed,
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")


def _startup_update_gate(update_service: UpdateService, launcher_script: str, argv: list[str]) -> bool:
    updates_disabled = _updates_disabled(argv)
    if updates_disabled:
        return False
    if update_service.pending_app_update_is_forced():
        relaunched = update_service.launch_pending_app_update_and_restart(
            launcher_script,
            argv,
            parent_pid=os.getpid(),
        )
        if relaunched:
            return True
    update_result = update_service.startup_sync()
    if update_result.get("restart_required"):
        relaunched = update_service.launch_pending_app_update_and_restart(
            launcher_script,
            argv,
            parent_pid=os.getpid(),
        )
        if relaunched:
            return True
    return False


def run_print_app(launcher_script: str, argv: list[str] | None = None) -> None:
    args = list(argv or [])
    os.chdir(PROJECT_ROOT)
    update_service = UpdateService()
    if _startup_update_gate(update_service, launcher_script, args):
        return

    from app.ui.print_window import PrintWindow

    state_path = DATA_DIR / "window_state_print.json"
    root = tk.Tk()
    root.title(f"Etiquetas Composicao - Impressao v{APP_VERSION}")
    root.geometry("1220x760")
    style = ttk.Style(root)
    try:
        style.theme_use("clam")
    except Exception:
        pass
    app = PrintWindow(root)
    restored = _load_window_state(root, state_path)
    updates_disabled = _updates_disabled(args)

    def on_close() -> None:
        try:
            app._save_ui_state()
        except Exception:
            pass
        _save_window_state(root, state_path)
        if not updates_disabled:
            try:
                update_service.launch_pending_app_update_after_exit(os.getpid())
            except Exception:
                pass
        root.destroy()

    root.protocol("WM_DELETE_WINDOW", on_close)
    if not restored:
        root.after_idle(lambda: maximize_window(root))
    root.mainloop()


def run_maintenance_app(launcher_script: str, argv: list[str] | None = None) -> None:
    args = list(argv or [])
    os.chdir(PROJECT_ROOT)
    update_service = UpdateService()
    if _startup_update_gate(update_service, launcher_script, args):
        return

    from app.ui.maintenance_window import MaintenanceWindow

    state_path = DATA_DIR / "window_state_maintenance.json"
    root = tk.Tk()
    root.title(f"Etiquetas Composicao - Cadastro v{APP_VERSION}")
    root.geometry("1220x760")
    style = ttk.Style(root)
    try:
        style.theme_use("clam")
    except Exception:
        pass
    MaintenanceWindow(root)
    restored = _load_window_state(root, state_path)
    updates_disabled = _updates_disabled(args)

    def on_close() -> None:
        _save_window_state(root, state_path)
        if not updates_disabled:
            try:
                update_service.launch_pending_app_update_after_exit(os.getpid())
            except Exception:
                pass
        root.destroy()

    root.protocol("WM_DELETE_WINDOW", on_close)
    if not restored:
        root.after_idle(lambda: maximize_window(root))
    root.mainloop()
