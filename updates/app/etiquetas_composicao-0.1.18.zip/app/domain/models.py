from dataclasses import dataclass, field
from typing import List


@dataclass
class LabelTemplate:
    label_code: str
    width_mm: float
    height_mm: float
    layout_preset: str = "padrao"
    labels_per_row: int = 1
    text_size_mm: float = 2.0
    symbol_size_mm: float = 4.0
    left_margin_mm: float = 0.0
    top_margin_mm: float = 0.0
    right_margin_mm: float = 0.0
    bottom_margin_mm: float = 0.0
    symbol_x_offset_mm: float = -4.0
    tecido_principal: str = ""
    forro: str = ""
    bojo: str = ""
    allowed_sizes: List[str] = field(default_factory=list)
    symbols: List[str] = field(default_factory=list)
    fabricante: str = ""
    cnpj: str = ""
    pais_origem: str = ""
    instrucoes_adicionais: str = ""
    logo_text: str = ""
    vertical_code: str = ""


@dataclass
class Assignment:
    ref_code: str
    label_code: str


@dataclass
class AssignmentRule:
    priority: int
    ref_suffix: str
    color_prefix: str
    label_code: str


@dataclass
class PrintRequest:
    ref_code: str
    size: str
    quantity: int
    mode: str = "frente-verso-separados"
    color_code: str = ""
    textile_name: str = ""
    company: str = ""


@dataclass
class ProductTextileOption:
    company: str
    ref_code: str
    textile_name: str
    color_type: str
    label_code: str
