import re
from .compliance import mm_to_dots, min_text_dots, ensure_within_bounds
from .layout_presets import get_layout_preset


def compute_canvas(width_mm: float, height_mm: float, dpi: int) -> dict:
    return {
        "width_dots": mm_to_dots(width_mm, dpi),
        "height_dots": mm_to_dots(height_mm, dpi),
    }


def _wrap_lines(text: str, width_chars: int = 22) -> list[str]:
    if not text:
        return []
    normalized = _normalize_composition_lines(text)
    if normalized:
        text = "\n".join(normalized)
    out = []
    for line in text.splitlines() or [text]:
        line = line.strip()
        while len(line) > width_chars:
            cut = line.rfind(" ", 0, width_chars)
            if cut <= 0:
                cut = width_chars
            out.append(line[:cut])
            line = line[cut:].strip()
        if line:
            out.append(line)
    return out


def _normalize_composition_lines(text: str) -> list[str]:
    if not text:
        return []
    raw = " ".join((text or "").strip().split())
    raw = re.sub(r"(%)([A-Za-z])", r"\1 \2", raw)
    parts = [p.strip() for p in re.split(r"(?<!\d)(?=\d{1,3}%)", raw) if p.strip()]
    if len(parts) >= 2:
        return parts
    return [raw] if raw else []


def _normalize_composition_inline(text: str) -> str:
    parts = _normalize_composition_lines(text)
    return ", ".join(parts) if parts else ""


def _build_front_sections(template) -> list[tuple[str, str]]:
    sections = []
    preset = get_layout_preset(getattr(template, "layout_preset", "padrao"))
    front_cfg = preset["front"]
    enabled = set(front_cfg.get("sections", ["tecido_principal", "forro", "bojo"]))
    show_titles = bool(front_cfg.get("show_titles", True))

    tecido = (template.tecido_principal or "").strip()
    if "tecido_principal" in enabled and tecido:
        sections.append(("TECIDO PRINCIPAL:" if show_titles else "", tecido))
    forro = (template.forro or "").strip()
    if "forro" in enabled and forro:
        sections.append(("FORRO:" if show_titles else "", forro))
    bojo = (template.bojo or "").strip()
    if "bojo" in enabled and bojo:
        sections.append(("BOJO:" if show_titles else "", bojo))
    return sections


def _build_back_composition_sections(template) -> list[tuple[str, list[str]]]:
    tecido_lines = _normalize_composition_lines((template.tecido_principal or "").strip())
    forro = _normalize_composition_inline((template.forro or "").strip())
    bojo = _normalize_composition_inline((template.bojo or "").strip())
    if tecido_lines:
        if len(tecido_lines) >= 2:
            tecido = [f"TECIDO PRINCIPAL: {tecido_lines[0]},", tecido_lines[1]]
        else:
            tecido = [f"TECIDO PRINCIPAL: {tecido_lines[0]}"]
    else:
        tecido = []
    return [
        ("tecido_principal", tecido),
        ("forro", [f"FORRO: {forro}".strip()] if forro else []),
        ("bojo", [f"BOJO: {bojo}".strip()] if bojo else []),
    ]


def _build_back_vertical_composition_layout(template, canvas: dict, back_cfg: dict, text_h: int, dpi: int) -> dict:
    w = canvas["width_dots"]
    h = canvas["height_dots"]
    margin_x = mm_to_dots(max(0.0, float(getattr(template, "left_margin_mm", 0.0))), dpi)
    content_y_offset = int(back_cfg.get("content_y_offset", 0))
    margin_top = mm_to_dots(max(0.0, float(getattr(template, "top_margin_mm", 0.0))), dpi)
    margin_right = mm_to_dots(max(0.0, float(getattr(template, "right_margin_mm", 0.0))), dpi)
    margin_bottom = mm_to_dots(max(0.0, float(getattr(template, "bottom_margin_mm", 0.0))), dpi)
    section_xs = list(back_cfg.get("section_xs", [6, 46, 86]))
    top_base = mm_to_dots(float(back_cfg["text_top_mm"]), dpi) if "text_top_mm" in back_cfg else int(back_cfg.get("text_top", 10))
    bottom_base = mm_to_dots(float(back_cfg["text_bottom_mm"]), dpi) if "text_bottom_mm" in back_cfg else int(back_cfg.get("text_bottom", 14))
    y = top_base + content_y_offset + (margin_top if bool(back_cfg.get("use_template_top_margin", True)) else 0)
    text_bottom = bottom_base + (margin_bottom if bool(back_cfg.get("use_template_bottom_margin", True)) else 0)
    font_w = max(1, int(round(text_h * float(back_cfg.get("font_width_ratio", 0.75)))))
    advance_ratio = float(back_cfg.get("advance_ratio", 1.0))

    def vertical_advance(text: str) -> int:
        raw = len(text) * font_w
        return max(text_h, int(round(raw * advance_ratio)))

    blocks = []
    section_line_gap = int(back_cfg.get("section_line_gap", text_h))
    sections = _build_back_composition_sections(template)
    if bool(back_cfg.get("center_text_lanes", False)):
        lanes: list[tuple[str, str]] = []
        for section_id, lines in sections:
            lanes.extend((section_id, line) for line in lines if line.strip())
        available_w = max(0, w - margin_x - margin_right - text_h)
        total_lanes_w = max(0, (len(lanes) - 1) * section_line_gap)
        start_x = margin_x + max(0, (available_w - total_lanes_w) // 2) + total_lanes_w
        for lane_idx, (section_id, line) in enumerate(lanes):
            line_x = start_x - (lane_idx * section_line_gap)
            block_h = vertical_advance(line)
            blocks.append({
                "id": section_id,
                "x": line_x,
                "y": y,
                "w": text_h,
                "h": block_h,
                "text": line,
                "orientation": "R",
            })
        errors = []
        for b in blocks:
            ok, msg = ensure_within_bounds(b["x"], b["y"], b["w"], b["h"], w, h - text_bottom)
            if not ok:
                errors.append(f"{b['id']}: {msg}")
        return {"canvas": canvas, "blocks": blocks, "errors": errors, "text_height_dots": text_h}

    for idx, (section_id, lines) in enumerate(sections):
        lines = [line for line in lines if line.strip()]
        if not lines:
            continue
        x = (int(section_xs[idx]) if idx < len(section_xs) else int(section_xs[-1] - ((idx - len(section_xs) + 1) * section_line_gap))) + margin_x
        for line_idx, line in enumerate(lines):
            line_x = x - (line_idx * section_line_gap)
            block_h = vertical_advance(line)
            blocks.append({
                "id": section_id,
                "x": line_x,
                "y": y,
                "w": text_h,
                "h": block_h,
                "text": line,
                "orientation": "R",
            })

    errors = []
    for b in blocks:
        ok, msg = ensure_within_bounds(b["x"], b["y"], b["w"], b["h"], w, h - text_bottom)
        if not ok:
            errors.append(f"{b['id']}: {msg}")
    return {"canvas": canvas, "blocks": blocks, "errors": errors, "text_height_dots": text_h}


def _build_symbols_cnpj_vertical_layout(template, dpi: int, canvas: dict, front_cfg: dict, text_h: int, produto_info: str = "") -> dict:
    w = canvas["width_dots"]
    h = canvas["height_dots"]
    requested_symbol = mm_to_dots(max(4.0, float(getattr(template, "symbol_size_mm", 4.0))), dpi)
    gap = int(front_cfg.get("symbol_col_gap", 6))
    symbol_top = int(front_cfg.get("symbol_top", 18))
    symbol_bottom = int(front_cfg.get("symbol_bottom", 18))
    margin_x = mm_to_dots(max(0.0, float(getattr(template, "left_margin_mm", 0.0))), dpi)
    content_y_offset = int(front_cfg.get("content_y_offset", 0))
    margin_top = mm_to_dots(max(0.0, float(getattr(template, "top_margin_mm", 0.0))), dpi)
    margin_right = mm_to_dots(max(0.0, float(getattr(template, "right_margin_mm", 0.0))), dpi)
    margin_bottom = mm_to_dots(max(0.0, float(getattr(template, "bottom_margin_mm", 0.0))), dpi)
    symbol_x = int(round(w * float(front_cfg.get("symbol_x_ratio", 0.52))))
    symbol_x += mm_to_dots(float(getattr(template, "symbol_x_offset_mm", 0.0)), dpi)
    symbol_x += margin_x
    symbol_x = max(0, min(symbol_x, w - requested_symbol - margin_right))

    cnpj_val = (template.cnpj or "").strip()
    if bool(front_cfg.get("show_cnpj_prefix", True)):
        cnpj_text = f"CNPJ: {cnpj_val}".strip()
    else:
        cnpj_text = cnpj_val
    origem_text = (template.pais_origem or "").strip()
    if origem_text:
        cnpj_text = f"{cnpj_text}   {origem_text}"
    produto_text = (produto_info or "").strip()
    cnpj_x = int(front_cfg.get("cnpj_x", 6)) + margin_x
    cnpj_top = int(front_cfg.get("cnpj_top", 10)) + content_y_offset + margin_top
    cnpj_bottom = int(front_cfg.get("cnpj_bottom", 10)) + margin_bottom
    produto_x = int(front_cfg.get("produto_x", int(front_cfg.get("origem_x", cnpj_x)))) + margin_x
    produto_top = int(front_cfg.get("produto_top", int(front_cfg.get("origem_top", int(front_cfg.get("cnpj_top", 10)))))) + content_y_offset + margin_top
    available_cnpj_h = h - cnpj_top - cnpj_bottom
    cnpj_text_h = max(1, int(round(text_h * float(front_cfg.get("cnpj_font_scale", 1.0)))))
    produto_text_h = max(1, int(round(text_h * float(front_cfg.get("produto_font_scale", 1.0)))))
    requested_font_w = int(round(cnpj_text_h * float(front_cfg.get("cnpj_font_width_ratio", 0.75))))
    produto_requested_w = int(round(produto_text_h * float(front_cfg.get("produto_font_width_ratio", 0.75))))
    cnpj_len = max(1, len(cnpj_text))
    produto_len = len(produto_text)
    font_w = max(1, requested_font_w)
    produto_w = max(1, produto_requested_w) if produto_text else 0

    cnpj_h = cnpj_len * font_w
    produto_h = produto_len * produto_w if produto_text else 0

    symbols = template.symbols or []
    symbols_h = len(symbols) * requested_symbol + max(0, len(symbols) - 1) * gap
    area_h = max(0, h - (symbol_top + margin_top) - (symbol_bottom + margin_bottom))
    symbol_y = symbol_top + content_y_offset + margin_top + max(0, (area_h - symbols_h) // 2)

    blocks = []
    if cnpj_text != "CNPJ:":
        blocks.append({
            "id": "cnpj_vertical",
            "x": cnpj_x,
            "y": cnpj_top,
            "w": cnpj_text_h,
            "h": cnpj_h,
            "text": cnpj_text,
            "orientation": "R",
        })
    if produto_text:
        blocks.append({
            "id": "produto_vertical",
            "x": produto_x,
            "y": produto_top,
            "w": produto_text_h,
            "h": produto_h,
            "text": produto_text,
            "orientation": "R",
        })
    blocks.append({
        "id": "symbols",
        "x": symbol_x,
        "y": symbol_y,
        "w": requested_symbol,
        "h": symbols_h,
        "symbols": symbols,
        "orientation": "vertical",
    })

    errors = []
    if not (template.cnpj or "").strip():
        errors.append("cnpj_vertical: CNPJ e obrigatorio neste layout.")
    if not symbols:
        errors.append("symbols: selecione ao menos uma simbologia.")
    if symbols_h > area_h:
        errors.append(
            f"symbols: {len(symbols)} simbolos nao cabem na coluna com tamanho/gap atual."
        )
    for b in blocks:
        ok, msg = ensure_within_bounds(b["x"], b["y"], b["w"], b["h"], w, h)
        if not ok:
            errors.append(f"{b['id']}: {msg}")

    return {
        "canvas": canvas,
        "blocks": blocks,
        "errors": errors,
        "text_height_dots": text_h,
        "min_symbol_dots": requested_symbol,
    }


def build_front_layout(template, dpi: int, produto_info: str = "") -> dict:
    canvas = compute_canvas(template.width_mm, template.height_mm, dpi)
    w = canvas["width_dots"]
    h = canvas["height_dots"]

    preset = get_layout_preset(getattr(template, "layout_preset", "padrao"))
    front_cfg = preset["front"]
    requested_text = mm_to_dots(max(2.0, float(getattr(template, "text_size_mm", 2.0))), dpi)
    text_h = max(min_text_dots(dpi), requested_text)
    if front_cfg.get("type") == "symbols_cnpj_vertical":
        return _build_symbols_cnpj_vertical_layout(template, dpi, canvas, front_cfg, text_h, produto_info=produto_info)
    margin_x = mm_to_dots(max(0.0, float(getattr(template, "left_margin_mm", 0.0))), dpi)
    margin_top = mm_to_dots(max(0.0, float(getattr(template, "top_margin_mm", 0.0))), dpi)
    margin_right = mm_to_dots(max(0.0, float(getattr(template, "right_margin_mm", 0.0))), dpi)
    margin_bottom = mm_to_dots(max(0.0, float(getattr(template, "bottom_margin_mm", 0.0))), dpi)
    left_w = int(round(w * 0.63))
    text_x = int(front_cfg.get("text_x", 8)) + margin_x
    symbol_x = int(round(w * float(front_cfg.get("symbol_x_ratio", 0.67))))
    symbol_x += margin_x
    symbol_x += mm_to_dots(float(getattr(template, "symbol_x_offset_mm", -4.0)), dpi)
    symbol_x = max(8 + margin_x, min(symbol_x, w - 8 - margin_right))
    symbol_w = w - symbol_x - 8 - margin_right
    symbol_top = int(front_cfg.get("symbol_top", 8)) + margin_top
    symbol_bottom = int(front_cfg.get("symbol_bottom", 8)) + margin_bottom
    title_body_gap = int(front_cfg.get("title_body_gap", 4))
    section_gap = int(front_cfg.get("section_gap", 4))
    top_margin = int(front_cfg.get("top_margin", 8)) + margin_top
    bottom_margin = int(front_cfg.get("bottom_margin", 8)) + margin_bottom

    requested_symbol = mm_to_dots(max(4.0, float(getattr(template, "symbol_size_mm", 4.0))), dpi)
    min_symbol_dots = requested_symbol
    blocks = [{"id": "symbols", "x": symbol_x, "y": symbol_top, "w": symbol_w, "h": h - symbol_top - symbol_bottom, "symbols": template.symbols}]

    sections = _build_front_sections(template)
    sections_meta = []
    total_h = 0
    for title, body in sections:
        lines = _wrap_lines(body)
        title_h = text_h if title else 0
        gap_h = title_body_gap if title else 0
        sec_h = title_h + gap_h + len(lines) * (text_h + 2)
        sections_meta.append((title, lines, sec_h))
        total_h += sec_h
    if sections_meta:
        total_h += section_gap * (len(sections_meta) - 1)

    usable_h = max(0, h - top_margin - bottom_margin)
    start_y = max(top_margin, top_margin + (usable_h - total_h) // 2) if sections_meta else top_margin
    y = start_y
    for idx, (title, lines, sec_h) in enumerate(sections_meta):
        if title:
            blocks.append({"id": f"sec_{idx}_title", "x": text_x, "y": y, "w": left_w - text_x, "h": text_h, "text": title, "bold": True})
            y += text_h + title_body_gap
        if lines:
            blocks.append({"id": f"sec_{idx}_body", "x": text_x, "y": y, "w": left_w - text_x, "h": len(lines) * (text_h + 2), "text": "\\n".join(lines)})
            y += len(lines) * (text_h + 2)
        if idx < len(sections_meta) - 1:
            y += section_gap

    errors = []
    for b in blocks:
        ok, msg = ensure_within_bounds(b["x"], b["y"], b["w"], b["h"], w, h)
        if not ok:
            errors.append(f"{b['id']}: {msg}")

    symbols = template.symbols or []
    if symbols:
        area_h = max(0, h - symbol_top - symbol_bottom)
        max_rows = max(1, area_h // (min_symbol_dots + 3))
        cols = 1 if symbol_w < (min_symbol_dots * 2 + 3) else 2
        capacity = max_rows * cols
        if symbol_w < min_symbol_dots:
            errors.append(f"symbols: largura insuficiente para simbolo minimo configurado ({min_symbol_dots} dots).")
        if area_h < min_symbol_dots:
            errors.append(f"symbols: altura insuficiente para simbolo minimo configurado ({min_symbol_dots} dots).")
        if len(symbols) > capacity:
            errors.append(
                f"symbols: {len(symbols)} simbolos nao cabem com tamanho configurado; capacidade atual: {capacity}."
            )

    return {
        "canvas": canvas,
        "blocks": blocks,
        "errors": errors,
        "text_height_dots": text_h,
        "min_symbol_dots": min_symbol_dots,
    }


def build_back_layout(template, size: str, dpi: int) -> dict:
    canvas = compute_canvas(template.width_mm, template.height_mm, dpi)
    w = canvas["width_dots"]
    h = canvas["height_dots"]
    preset = get_layout_preset(getattr(template, "layout_preset", "padrao"))
    back_cfg = preset["back"]
    requested_text = mm_to_dots(max(2.0, float(getattr(template, "text_size_mm", 2.0))), dpi)
    text_h = max(min_text_dots(dpi), requested_text)
    if back_cfg.get("type") == "vertical_composition":
        return _build_back_vertical_composition_layout(template, canvas, back_cfg, text_h, dpi)
    margin_x = mm_to_dots(max(0.0, float(getattr(template, "left_margin_mm", 0.0))), dpi)
    margin_top = mm_to_dots(max(0.0, float(getattr(template, "top_margin_mm", 0.0))), dpi)

    blocks = []
    blocks.append({"id": "size", "x": int(round(w * float(back_cfg.get("size_x_ratio", 0.50)))) + margin_x, "y": int(round(h * float(back_cfg.get("size_y_ratio", 0.10)))) + margin_top, "w": int(round(w * 0.20)), "h": text_h * 2, "text": size, "bold": True})
    if back_cfg.get("show_logo", True):
        blocks.append({"id": "logo", "x": int(round(w * float(back_cfg.get("logo_x_ratio", 0.28)))) + margin_x, "y": int(round(h * float(back_cfg.get("logo_y_ratio", 0.36)))) + margin_top, "w": int(round(w * 0.50)), "h": text_h * 2, "text": template.logo_text or "LOGO"})
    blocks.append({"id": "cnpj", "x": int(round(w * float(back_cfg.get("cnpj_x_ratio", 0.24)))) + margin_x, "y": int(round(h * float(back_cfg.get("cnpj_y_ratio", 0.62)))) + margin_top, "w": int(round(w * 0.65)), "h": text_h, "text": f"CNPJ: {template.cnpj}"})
    blocks.append({"id": "origem", "x": int(round(w * float(back_cfg.get("origem_x_ratio", 0.24)))) + margin_x, "y": int(round(h * float(back_cfg.get("origem_y_ratio", 0.78)))) + margin_top, "w": int(round(w * 0.65)), "h": text_h, "text": template.pais_origem or "FEITO NO BRASIL"})
    if back_cfg.get("show_vertical_code", True):
        blocks.append({"id": "vertical_code", "x": int(back_cfg.get("vertical_x", 8)) + margin_x, "y": int(round(h * float(back_cfg.get("vertical_y_ratio", 0.20)))) + margin_top, "w": int(round(w * 0.10)), "h": text_h, "text": template.vertical_code})

    errors = []
    for b in blocks:
        ok, msg = ensure_within_bounds(b["x"], b["y"], b["w"], b["h"], w, h)
        if not ok:
            errors.append(f"{b['id']}: {msg}")
    return {"canvas": canvas, "blocks": blocks, "errors": errors, "text_height_dots": text_h}
