DPI_DEFAULT = 200
MIN_TEXT_MM = 2.0
MM_PER_INCH = 25.4

SIZE_OPTIONS = ["P", "M", "G", "GG", "XG", "XXG"]
PRINT_MODES = ["somente-frente", "somente-verso", "frente-e-verso", "frente-verso-separados"]
