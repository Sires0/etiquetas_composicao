import math
from .constants import MM_PER_INCH, MIN_TEXT_MM


def mm_to_dots(mm: float, dpi: int) -> int:
    return int(math.ceil(mm * dpi / MM_PER_INCH))


def dots_to_mm(dots: int, dpi: int) -> float:
    return dots * MM_PER_INCH / dpi


def min_text_dots(dpi: int) -> int:
    return mm_to_dots(MIN_TEXT_MM, dpi)


def validate_min_text_height(text_height_dots: int, dpi: int) -> tuple[bool, str]:
    minimum = min_text_dots(dpi)
    if text_height_dots < minimum:
        return False, f"Text height {text_height_dots} dots is below required {minimum} dots (2.0mm)."
    return True, "OK"


def ensure_within_bounds(x: int, y: int, w: int, h: int, max_w: int, max_h: int) -> tuple[bool, str]:
    if x < 0 or y < 0:
        return False, "Element starts outside label bounds."
    if x + w > max_w or y + h > max_h:
        return False, "Element exceeds label bounds."
    return True, "OK"
