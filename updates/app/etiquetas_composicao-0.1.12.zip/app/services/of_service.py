from __future__ import annotations

import json
import math
import re
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from difflib import SequenceMatcher
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from app.domain.models import PrintRequest, ProductTextileOption
from app.services.textile_importer import classify_color_type
from app.storage.csv_store import CsvStore

BASE_URL = "https://unaforce.com.br/_of-service"
AUTH_TOKEN = "0IFYf9DuRsAJnuiY0Jpx1tm44oS7K4PmUCrCmesv0gFoc9s_"
TIMEOUT_SECONDS = 12.0

FABRIC_HINTS = (
    "TECIDO",
    "POLIAMIDA",
    "POLIESTER",
    "POLIÉSTER",
    "ELASTANO",
    "VISCOSE",
    "MALHA",
    "TWILL",
    "AIR FLOW",
    "CREPE",
    "LINHO",
    "RENDA",
    "TULE",
    "MICROFIBRA",
    "SATIN",
    "CETIM",
    "TRICOT",
)

AVOID_HINTS = (
    "TAG",
    "EMBALAGEM",
    "LINHA",
    "PLAQUINHA",
    "BOTAO",
    "BOTÃO",
    "ZIPER",
    "ZIPER",
    "ELASTICO",
    "ELÁSTICO",
    "CORDAO",
    "CORDÃO",
    "CABIDE",
    "ADESIVO",
)


class OfServiceError(Exception):
    pass


@dataclass
class OfResolvedRow:
    of_number: str
    ref_code: str
    color_code: str
    color_description: str
    size: str
    base_quantity: Decimal
    final_quantity: int
    textile_option: ProductTextileOption | None
    material_description: str
    company: str
    label_code: str
    status: str

    def to_print_request(self, mode: str) -> PrintRequest:
        return PrintRequest(
            ref_code=self.ref_code,
            size=self.size,
            quantity=self.final_quantity,
            mode=mode,
            color_code=self.color_code,
            textile_name=self.textile_option.textile_name if self.textile_option else "",
            company=self.company,
        )


def _normalize_text(value: object) -> str:
    text = str(value or "").strip().upper()
    return " ".join(text.split())


def _tokenize(value: object) -> set[str]:
    text = _normalize_text(value)
    return {token for token in re.split(r"[^A-Z0-9]+", text) if len(token) >= 2}


def _parse_decimal(value: object) -> Decimal:
    text = str(value or "").strip()
    if not text:
        return Decimal("0")
    text = text.replace(",", ".")
    try:
        return Decimal(text)
    except InvalidOperation as exc:
        raise OfServiceError(f"Quantidade invalida recebida do servico: {value!r}") from exc


def _request_json(path: str) -> dict[str, Any]:
    url = f"{BASE_URL}{path}"
    req = Request(url, headers={"Authorization": f"Bearer {AUTH_TOKEN}"})
    try:
        with urlopen(req, timeout=TIMEOUT_SECONDS) as response:
            raw = response.read().decode("utf-8")
    except HTTPError as exc:
        body = ""
        try:
            body = exc.read().decode("utf-8", errors="replace")
        except Exception:
            body = ""
        raise OfServiceError(f"Servico OF respondeu {exc.code}: {body or exc.reason}") from exc
    except URLError as exc:
        raise OfServiceError(f"Falha ao conectar no servico OF: {exc.reason}") from exc
    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise OfServiceError("Servico OF retornou JSON invalido.") from exc
    if not isinstance(data, dict):
        raise OfServiceError("Servico OF retornou payload invalido.")
    return data


def fetch_of(numero: str) -> dict[str, Any]:
    numero = str(numero or "").strip()
    if not numero:
        raise OfServiceError("Informe o numero da OF.")
    return _request_json(f"/v1/of/{numero}")


def _material_score(item: dict[str, Any], material: dict[str, Any]) -> int:
    score = 0
    desc = _normalize_text(material.get("material_descricao", ""))
    unit = _normalize_text(material.get("material_unidade", ""))
    if unit == "MT":
        score += 40
    if any(hint in desc for hint in FABRIC_HINTS):
        score += 25
    if any(hint in desc for hint in AVOID_HINTS):
        score -= 80
    if _normalize_text(material.get("cor_codigo", "")) == _normalize_text(item.get("cor_codigo", "")):
        score += 20
    return score


def _pick_material_candidate(item: dict[str, Any], consumos: list[dict[str, Any]]) -> dict[str, Any] | None:
    best = None
    best_score = -10**9
    for material in consumos:
        score = _material_score(item, material)
        if score > best_score:
            best_score = score
            best = material
    if best_score < 0:
        return None
    return best


def _option_score(option: ProductTextileOption, material_description: str, color_code: str) -> float:
    textile = _normalize_text(option.textile_name)
    material = _normalize_text(material_description)
    if not textile:
        return -1.0
    score = 0.0
    if textile and textile in material:
        score += 80.0
    textile_tokens = _tokenize(textile)
    material_tokens = _tokenize(material)
    if textile_tokens:
        overlap = len(textile_tokens & material_tokens)
        score += overlap * 12.0
    score += SequenceMatcher(None, textile, material).ratio() * 30.0
    color_type = classify_color_type(option.company, color_code, "")
    if option.color_type and option.color_type == color_type:
        score += 10.0
    return score


def _resolve_textile_option(store: CsvStore, ref_code: str, color_code: str, material_description: str) -> ProductTextileOption | None:
    options = store.list_product_textiles(ref_code=ref_code)
    if not options:
        return None
    if material_description:
        ranked = sorted(options, key=lambda opt: _option_score(opt, material_description, color_code), reverse=True)
        if ranked and _option_score(ranked[0], material_description, color_code) >= 35.0:
            return ranked[0]

    company_guess = options[0].company if len({o.company for o in options}) == 1 else ""
    classified = classify_color_type(company_guess, color_code, "")
    for option in options:
        if option.color_type and option.color_type == classified:
            return option
    return options[0]


def _build_status(option: ProductTextileOption | None, material_description: str) -> str:
    if option:
        if material_description:
            return "OK"
        return "OK sem material"
    if material_description:
        return "Sem tecido correspondente"
    return "Sem material textil"


def build_of_rows(store: CsvStore, numero: str, extra_percent: float) -> tuple[dict[str, Any], list[OfResolvedRow]]:
    payload = fetch_of(numero)
    of_data = payload.get("of") or {}
    itens = payload.get("itens") or []
    consumos = payload.get("consumos") or []
    if not isinstance(itens, list):
        raise OfServiceError("Payload da OF sem lista de itens valida.")

    factor = 1.0 + max(float(extra_percent), 0.0) / 100.0
    rows: list[OfResolvedRow] = []
    for item in itens:
        if not isinstance(item, dict):
            continue
        ref_code = str(item.get("produto_codigo") or of_data.get("produto_codigo") or "").strip()
        color_code = str(item.get("cor_codigo") or "").strip()
        color_description = str(item.get("cor_descricao") or "").strip()
        size = str(item.get("tamanho") or "").strip().upper()
        base_quantity = _parse_decimal(item.get("quantidade"))
        final_quantity = int(math.ceil(float(base_quantity) * factor))
        material = _pick_material_candidate(item, [c for c in consumos if isinstance(c, dict)])
        material_description = str((material or {}).get("material_descricao") or "").strip()
        option = _resolve_textile_option(store, ref_code, color_code, material_description)
        company = option.company if option else ""
        label_code = option.label_code if option else ""
        status = _build_status(option, material_description)
        rows.append(
            OfResolvedRow(
                of_number=str(of_data.get("numero") or numero).strip(),
                ref_code=ref_code,
                color_code=color_code,
                color_description=color_description,
                size=size,
                base_quantity=base_quantity,
                final_quantity=final_quantity,
                textile_option=option,
                material_description=material_description,
                company=company,
                label_code=label_code,
                status=status,
            )
        )
    return payload, rows
