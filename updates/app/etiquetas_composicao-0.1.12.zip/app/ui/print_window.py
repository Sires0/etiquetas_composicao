import json
import os
import tkinter as tk
from tkinter import messagebox, ttk

from app.domain.constants import PRINT_MODES, SIZE_OPTIONS
from app.paths import DATA_DIR
from app.services.of_service import OfResolvedRow, OfServiceError, build_of_rows
from app.services.print_service import PrintService
from app.storage.csv_store import CsvStore
from app.ui.main_window import MainWindow
from app.version import APP_VERSION


class PrintWindow(MainWindow):
    def __init__(self, master):
        ttk.Frame.__init__(self, master)
        self.store = CsvStore("data")
        self.print_service = PrintService()
        self.current_preview_img = None
        self.defaults_path = ""
        self.ui_state_path = str(DATA_DIR / "ui_state_print.json")
        self._textile_options = []
        self._textile_option_by_display = {}
        self._of_rows: list[OfResolvedRow] = []
        self._of_edit_textile_options = []
        self._of_edit_option_by_display = {}
        self._of_updating_editor = False

        self.pack(fill="both", expand=True)
        self._build_ui()
        self._bind_ctrl_a()
        self.refresh_labels_combo()
        self._load_printers()
        self._load_ui_state()
        self.winfo_toplevel().title(f"Etiquetas Composicao - Impressao v{APP_VERSION}")
        self.winfo_toplevel().protocol("WM_DELETE_WINDOW", self._on_close)

    def _build_ui(self):
        outer = ttk.Frame(self)
        outer.pack(fill="both", expand=True, padx=10, pady=10)

        ttk.Label(outer, text="Impressao de Etiquetas", font=("TkDefaultFont", 14, "bold")).pack(anchor="w", pady=(0, 8))

        self.v_ref = tk.StringVar()
        self.v_color = tk.StringVar()
        self.v_textile = tk.StringVar()
        self.v_size = tk.StringVar(value="M")
        self.v_qty = tk.StringVar(value="1")
        self.v_mode = tk.StringVar(value="frente-verso-separados")
        self.v_printer = tk.StringVar()
        self.v_of_number = tk.StringVar()
        self.v_of_extra = tk.StringVar(value="10")
        self.v_of_status = tk.StringVar(value="")
        self.v_of_edit_ref = tk.StringVar()
        self.v_of_edit_color = tk.StringVar()
        self.v_of_edit_size = tk.StringVar(value="M")
        self.v_of_edit_qty = tk.StringVar()
        self.v_of_edit_textile = tk.StringVar()
        self.v_of_edit_base_qty = tk.StringVar()

        def row(parent, label, var, width=18):
            r = ttk.Frame(parent)
            r.pack(fill="x", padx=8, pady=3)
            ttk.Label(r, text=label, width=18).pack(side="left")
            ttk.Entry(r, textvariable=var, width=width).pack(side="left", fill="x", expand=True)

        notebook = ttk.Notebook(outer)
        notebook.pack(fill="both", expand=True)
        tab_manual = ttk.Frame(notebook)
        tab_of = ttk.Frame(notebook)
        notebook.add(tab_manual, text="Impressao Manual")
        notebook.add(tab_of, text="Imprimir OF")

        manual = ttk.LabelFrame(tab_manual, text="Dados")
        manual.pack(fill="x", padx=8, pady=8)

        row(manual, "REF do produto", self.v_ref)
        row(manual, "Cor do produto", self.v_color)

        rsize = ttk.Frame(manual)
        rsize.pack(fill="x", padx=8, pady=3)
        ttk.Label(rsize, text="Tamanho", width=18).pack(side="left")
        ttk.Combobox(rsize, values=SIZE_OPTIONS, textvariable=self.v_size, state="readonly", width=16).pack(side="left")

        rtextile = ttk.Frame(manual)
        rtextile.pack(fill="x", padx=8, pady=3)
        ttk.Label(rtextile, text="Tecido", width=18).pack(side="left")
        self.cmb_textile = ttk.Combobox(rtextile, textvariable=self.v_textile, state="readonly", width=28)
        self.cmb_textile.pack(side="left", fill="x", expand=True)

        row(manual, "Quantidade", self.v_qty)

        ttk.Button(tab_manual, text="Imprimir", command=self.print_manual).pack(anchor="w", padx=8, pady=(0, 6))

        self._build_of_tab(tab_of)

        mode_box = ttk.LabelFrame(outer, text="Configuracao")
        mode_box.pack(fill="x", padx=8, pady=(0, 8))

        rmode = ttk.Frame(mode_box)
        rmode.pack(fill="x", padx=8, pady=(8, 3))
        ttk.Label(rmode, text="Modo", width=18).pack(side="left")
        ttk.Combobox(rmode, values=PRINT_MODES, textvariable=self.v_mode, state="readonly", width=22).pack(side="left")

        prow_manual = ttk.Frame(mode_box)
        prow_manual.pack(fill="x", padx=8, pady=(6, 3))
        ttk.Label(prow_manual, text="Impressora", width=18).pack(side="left")
        self.cmb_printer = ttk.Combobox(prow_manual, textvariable=self.v_printer, width=28)
        self.cmb_printer.pack(side="left", fill="x", expand=True)
        ttk.Button(prow_manual, text="Detectar", command=self._load_printers).pack(side="left", padx=(6, 0))

        self.v_ref.trace_add("write", self._refresh_textile_options)
        self.v_color.trace_add("write", self._refresh_textile_options)
        self.v_of_edit_ref.trace_add("write", self._refresh_of_edit_textiles)
        self.v_of_edit_color.trace_add("write", self._refresh_of_edit_textiles)
        self._refresh_textile_options()
        self._refresh_of_edit_textiles()

    def _build_of_tab(self, parent):
        top = ttk.LabelFrame(parent, text="Consulta da OF")
        top.pack(fill="x", padx=8, pady=(8, 6))

        row1 = ttk.Frame(top)
        row1.pack(fill="x", padx=8, pady=6)
        ttk.Label(row1, text="Numero da OF", width=18).pack(side="left")
        ttk.Entry(row1, textvariable=self.v_of_number, width=18).pack(side="left")
        ttk.Label(row1, text="% extra", width=10).pack(side="left", padx=(12, 0))
        ttk.Entry(row1, textvariable=self.v_of_extra, width=8).pack(side="left")
        ttk.Button(row1, text="Buscar OF", command=self.fetch_of_rows).pack(side="left", padx=(10, 0))
        ttk.Button(row1, text="Imprimir OF", command=self.print_of_rows).pack(side="left", padx=(6, 0))

        ttk.Label(top, textvariable=self.v_of_status).pack(anchor="w", padx=8, pady=(0, 6))

        grid_wrap = ttk.Frame(parent)
        grid_wrap.pack(fill="both", expand=True, padx=8, pady=6)
        cols = ("ref", "cor", "tam", "qtd_base", "qtd_final", "tecido", "etiq", "status", "material")
        self.tr_of = ttk.Treeview(grid_wrap, columns=cols, show="headings")
        self.tr_of.heading("ref", text="REF")
        self.tr_of.heading("cor", text="Cor")
        self.tr_of.heading("tam", text="Tam")
        self.tr_of.heading("qtd_base", text="Qtd base")
        self.tr_of.heading("qtd_final", text="Qtd final")
        self.tr_of.heading("tecido", text="Tecido")
        self.tr_of.heading("etiq", text="ETIQ")
        self.tr_of.heading("status", text="Status")
        self.tr_of.heading("material", text="Material detectado")
        self.tr_of.column("ref", width=80, anchor="center")
        self.tr_of.column("cor", width=90, anchor="center")
        self.tr_of.column("tam", width=60, anchor="center")
        self.tr_of.column("qtd_base", width=80, anchor="center")
        self.tr_of.column("qtd_final", width=80, anchor="center")
        self.tr_of.column("tecido", width=220, anchor="w")
        self.tr_of.column("etiq", width=60, anchor="center")
        self.tr_of.column("status", width=140, anchor="w")
        self.tr_of.column("material", width=340, anchor="w")
        sy = ttk.Scrollbar(grid_wrap, orient="vertical", command=self.tr_of.yview)
        sx = ttk.Scrollbar(grid_wrap, orient="horizontal", command=self.tr_of.xview)
        self.tr_of.configure(yscrollcommand=sy.set, xscrollcommand=sx.set)
        self.tr_of.pack(side="left", fill="both", expand=True)
        sy.pack(side="right", fill="y")
        sx.pack(side="bottom", fill="x")
        self.tr_of.bind("<<TreeviewSelect>>", self._on_select_of_row)

        edit = ttk.LabelFrame(parent, text="Editar linha selecionada")
        edit.pack(fill="x", padx=8, pady=(0, 8))

        line1 = ttk.Frame(edit)
        line1.pack(fill="x", padx=8, pady=4)
        ttk.Label(line1, text="REF", width=12).pack(side="left")
        ttk.Entry(line1, textvariable=self.v_of_edit_ref, width=12).pack(side="left")
        ttk.Label(line1, text="Cor", width=8).pack(side="left", padx=(8, 0))
        ttk.Entry(line1, textvariable=self.v_of_edit_color, width=12).pack(side="left")
        ttk.Label(line1, text="Tamanho", width=10).pack(side="left", padx=(8, 0))
        ttk.Combobox(line1, values=SIZE_OPTIONS, textvariable=self.v_of_edit_size, state="readonly", width=10).pack(side="left")

        line2 = ttk.Frame(edit)
        line2.pack(fill="x", padx=8, pady=4)
        ttk.Label(line2, text="Qtd base", width=12).pack(side="left")
        ttk.Entry(line2, textvariable=self.v_of_edit_base_qty, width=12, state="readonly").pack(side="left")
        ttk.Label(line2, text="Qtd final", width=8).pack(side="left", padx=(8, 0))
        ttk.Entry(line2, textvariable=self.v_of_edit_qty, width=12).pack(side="left")

        line3 = ttk.Frame(edit)
        line3.pack(fill="x", padx=8, pady=4)
        ttk.Label(line3, text="Tecido", width=12).pack(side="left")
        self.cmb_of_textile = ttk.Combobox(line3, textvariable=self.v_of_edit_textile, state="readonly", width=42)
        self.cmb_of_textile.pack(side="left", fill="x", expand=True)
        ttk.Button(line3, text="Atualizar linha", command=self.apply_of_row_edits).pack(side="left", padx=(8, 0))

    def _load_ui_state(self):
        if not os.path.exists(self.ui_state_path):
            return
        try:
            with open(self.ui_state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
        except Exception:
            return
        if not isinstance(state, dict):
            return
        self.v_mode.set(str(state.get("mode", self.v_mode.get()) or self.v_mode.get()))
        self.v_printer.set(str(state.get("printer", self.v_printer.get()) or self.v_printer.get()))
        self.v_of_extra.set(str(state.get("of_extra_percent", self.v_of_extra.get()) or self.v_of_extra.get()))

    def _save_ui_state(self):
        state = {
            "mode": self.v_mode.get().strip(),
            "printer": self.v_printer.get().strip(),
            "of_extra_percent": self.v_of_extra.get().strip(),
        }
        os.makedirs(os.path.dirname(self.ui_state_path), exist_ok=True)
        with open(self.ui_state_path, "w", encoding="utf-8") as f:
            json.dump(state, f, ensure_ascii=False, indent=2)

    def _on_close(self):
        try:
            self._save_ui_state()
        finally:
            self.winfo_toplevel().destroy()

    def _display_textile_option(self, option, option_pool) -> str:
        textile = (getattr(option, "textile_name", "") or "").strip()
        color_type = (getattr(option, "color_type", "") or "").strip().upper()
        company = (getattr(option, "company", "") or "").strip()
        display = textile
        if color_type:
            display = f"{display} [{color_type}]"
        if company and len({o.company for o in option_pool}) > 1:
            display = f"{company.title()} - {display}"
        return display

    def _refresh_textile_options(self, *_args):
        ref_code = self.v_ref.get().strip()
        color_code = self.v_color.get().strip()
        if not ref_code:
            options = []
        else:
            options = self.store.list_product_textiles(ref_code=ref_code)
        self._textile_options = options
        self._textile_option_by_display = {}

        displays = []
        for opt in options:
            display = self._display_textile_option(opt, options)
            displays.append(display)
            self._textile_option_by_display[display] = opt

        self.cmb_textile["values"] = displays
        self.cmb_textile.configure(state="readonly" if displays else "disabled")
        selected_display = ""
        if options:
            match = None
            company_guess = options[0].company if len({o.company for o in options}) == 1 else ""
            from app.services.textile_importer import classify_color_type

            classified = classify_color_type(company_guess, color_code, "")
            if color_code:
                for opt in options:
                    if opt.color_type and (opt.color_type in color_code.upper() or opt.color_type == classified):
                        match = opt
                        break
            if match is None:
                match = options[0]
            selected_display = self._display_textile_option(match, options)

        if self.v_textile.get().strip() != selected_display:
            self.v_textile.set(selected_display)

    def _selected_textile_option(self):
        display = self.v_textile.get().strip()
        if display and display in self._textile_option_by_display:
            return self._textile_option_by_display[display]
        if len(self._textile_options) == 1:
            return self._textile_options[0]
        return None

    def _refresh_of_edit_textiles(self, *_args):
        if self._of_updating_editor:
            return
        ref_code = self.v_of_edit_ref.get().strip()
        options = self.store.list_product_textiles(ref_code=ref_code) if ref_code else []
        self._of_edit_textile_options = options
        self._of_edit_option_by_display = {}
        displays = []
        for opt in options:
            display = self._display_textile_option(opt, options)
            displays.append(display)
            self._of_edit_option_by_display[display] = opt
        self.cmb_of_textile["values"] = displays
        self.cmb_of_textile.configure(state="readonly" if displays else "disabled")

    def _selected_of_textile_option(self):
        display = self.v_of_edit_textile.get().strip()
        if display and display in self._of_edit_option_by_display:
            return self._of_edit_option_by_display[display]
        if len(self._of_edit_textile_options) == 1:
            return self._of_edit_textile_options[0]
        return None

    def _populate_of_tree(self):
        for item in self.tr_of.get_children():
            self.tr_of.delete(item)
        for idx, row in enumerate(self._of_rows):
            textile = row.textile_option.textile_name if row.textile_option else ""
            self.tr_of.insert(
                "",
                "end",
                iid=str(idx),
                values=(
                    row.ref_code,
                    row.color_code,
                    row.size,
                    str(row.base_quantity),
                    row.final_quantity,
                    textile,
                    row.label_code,
                    row.status,
                    row.material_description,
                ),
            )

    def fetch_of_rows(self):
        numero = self.v_of_number.get().strip()
        try:
            extra = float((self.v_of_extra.get().strip() or "0").replace(",", "."))
        except Exception:
            messagebox.showerror("Erro", "Percentual extra invalido.")
            return
        try:
            payload, rows = build_of_rows(self.store, numero, extra)
        except OfServiceError as e:
            messagebox.showerror("Erro da OF", str(e))
            return
        except Exception as e:
            messagebox.showerror("Erro da OF", str(e))
            return
        self._of_rows = rows
        self._populate_of_tree()
        of_info = payload.get("of") or {}
        self.v_of_status.set(
            f"OF {of_info.get('numero', numero)} carregada: {len(rows)} item(ns), produto {of_info.get('produto_codigo', '')} {of_info.get('produto_descricao', '')}".strip()
        )
        if rows:
            self.tr_of.selection_set("0")
            self._on_select_of_row()

    def _on_select_of_row(self, _event=None):
        sel = self.tr_of.selection()
        if not sel:
            return
        idx = int(sel[0])
        if idx < 0 or idx >= len(self._of_rows):
            return
        row = self._of_rows[idx]
        self._of_updating_editor = True
        try:
            self.v_of_edit_ref.set(row.ref_code)
            self.v_of_edit_color.set(row.color_code)
            self.v_of_edit_size.set(row.size)
            self.v_of_edit_base_qty.set(str(row.base_quantity))
            self.v_of_edit_qty.set(str(row.final_quantity))
            self._refresh_of_edit_textiles()
            if row.textile_option:
                pool = self._of_edit_textile_options or [row.textile_option]
                self.v_of_edit_textile.set(self._display_textile_option(row.textile_option, pool))
            else:
                self.v_of_edit_textile.set("")
        finally:
            self._of_updating_editor = False

    def apply_of_row_edits(self):
        sel = self.tr_of.selection()
        if not sel:
            messagebox.showerror("Erro", "Selecione uma linha da OF.")
            return
        idx = int(sel[0])
        row = self._of_rows[idx]
        try:
            qty = int(float((self.v_of_edit_qty.get().strip() or "0").replace(",", ".")))
        except Exception:
            messagebox.showerror("Erro", "Quantidade final invalida.")
            return
        if qty <= 0:
            messagebox.showerror("Erro", "Quantidade final deve ser positiva.")
            return
        row.ref_code = self.v_of_edit_ref.get().strip()
        row.color_code = self.v_of_edit_color.get().strip()
        row.size = self.v_of_edit_size.get().strip().upper()
        row.final_quantity = qty
        option = self._selected_of_textile_option()
        row.textile_option = option
        row.company = option.company if option else ""
        row.label_code = option.label_code if option else ""
        row.status = "OK manual" if option else "Sem tecido correspondente"
        self._populate_of_tree()
        self.tr_of.selection_set(str(idx))
        self._on_select_of_row()

    def print_of_rows(self):
        if not self._of_rows:
            messagebox.showerror("Erro", "Nenhuma OF carregada.")
            return
        unresolved = []
        requests = []
        for row in self._of_rows:
            if not row.textile_option:
                unresolved.append(f"{row.ref_code} cor {row.color_code} tam {row.size}: sem tecido")
                continue
            if row.final_quantity <= 0:
                unresolved.append(f"{row.ref_code} cor {row.color_code} tam {row.size}: quantidade invalida")
                continue
            requests.append(row.to_print_request(self.v_mode.get().strip()))
        if unresolved:
            messagebox.showerror("Erro", "Corrija as linhas antes de imprimir:\n" + "\n".join(unresolved[:12]))
            return
        try:
            self._run_print_requests(requests, direct=True)
            self.v_of_status.set(f"Impressao da OF executada para {len(requests)} linha(s).")
        except Exception as e:
            messagebox.showerror("Erro de impressao", str(e))

    def print_manual(self):
        try:
            qty = int(self.v_qty.get())
            if qty <= 0:
                raise ValueError("Quantidade deve ser positiva.")
            selected_textile = self._selected_textile_option()
            if self._textile_options and not selected_textile:
                raise ValueError("Selecione um tecido para o produto.")
            from app.domain.models import PrintRequest

            req = PrintRequest(
                ref_code=self.v_ref.get().strip(),
                size=self.v_size.get().strip().upper(),
                quantity=qty,
                mode=self.v_mode.get().strip(),
                color_code=self.v_color.get().strip(),
                textile_name=selected_textile.textile_name if selected_textile else "",
                company=selected_textile.company if selected_textile else "",
            )
            self._run_print_requests([req], direct=True)
        except Exception as e:
            messagebox.showerror("Erro de impressao", str(e))

    def _refresh_print_summary(self):
        return None

    def _add_print_row(self, *args, **kwargs):
        return None

    def clear_print_table(self):
        return None
