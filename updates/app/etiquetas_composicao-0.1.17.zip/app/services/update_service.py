from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any
from urllib.request import urlopen

from app.paths import (
    APPLY_LOG_PATH,
    CURRENT_VERSION_PATH,
    DATA_DIR,
    PENDING_APP_UPDATE_PATH,
    PROJECT_ROOT,
    SYMBOLS_DIR,
    UPDATE_BACKUP_DIR,
    UPDATE_CACHE_DIR,
    UPDATE_LOG_PATH,
    UPDATE_STAGE_DIR,
    UPDATE_STATE_PATH,
    VERSIONS_DIR,
)
from app.services.update_crypto import decrypt_bytes, sha256_hex
from app.update_config import load_update_config, resolve_bundle_url
from app.version import APP_VERSION, UPDATE_SCHEMA_VERSION


@dataclass
class BundleSpec:
    name: str
    version: str
    forced: bool
    bundle_url: str
    sha256_encrypted: str
    sha256_decrypted_zip: str


def _utc_now() -> str:
    return datetime.utcnow().replace(microsecond=0).isoformat() + "Z"


def _version_key(value: str) -> list[Any]:
    text = str(value or "").strip()
    if not text:
        return [0]
    parts: list[Any] = []
    token = ""
    token_is_digit = text[0].isdigit()
    for ch in text:
        if ch.isdigit() == token_is_digit and ch.isalnum():
            token += ch
            continue
        if token:
            parts.append(int(token) if token_is_digit else token.lower())
        token = ch if ch.isalnum() else ""
        token_is_digit = ch.isdigit()
    if token:
        parts.append(int(token) if token_is_digit else token.lower())
    return parts or [text.lower()]


def _is_newer(remote: str, local: str) -> bool:
    return _version_key(remote) > _version_key(local)


def _safe_read_json(path: Path, default: dict) -> dict:
    if not path.exists():
        return dict(default)
    try:
        loaded = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(loaded, dict):
            merged = dict(default)
            merged.update(loaded)
            return merged
    except Exception:
        pass
    return dict(default)


class UpdateService:
    def __init__(self) -> None:
        self.config = load_update_config()
        self.manifest_url = str(self.config.get("manifest_url", "") or "").strip()
        self.password = str(self.config.get("password", "") or "")
        self.check_timeout = float(self.config.get("check_timeout_seconds", 3.0) or 3.0)
        self.bundle_timeout = float(self.config.get("bundle_timeout_seconds", 20.0) or 20.0)
        self.auto_apply_data = bool(self.config.get("auto_apply_data", True))
        self.auto_stage_app = bool(self.config.get("auto_stage_app", True))
        UPDATE_CACHE_DIR.mkdir(parents=True, exist_ok=True)
        UPDATE_STAGE_DIR.mkdir(parents=True, exist_ok=True)
        UPDATE_BACKUP_DIR.mkdir(parents=True, exist_ok=True)
        DATA_DIR.mkdir(parents=True, exist_ok=True)

    def _log(self, message: str) -> None:
        print(f"[update] {message}", flush=True)
        self._write_log(UPDATE_LOG_PATH, message)

    def _apply_log(self, message: str) -> None:
        self._log(message)
        self._write_log(APPLY_LOG_PATH, message)

    def _write_log(self, path: Path, message: str) -> None:
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open("a", encoding="utf-8") as f:
                f.write(f"{_utc_now()} {message}\n")
        except Exception:
            pass

    def _default_state(self) -> dict:
        return {
            "schema_version": UPDATE_SCHEMA_VERSION,
            "app_version": APP_VERSION,
            "data_version": "0",
            "pending_app_version": "",
            "installed_app_files": [],
            "installed_data_files": [],
            "available_app_version": "",
            "available_data_version": "",
            "last_check": "",
            "last_error": "",
            "last_data_update": "",
            "last_app_stage": "",
            "last_app_apply": "",
            "current_version_path": "",
        }

    def load_state(self) -> dict:
        state = _safe_read_json(UPDATE_STATE_PATH, self._default_state())
        if state.get("app_version") != APP_VERSION:
            state["app_version"] = APP_VERSION
        current_pointer = self._read_current_version_pointer()
        if current_pointer:
            state["current_version_path"] = str(current_pointer.get("version_path", "") or "")
        return state

    def save_state(self, state: dict) -> None:
        state["schema_version"] = UPDATE_SCHEMA_VERSION
        UPDATE_STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
        UPDATE_STATE_PATH.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")

    def _record_error(self, state: dict, exc: Exception | str) -> None:
        self._log(f"erro: {exc}")
        state["last_error"] = str(exc)
        self.save_state(state)

    def _fetch_bytes(self, url: str, timeout: float) -> bytes:
        with urlopen(url, timeout=timeout) as response:
            return response.read()

    def _fetch_manifest(self) -> dict:
        if not self.manifest_url:
            self._log("manifest_url vazio, pulando checagem online.")
            return {}
        self._log(f"buscando manifesto: {self.manifest_url}")
        raw = self._fetch_bytes(self.manifest_url, self.check_timeout)
        manifest = json.loads(raw.decode("utf-8"))
        if not isinstance(manifest, dict):
            raise ValueError("Manifesto de update invalido.")
        self._log("manifesto recebido.")
        return manifest

    def _bundle_from_manifest(self, manifest: dict, name: str) -> BundleSpec | None:
        block = manifest.get(name)
        if not isinstance(block, dict):
            return None
        bundle_url = str(block.get("bundle_url", "") or "").strip()
        version = str(block.get("version", "") or "").strip()
        if not bundle_url or not version:
            return None
        return BundleSpec(
            name=name,
            version=version,
            forced=bool(block.get("forced", False)),
            bundle_url=resolve_bundle_url(self.manifest_url, bundle_url),
            sha256_encrypted=str(block.get("sha256_encrypted", "") or "").strip().lower(),
            sha256_decrypted_zip=str(block.get("sha256_decrypted_zip", "") or "").strip().lower(),
        )

    def _download_and_extract_bundle(self, spec: BundleSpec) -> tuple[Path, dict]:
        self._log(f"baixando pacote {spec.name} {spec.version}")
        encrypted = self._fetch_bytes(spec.bundle_url, self.bundle_timeout)
        if spec.sha256_encrypted and sha256_hex(encrypted) != spec.sha256_encrypted:
            raise ValueError(f"Hash do pacote {spec.name} nao confere.")
        self._log(f"descriptografando pacote {spec.name} {spec.version}")
        zip_bytes = decrypt_bytes(encrypted, self.password)
        if spec.sha256_decrypted_zip and sha256_hex(zip_bytes) != spec.sha256_decrypted_zip:
            raise ValueError(f"Hash interno do pacote {spec.name} nao confere.")

        work_dir = Path(tempfile.mkdtemp(prefix=f"etiquetas_{spec.name}_", dir=str(UPDATE_CACHE_DIR)))
        archive_path = work_dir / f"{spec.name}.zip"
        archive_path.write_bytes(zip_bytes)
        extract_dir = work_dir / "extract"
        extract_dir.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(archive_path, "r") as zf:
            zf.extractall(extract_dir)
        manifest_path = extract_dir / "bundle_manifest.json"
        if not manifest_path.exists():
            raise ValueError(f"Manifesto interno ausente no pacote {spec.name}.")
        bundle_manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        if not isinstance(bundle_manifest, dict):
            raise ValueError(f"Manifesto interno invalido no pacote {spec.name}.")
        self._log(f"pacote {spec.name} {spec.version} pronto para aplicar")
        return extract_dir, bundle_manifest

    def _persist_bundle_stage(self, spec: BundleSpec, extract_dir: Path) -> Path:
        stage_root = UPDATE_STAGE_DIR / f"{spec.name}-{spec.version}"
        if stage_root.exists():
            shutil.rmtree(stage_root)
        shutil.copytree(extract_dir, stage_root)
        self._log(f"pacote {spec.name} {spec.version} preservado em {stage_root}")
        return stage_root

    def _read_version_from_dir(self, version_dir: Path) -> str:
        version_path = version_dir / "app" / "version.py"
        if not version_path.exists():
            return ""
        try:
            match = re.search(r'APP_VERSION = "([^"]+)"', version_path.read_text(encoding="utf-8"))
            if match:
                return match.group(1).strip()
        except Exception:
            pass
        return ""

    def _validate_version_dir(self, version_dir: Path, expected_version: str | None = None) -> bool:
        if not version_dir.is_dir():
            return False
        if not (version_dir / "app" / "launch.py").exists():
            return False
        actual_version = self._read_version_from_dir(version_dir)
        if not actual_version:
            return False
        if expected_version and actual_version != expected_version:
            return False
        return True

    def _write_current_version_pointer(self, version: str, version_dir: Path) -> None:
        CURRENT_VERSION_PATH.parent.mkdir(parents=True, exist_ok=True)
        CURRENT_VERSION_PATH.write_text(
            json.dumps(
                {
                    "app_version": version,
                    "version_path": str(version_dir),
                    "activated_at": _utc_now(),
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )

    def _read_current_version_pointer(self) -> dict:
        return _safe_read_json(CURRENT_VERSION_PATH, {})

    def _backup_targets(self, relative_files: list[str], prefix: str) -> None:
        if not relative_files:
            return
        backup_root = UPDATE_BACKUP_DIR / f"{prefix}-{int(time.time())}"
        for rel in relative_files:
            src = PROJECT_ROOT / rel
            if not src.exists():
                continue
            dst = backup_root / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            if src.is_dir():
                if dst.exists():
                    self._retry_operation(lambda p=dst: shutil.rmtree(p), f"remover backup antigo {rel}")
                self._retry_operation(lambda s=src, d=dst: shutil.copytree(s, d), f"backup diretorio {rel}")
            else:
                self._retry_operation(lambda s=src, d=dst: shutil.copy2(s, d), f"backup arquivo {rel}")

    def _remove_old_tracked_files(self, old_files: list[str], new_files: list[str]) -> None:
        old_set = {str(x).replace("\\", "/") for x in old_files if str(x).strip()}
        new_set = {str(x).replace("\\", "/") for x in new_files if str(x).strip()}
        for rel in sorted(old_set - new_set, reverse=True):
            path = PROJECT_ROOT / rel
            if not path.exists():
                continue
            try:
                if path.is_file():
                    self._retry_operation(lambda p=path: p.unlink(), f"remover arquivo antigo {rel}")
            except Exception:
                continue

    def _copy_relative_files(self, source_root: Path, relative_files: list[str]) -> None:
        for rel in relative_files:
            src = source_root / rel
            dst = PROJECT_ROOT / rel
            if not src.exists():
                continue
            dst.parent.mkdir(parents=True, exist_ok=True)
            if src.is_dir():
                if dst.exists():
                    self._retry_operation(lambda p=dst: shutil.rmtree(p), f"remover diretorio {rel}")
                self._retry_operation(lambda s=src, d=dst: shutil.copytree(s, d), f"copiar diretorio {rel}")
            else:
                self._retry_operation(lambda s=src, d=dst: shutil.copy2(s, d), f"copiar arquivo {rel}")

    def _retry_operation(self, operation, description: str) -> None:
        last_exc: Exception | None = None
        for attempt in range(1, 16):
            try:
                operation()
                if attempt > 1:
                    self._apply_log(f"{description}: ok apos tentativa {attempt}")
                return
            except PermissionError as exc:
                last_exc = exc
                self._apply_log(f"{description}: bloqueado na tentativa {attempt}: {exc}")
                time.sleep(min(0.25 * attempt, 2.0))
            except OSError as exc:
                last_exc = exc
                self._apply_log(f"{description}: falhou na tentativa {attempt}: {exc}")
                time.sleep(min(0.25 * attempt, 2.0))
        assert last_exc is not None
        raise last_exc

    def apply_data_update(self, spec: BundleSpec, state: dict) -> bool:
        self._log(f"atualizando dados: local={state.get('data_version', '0')} online={spec.version} forced={spec.forced}")
        extract_dir, bundle_manifest = self._download_and_extract_bundle(spec)
        stage_root = self._persist_bundle_stage(spec, extract_dir)
        files = [str(x).replace("\\", "/") for x in bundle_manifest.get("files", []) if str(x).strip()]
        if not files:
            raise ValueError("Pacote de dados sem lista de arquivos.")
        self._backup_targets(files, f"data-{spec.version}")
        self._remove_old_tracked_files(state.get("installed_data_files", []), files)
        self._copy_relative_files(stage_root, files)
        state["data_version"] = spec.version
        state["installed_data_files"] = files
        state["available_data_version"] = spec.version
        state["last_data_update"] = _utc_now()
        state["last_error"] = ""
        self.save_state(state)
        shutil.rmtree(extract_dir.parent, ignore_errors=True)
        self._log(f"dados atualizados para {spec.version}; copia preservada em {stage_root}")
        return True

    def stage_app_update(self, spec: BundleSpec, state: dict) -> bool:
        self._log(f"preparando update do programa: local={state.get('app_version', APP_VERSION)} online={spec.version} forced={spec.forced}")
        extract_dir, bundle_manifest = self._download_and_extract_bundle(spec)
        files = [str(x).replace("\\", "/") for x in bundle_manifest.get("files", []) if str(x).strip()]
        if not files:
            raise ValueError("Pacote de programa sem lista de arquivos.")
        version_dir = VERSIONS_DIR / spec.version
        VERSIONS_DIR.mkdir(parents=True, exist_ok=True)
        if version_dir.exists():
            shutil.rmtree(version_dir)
        shutil.move(str(extract_dir), str(version_dir))
        shutil.rmtree(extract_dir.parent, ignore_errors=True)
        if not self._validate_version_dir(version_dir, spec.version):
            raise ValueError(f"Versao preparada do programa invalida: {version_dir}")
        pending = {
            "version": spec.version,
            "forced": bool(spec.forced),
            "staged_at": _utc_now(),
            "version_dir": str(version_dir),
            "files": files,
        }
        PENDING_APP_UPDATE_PATH.parent.mkdir(parents=True, exist_ok=True)
        PENDING_APP_UPDATE_PATH.write_text(json.dumps(pending, ensure_ascii=False, indent=2), encoding="utf-8")
        state["pending_app_version"] = spec.version
        state["available_app_version"] = spec.version
        state["installed_app_files"] = files
        state["last_app_stage"] = _utc_now()
        state["last_error"] = ""
        self.save_state(state)
        self._log(f"update do programa {spec.version} preparado em {version_dir}")
        return True

    def startup_sync(self) -> dict:
        state = self.load_state()
        result = {"state": state, "restart_required": False}
        self._log("procurando atualizacoes...")
        self._log(f"versoes atuais: app={state.get('app_version', APP_VERSION)} data={state.get('data_version', '0')}")
        state["last_check"] = _utc_now()
        self.save_state(state)
        if not self.manifest_url:
            result["state"] = state
            return result
        try:
            manifest = self._fetch_manifest()
            app_spec = self._bundle_from_manifest(manifest, "app")
            data_spec = self._bundle_from_manifest(manifest, "data")
            if data_spec:
                self._log(f"versao online de dados: {data_spec.version} forced={data_spec.forced}")
                state["available_data_version"] = data_spec.version
                if self.auto_apply_data and _is_newer(data_spec.version, str(state.get("data_version", "0"))):
                    self.apply_data_update(data_spec, state)
                    state = self.load_state()
                else:
                    self._log("dados ja estao atualizados.")
            if app_spec:
                local_app_version = str(state.get("app_version", APP_VERSION) or APP_VERSION)
                self._log(f"versao online do programa: {app_spec.version} forced={app_spec.forced}")
                state["available_app_version"] = app_spec.version
                already_pending = str(state.get("pending_app_version", "") or "").strip() == app_spec.version
                staged_now = False
                if self.auto_stage_app and _is_newer(app_spec.version, local_app_version) and not already_pending:
                    self.stage_app_update(app_spec, state)
                    state = self.load_state()
                    staged_now = True
                elif already_pending:
                    self._log(f"update do programa {app_spec.version} ja estava preparado.")
                else:
                    self._log("programa ja esta atualizado.")
                if app_spec.forced and staged_now:
                    self._log("update forcado do programa preparado; reinicio imediato necessario.")
                    result["restart_required"] = True
                elif app_spec.forced and already_pending:
                    self._log("update forcado do programa ja preparado; reinicio imediato necessario.")
                    result["restart_required"] = True
            if not data_spec and not app_spec:
                self._log("manifesto sem pacotes validos de app/dados.")
            state["last_error"] = ""
            self.save_state(state)
            self._log("checagem de updates concluida.")
            result["state"] = state
            return result
        except Exception as exc:
            self._record_error(state, exc)
            self._log("seguindo sem bloquear a aplicacao.")
            result["state"] = state
            return result

    def _load_pending_update(self) -> dict | None:
        if not PENDING_APP_UPDATE_PATH.exists():
            return None
        try:
            payload = json.loads(PENDING_APP_UPDATE_PATH.read_text(encoding="utf-8"))
            if isinstance(payload, dict):
                return payload
        except Exception:
            return None
        return None

    def has_pending_app_update(self) -> bool:
        return self._load_pending_update() is not None

    def pending_app_update_is_forced(self) -> bool:
        pending = self._load_pending_update()
        return bool(pending and pending.get("forced", False))

    def _apply_pending_app_update_once(self) -> bool:
        pending = self._load_pending_update()
        if not pending:
            return False
        version = str(pending.get("version", "") or "").strip()
        version_dir = Path(str(pending.get("version_dir", "") or "").strip())
        files = [str(x).replace("\\", "/") for x in pending.get("files", []) if str(x).strip()]
        if not version or not version_dir.exists() or not files:
            return False
        if not self._validate_version_dir(version_dir, version):
            raise RuntimeError(f"Versao preparada invalida para ativacao: {version_dir}")
        self._apply_log(f"ativando update pendente do programa {version}")
        self._apply_log(f"versao preparada: {version_dir}")
        self._apply_log(f"ponteiro atual sera atualizado em {CURRENT_VERSION_PATH}")
        state = self.load_state()
        self._write_current_version_pointer(version, version_dir)
        current_pointer = self._read_current_version_pointer()
        if str(current_pointer.get("app_version", "") or "").strip() != version:
            raise RuntimeError(f"Ponteiro de versao nao foi atualizado para {version}.")
        state["app_version"] = version
        state["pending_app_version"] = ""
        state["installed_app_files"] = files
        state["current_version_path"] = str(version_dir)
        state["last_app_apply"] = _utc_now()
        state["last_error"] = ""
        self.save_state(state)
        try:
            PENDING_APP_UPDATE_PATH.unlink()
        except Exception:
            pass
        self._apply_log(f"update pendente do programa {version} ativado")
        return True

    def apply_pending_app_update(self, wait_seconds: float = 25.0) -> bool:
        self._apply_log("verificando se existe update pendente do programa...")
        deadline = time.time() + max(wait_seconds, 1.0)
        last_exc: Exception | None = None
        while time.time() < deadline:
            try:
                return self._apply_pending_app_update_once()
            except PermissionError as exc:
                last_exc = exc
                time.sleep(0.5)
            except Exception as exc:
                state = self.load_state()
                self._record_error(state, exc)
                return False
        if last_exc:
            state = self.load_state()
            self._record_error(state, last_exc)
        self._log("nenhum update pendente aplicado.")
        return False

    def _launch_runner(self, relaunch_cmd: list[str] | None = None, parent_pid: int | None = None) -> bool:
        pending = self._load_pending_update()
        if not pending:
            return False
        script_path = UPDATE_CACHE_DIR / "apply_pending_update_runner.py"
        relaunch_json = json.dumps(relaunch_cmd or [])
        parent_pid_value = int(parent_pid or 0)
        project_root_json = json.dumps(str(PROJECT_ROOT))
        apply_log_json = json.dumps(str(APPLY_LOG_PATH))
        code_root_json = json.dumps(str(Path(__file__).resolve().parents[2]))
        shared_root_env_json = json.dumps(str(os.environ.get("ETIQUETAS_SHARED_ROOT", str(PROJECT_ROOT))))
        script_path.write_text(
            (
                "import ctypes, json, os, subprocess, sys, time\n"
                f"PROJECT_ROOT = json.loads({project_root_json!r})\n"
                f"APPLY_LOG = json.loads({apply_log_json!r})\n"
                f"CODE_ROOT = json.loads({code_root_json!r})\n"
                f"SHARED_ROOT = json.loads({shared_root_env_json!r})\n"
                "def runner_log(message):\n"
                "    try:\n"
                "        os.makedirs(os.path.dirname(APPLY_LOG), exist_ok=True)\n"
                "        with open(APPLY_LOG, 'a', encoding='utf-8') as f:\n"
                "            f.write(time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()) + ' runner: ' + message + '\\n')\n"
                "    except Exception:\n"
                "        pass\n"
                "runner_log('iniciado')\n"
                "os.environ['ETIQUETAS_SHARED_ROOT'] = SHARED_ROOT\n"
                "if CODE_ROOT not in sys.path:\n"
                "    sys.path.insert(0, CODE_ROOT)\n"
                "from app.services.update_service import apply_pending_update_cli\n"
                f"cmd = json.loads({relaunch_json!r})\n"
                f"parent_pid = {parent_pid_value!r}\n"
                "def wait_for_parent(pid):\n"
                "    if not pid:\n"
                "        runner_log('sem pid pai, aguardando fallback')\n"
                "        time.sleep(0.75)\n"
                "        return\n"
                "    runner_log('aguardando processo pai ' + str(pid))\n"
                "    deadline = time.time() + 45.0\n"
                "    if sys.platform.startswith('win'):\n"
                "        SYNCHRONIZE = 0x00100000\n"
                "        WAIT_TIMEOUT = 0x00000102\n"
                "        kernel32 = ctypes.windll.kernel32\n"
                "        handle = kernel32.OpenProcess(SYNCHRONIZE, False, pid)\n"
                "        if handle:\n"
                "            try:\n"
                "                while time.time() < deadline:\n"
                "                    if kernel32.WaitForSingleObject(handle, 500) != WAIT_TIMEOUT:\n"
                "                        runner_log('processo pai finalizado')\n"
                "                        return\n"
                "            finally:\n"
                "                kernel32.CloseHandle(handle)\n"
                "        runner_log('nao foi possivel esperar handle do pai, aguardando fallback')\n"
                "        time.sleep(1.5)\n"
                "        return\n"
                "    while time.time() < deadline:\n"
                "        try:\n"
                "            os.kill(pid, 0)\n"
                "        except OSError:\n"
                "            runner_log('processo pai finalizado')\n"
                "            return\n"
                "        time.sleep(0.5)\n"
                "    runner_log('tempo de espera pelo pai esgotado')\n"
                "wait_for_parent(parent_pid)\n"
                "runner_log('aplicando update pendente')\n"
                "code = apply_pending_update_cli(wait_seconds=25.0)\n"
                "runner_log('resultado apply=' + str(code))\n"
                "if code == 0 and cmd:\n"
                "    runner_log('reabrindo programa')\n"
                "    subprocess.Popen(cmd, cwd=PROJECT_ROOT, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL, start_new_session=True)\n"
            ),
            encoding="utf-8",
        )
        try:
            subprocess.Popen(
                [sys.executable, str(script_path)],
                cwd=str(PROJECT_ROOT),
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL,
                start_new_session=True,
            )
            return True
        except Exception:
            return False

    def launch_pending_app_update_after_exit(self, parent_pid: int) -> bool:
        return self._launch_runner(parent_pid=parent_pid)

    def launch_pending_app_update_and_restart(self, entry_script: str, extra_args: list[str] | None = None, parent_pid: int | None = None) -> bool:
        cmd = [sys.executable, entry_script]
        if extra_args:
            cmd.extend(extra_args)
        return self._launch_runner(relaunch_cmd=cmd, parent_pid=parent_pid)


def apply_pending_update_cli(wait_seconds: float = 25.0) -> int:
    service = UpdateService()
    return 0 if service.apply_pending_app_update(wait_seconds=wait_seconds) else 1
