from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = PROJECT_ROOT / "data"
SYMBOLS_DIR = PROJECT_ROOT / "simbologias"
UPDATES_DIR = PROJECT_ROOT / "updates"
UPDATE_WORK_DIR = PROJECT_ROOT / ".update_runtime"
UPDATE_CACHE_DIR = UPDATE_WORK_DIR / "cache"
UPDATE_STAGE_DIR = UPDATE_WORK_DIR / "staging"
UPDATE_BACKUP_DIR = UPDATE_WORK_DIR / "backups"
UPDATE_LOG_PATH = UPDATE_WORK_DIR / "update.log"
APPLY_LOG_PATH = UPDATE_WORK_DIR / "apply.log"
UPDATE_STATE_PATH = DATA_DIR / "update_state.json"
PENDING_APP_UPDATE_PATH = DATA_DIR / "pending_app_update.json"
UPDATE_CONFIG_PATH = PROJECT_ROOT / "update_config.json"
