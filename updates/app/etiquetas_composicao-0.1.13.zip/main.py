import sys
import json
import os
from pathlib import Path
import tkinter as tk
from tkinter import ttk

from app.version import APP_VERSION
from app.services.update_service import UpdateService


def _updates_disabled(argv: list[str] | None = None) -> bool:
    args = argv if argv is not None else sys.argv[1:]
    return "--no-update" in args

def maximize_window(root: tk.Tk) -> None:
    if sys.platform.startswith("win"):
        try:
            root.state("zoomed")
            return
        except Exception:
            pass

    if not sys.platform.startswith("win"):
        for attempt in (
            lambda: root.wm_attributes("-zoomed", 1),
            lambda: root.attributes("-zoomed", True),
            lambda: root.wm_state("zoomed"),
        ):
            try:
                attempt()
                root.update_idletasks()
                current_w = root.winfo_width()
                current_h = root.winfo_height()
                if current_w > 1200 or current_h > 700:
                    return
            except Exception:
                continue


def _load_window_state(root: tk.Tk, path: str) -> bool:
    if not os.path.exists(path):
        return False
    try:
        with open(path, "r", encoding="utf-8") as f:
            state = json.load(f)
    except Exception:
        return False

    geometry = (state.get("geometry") or "").strip()
    zoomed = bool(state.get("zoomed", False))
    try:
        if geometry:
            root.geometry(geometry)
        if zoomed:
            if sys.platform.startswith("win"):
                root.state("zoomed")
            else:
                try:
                    root.wm_attributes("-zoomed", 1)
                except Exception:
                    try:
                        root.attributes("-zoomed", True)
                    except Exception:
                        root.wm_state("zoomed")
        return True
    except Exception:
        return False


def _save_window_state(root: tk.Tk, path: str) -> None:
    zoomed = False
    try:
        zoomed = root.state() == "zoomed"
    except Exception:
        try:
            zoomed = bool(root.wm_attributes("-zoomed"))
        except Exception:
            zoomed = False
    state = {
        "geometry": root.geometry(),
        "zoomed": zoomed,
    }
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(state, f, ensure_ascii=False, indent=2)


def main():
    os.chdir(Path(__file__).resolve().parent)
    update_service = UpdateService()
    updates_disabled = _updates_disabled()
    if not updates_disabled:
        update_result = update_service.startup_sync()
        if update_result.get("restart_required"):
            relaunched = update_service.launch_pending_app_update_and_restart(str(Path(__file__).resolve()), sys.argv[1:])
            if relaunched:
                return
    state_path = os.path.join("data", "window_state_print.json")
    from app.ui.print_window import PrintWindow
    root = tk.Tk()
    root.title(f"Etiquetas Composicao - Impressao v{APP_VERSION}")
    root.geometry("1220x760")
    style = ttk.Style(root)
    try:
        style.theme_use("clam")
    except Exception:
        pass
    app = PrintWindow(root)
    restored = _load_window_state(root, state_path)

    def on_close():
        try:
            app._save_ui_state()
        except Exception:
            pass
        _save_window_state(root, state_path)
        if not updates_disabled:
            try:
                update_service.launch_pending_app_update_after_exit(os.getpid())
            except Exception:
                pass
        root.destroy()

    root.protocol("WM_DELETE_WINDOW", on_close)
    if not restored:
        root.after_idle(lambda: maximize_window(root))
    root.mainloop()


if __name__ == "__main__":
    main()
